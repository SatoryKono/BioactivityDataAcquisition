"""End-to-end tests for complete pipeline flows.

These tests verify full Extract → Bronze → Silver → Gold flows
with real infrastructure (MinIO, Redis via Docker).

NOTE: These tests are currently SKIPPED due to existing issues with:
- Delta Lake Arrow schema compatibility
- PubChem query requirements
- Domain model changes

Focus on test_infrastructure.py for E2E infrastructure testing.
"""

from unittest.mock import AsyncMock, patch

import pytest

from bioetl.composition.bootstrap import bootstrap_pipeline
from bioetl.composition.factories.storage import StorageAdapter, StorageContext
from bioetl.infrastructure.storage.bronze_writer import BronzeWriter
from bioetl.infrastructure.storage.gold_writer import GoldWriter
from bioetl.infrastructure.storage.silver_writer import SilverWriter
from tests.e2e.conftest import create_test_context


@pytest.mark.e2e
@pytest.mark.slow
class TestChEMBLPipelineE2E:
    """E2E tests for ChEMBL Activity pipeline."""

    @pytest.fixture
    def storage_paths(self, e2e_temp_storage):
        """Get storage paths from E2E temp storage."""
        return e2e_temp_storage

    @pytest.fixture
    def storage_adapter(self, storage_paths):
        """Create storage adapter with real writers pointing to temp paths."""
        import structlog

        logger = structlog.get_logger()

        bronze_writer = BronzeWriter(
            base_path=str(storage_paths["bronze"]),
            logger=logger,
            metrics=AsyncMock(),
            save_json=True,
            json_path=str(storage_paths["bronze"] / "json"),
        )

        silver_writer = SilverWriter(
            base_path=str(storage_paths["silver"]),
            logger=logger,
        )

        gold_writer = GoldWriter(
            base_path=str(storage_paths["gold"]),
            logger=logger,
        )

        return StorageAdapter(
            bronze_writer=bronze_writer,
            silver_writer=silver_writer,
            gold_writer=gold_writer,
        )

    @pytest.mark.vcr
    async def test_chembl_activity_full_run(
        self,
        storage_adapter,
        storage_paths,
        e2e_redis_client,
        e2e_minio_client,
        e2e_pipeline_limit,
    ):
        """Test complete pipeline from extract to Gold with real infrastructure.

        Verifies:
        - Bronze files created (JSONL)
        - Silver table created (Delta Lake)
        - Gold aggregations (if applicable)
        - Checkpoint saved
        - Redis locks released
        """
        storage_context = StorageContext(
            adapter=storage_adapter,
            bronze_path=str(storage_paths["bronze"]),
            silver_path=str(storage_paths["silver"]),
            gold_path=str(storage_paths["gold"]),
            checkpoints_path=str(storage_paths["checkpoints"]),
        )

        # Patch StorageFactory to return our test storage context
        with patch(
            "bioetl.composition.factories.services_factory.StorageFactory.create",
            return_value=storage_context,
        ):
            ctx = create_test_context("chembl_activity", limit=e2e_pipeline_limit)
            runner = bootstrap_pipeline(ctx)

            # Execute pipeline
            await runner.run()

        # Verify Bronze: Check for JSONL files
        bronze_files = list(storage_paths["bronze"].rglob("*.jsonl*"))
        assert len(bronze_files) > 0, "No Bronze JSONL files created"

        # Verify Silver: Check for Delta Lake files
        silver_parquet = list(storage_paths["silver"].rglob("*.parquet"))
        assert len(silver_parquet) > 0, "No Silver parquet files created"

        silver_delta_log = list(storage_paths["silver"].rglob("_delta_log"))
        assert len(silver_delta_log) > 0, "No Delta log created in Silver"

        # Verify locks released in Redis
        # Check that no locks remain with the chembl_activity pattern
        lock_keys = await e2e_redis_client.keys("lock:chembl_activity*")
        assert len(lock_keys) == 0, f"Locks not released: {lock_keys}"


@pytest.mark.e2e
@pytest.mark.slow
@pytest.mark.vcr
async def test_pubchem_compound_pipeline(
    e2e_temp_storage,
    e2e_redis_client,
    e2e_minio_client,
    e2e_pipeline_limit,
):
    """Test PubChem compound pipeline E2E flow.

    Verifies that PubChem pipeline can:
    - Extract compound data
    - Write to Bronze layer
    - Transform to Silver layer
    """
    import structlog

    logger = structlog.get_logger()

    # Create storage adapter for tests (lock validation is now at Application layer)
    bronze_writer = BronzeWriter(
        base_path=str(e2e_temp_storage["bronze"]),
        logger=logger,
        metrics=AsyncMock(),
        save_json=True,
        json_path=str(e2e_temp_storage["bronze"] / "json"),
    )

    silver_writer = SilverWriter(
        base_path=str(e2e_temp_storage["silver"]),
        logger=logger,
    )

    gold_writer = GoldWriter(
        base_path=str(e2e_temp_storage["gold"]),
        logger=logger,
    )

    storage_adapter = StorageAdapter(
        bronze_writer=bronze_writer,
        silver_writer=silver_writer,
        gold_writer=gold_writer,
    )

    storage_context = StorageContext(
        adapter=storage_adapter,
        bronze_path=str(e2e_temp_storage["bronze"]),
        silver_path=str(e2e_temp_storage["silver"]),
        gold_path=str(e2e_temp_storage["gold"]),
        checkpoints_path=str(e2e_temp_storage["checkpoints"]),
    )

    # Patch StorageFactory
    with patch(
        "bioetl.composition.factories.services_factory.StorageFactory.create",
        return_value=storage_context,
    ):
        ctx = create_test_context(
            "pubchem_compound",
            limit=e2e_pipeline_limit,
            query="aspirin",
        )
        runner = bootstrap_pipeline(ctx)

        # Execute pipeline
        await runner.run()

    # Verify Bronze files created
    bronze_files = list(e2e_temp_storage["bronze"].rglob("*.jsonl*"))
    assert len(bronze_files) > 0, "No Bronze files created for PubChem"

    # Verify Silver Delta Lake
    silver_parquet = list(e2e_temp_storage["silver"].rglob("*.parquet"))
    assert len(silver_parquet) > 0, "No Silver parquet files for PubChem"

    # Verify locks released
    lock_keys = await e2e_redis_client.keys("lock:pubchem_compound*")
    assert len(lock_keys) == 0, f"PubChem locks not released: {lock_keys}"


@pytest.mark.e2e
@pytest.mark.slow
@pytest.mark.vcr
async def test_pipeline_resume_after_failure(
    e2e_temp_storage,
    e2e_redis_client,
    e2e_minio_client,
):
    """Test pipeline resume with checkpoint after simulated failure.

    Verifies:
    - Checkpoint is saved during execution
    - Pipeline can resume from checkpoint
    - No duplicate records in Silver layer
    """
    import structlog

    logger = structlog.get_logger()

    # Create storage adapter for tests (lock validation is now at Application layer)
    bronze_writer = BronzeWriter(
        base_path=str(e2e_temp_storage["bronze"]),
        logger=logger,
        metrics=AsyncMock(),
        save_json=True,
        json_path=str(e2e_temp_storage["bronze"] / "json"),
    )

    silver_writer = SilverWriter(
        base_path=str(e2e_temp_storage["silver"]),
        logger=logger,
    )

    gold_writer = GoldWriter(
        base_path=str(e2e_temp_storage["gold"]),
        logger=logger,
    )

    storage_adapter = StorageAdapter(
        bronze_writer=bronze_writer,
        silver_writer=silver_writer,
        gold_writer=gold_writer,
    )

    storage_context = StorageContext(
        adapter=storage_adapter,
        bronze_path=str(e2e_temp_storage["bronze"]),
        silver_path=str(e2e_temp_storage["silver"]),
        gold_path=str(e2e_temp_storage["gold"]),
        checkpoints_path=str(e2e_temp_storage["checkpoints"]),
    )

    # First run: Process 5 records
    with patch(
        "bioetl.composition.factories.services_factory.StorageFactory.create",
        return_value=storage_context,
    ):
        ctx = create_test_context("chembl_activity", limit=5)
        runner = bootstrap_pipeline(ctx)

        await runner.run()

    # Verify first run created files
    silver_files_first = list(e2e_temp_storage["silver"].rglob("*.parquet"))
    assert len(silver_files_first) > 0, "No Silver files after first run"

    # Check checkpoint exists
    list(e2e_temp_storage["checkpoints"].rglob("*"))
    # Note: Checkpoint might be in S3 bucket, not local filesystem
    # For E2E we'd need to verify via checkpoint service

    # Second run: Resume with same run_id (would typically continue from checkpoint)
    # For this E2E test, we verify that running again doesn't cause errors
    with patch(
        "bioetl.composition.factories.services_factory.StorageFactory.create",
        return_value=storage_context,
    ):
        ctx = create_test_context("chembl_activity", limit=5)
        runner = bootstrap_pipeline(ctx)

        await runner.run()

    # Verify second run also created files
    silver_files_second = list(e2e_temp_storage["silver"].rglob("*.parquet"))
    assert len(silver_files_second) > 0, "No Silver files after second run"

    # Verify locks released after both runs
    lock_keys = await e2e_redis_client.keys("lock:chembl_activity*")
    assert len(lock_keys) == 0, f"Locks not released after resume: {lock_keys}"


@pytest.mark.e2e
@pytest.mark.slow
@pytest.mark.vcr
async def test_pipeline_idempotency(
    e2e_temp_storage,
    e2e_redis_client,
    e2e_minio_client,
):
    """Test that running the same pipeline twice produces idempotent results.

    Verifies:
    - Same content_hash for identical records
    - No duplicate records in Silver
    - Delta Lake merge/upsert working correctly
    """
    import structlog

    logger = structlog.get_logger()

    # Create storage adapter for tests (lock validation is now at Application layer)
    bronze_writer = BronzeWriter(
        base_path=str(e2e_temp_storage["bronze"]),
        logger=logger,
        metrics=AsyncMock(),
        save_json=True,
        json_path=str(e2e_temp_storage["bronze"] / "json"),
    )

    silver_writer = SilverWriter(
        base_path=str(e2e_temp_storage["silver"]),
        logger=logger,
    )

    gold_writer = GoldWriter(
        base_path=str(e2e_temp_storage["gold"]),
        logger=logger,
    )

    storage_adapter = StorageAdapter(
        bronze_writer=bronze_writer,
        silver_writer=silver_writer,
        gold_writer=gold_writer,
    )

    storage_context = StorageContext(
        adapter=storage_adapter,
        bronze_path=str(e2e_temp_storage["bronze"]),
        silver_path=str(e2e_temp_storage["silver"]),
        gold_path=str(e2e_temp_storage["gold"]),
        checkpoints_path=str(e2e_temp_storage["checkpoints"]),
    )

    # Run 1: Initial load
    with patch(
        "bioetl.composition.factories.services_factory.StorageFactory.create",
        return_value=storage_context,
    ):
        ctx = create_test_context("chembl_activity", limit=5)
        runner = bootstrap_pipeline(ctx)

        await runner.run()

    # Count records after first run
    import polars as pl

    silver_path = e2e_temp_storage["silver"]
    # Find the actual Delta table directory
    delta_tables = [d for d in silver_path.rglob("*") if (d / "_delta_log").exists()]

    if len(delta_tables) > 0:
        df_first = pl.read_delta(str(delta_tables[0]))
        count_first = len(df_first)

        # Run 2: Same data (should be idempotent)
        with patch(
            "bioetl.composition.factories.services_factory.StorageFactory.create",
            return_value=storage_context,
        ):
            ctx = create_test_context("chembl_activity", limit=5)
            runner = bootstrap_pipeline(ctx)

            await runner.run()

        # Count records after second run
        df_second = pl.read_delta(str(delta_tables[0]))
        count_second = len(df_second)

        # Verify idempotency: record count should be similar
        # (may differ slightly due to API changes, but should not double)
        assert count_second <= count_first * 1.5, (
            f"Record count increased too much: {count_first} -> {count_second}. "
            "Idempotency may be broken."
        )

    # Cleanup locks
    lock_keys = await e2e_redis_client.keys("lock:chembl_activity*")
    assert len(lock_keys) == 0, f"Locks not released: {lock_keys}"
