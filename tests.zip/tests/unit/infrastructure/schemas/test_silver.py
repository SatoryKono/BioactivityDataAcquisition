"""Tests for Silver layer PyArrow schemas.

Verifies schema definitions for all entities in the Silver layer.
"""

from __future__ import annotations

import pyarrow as pa
import pytest

from bioetl.infrastructure.schemas.silver import (
    CHEMBL_ACTIVITY_SCHEMA,
    CHEMBL_ASSAY_SCHEMA,
    CHEMBL_DOCUMENT_SCHEMA,
    CHEMBL_MOLECULE_SCHEMA,
    CHEMBL_TARGET_COMPONENT_SCHEMA,
    CHEMBL_TARGET_SCHEMA,
    PUBCHEM_COMPOUND_SCHEMA,
    PUBMED_PUBLICATION_SCHEMA,
    UNIPROT_PROTEIN_SCHEMA,
)

# Required system fields for all Silver schemas
REQUIRED_SYSTEM_FIELDS = frozenset(
    {
        "entity_id",
        "content_hash",
        "_run_id",
        "_run_type",
        "_source_batch_id",
        "_ingestion_ts",
    }
)


class TestSchemaExistence:
    """Test that all required schemas are defined."""

    def test_chembl_activity_schema_exists(self):
        """Verify CHEMBL_ACTIVITY_SCHEMA is defined."""
        assert CHEMBL_ACTIVITY_SCHEMA is not None
        assert isinstance(CHEMBL_ACTIVITY_SCHEMA, pa.Schema)

    def test_chembl_assay_schema_exists(self):
        """Verify CHEMBL_ASSAY_SCHEMA is defined."""
        assert CHEMBL_ASSAY_SCHEMA is not None
        assert isinstance(CHEMBL_ASSAY_SCHEMA, pa.Schema)

    def test_chembl_document_schema_exists(self):
        """Verify CHEMBL_DOCUMENT_SCHEMA is defined."""
        assert CHEMBL_DOCUMENT_SCHEMA is not None
        assert isinstance(CHEMBL_DOCUMENT_SCHEMA, pa.Schema)

    def test_chembl_molecule_schema_exists(self):
        """Verify CHEMBL_MOLECULE_SCHEMA is defined."""
        assert CHEMBL_MOLECULE_SCHEMA is not None
        assert isinstance(CHEMBL_MOLECULE_SCHEMA, pa.Schema)

    def test_chembl_target_schema_exists(self):
        """Verify CHEMBL_TARGET_SCHEMA is defined."""
        assert CHEMBL_TARGET_SCHEMA is not None
        assert isinstance(CHEMBL_TARGET_SCHEMA, pa.Schema)

    def test_chembl_target_component_schema_exists(self):
        """Verify CHEMBL_TARGET_COMPONENT_SCHEMA is defined."""
        assert CHEMBL_TARGET_COMPONENT_SCHEMA is not None
        assert isinstance(CHEMBL_TARGET_COMPONENT_SCHEMA, pa.Schema)

    def test_pubchem_compound_schema_exists(self):
        """Verify PUBCHEM_COMPOUND_SCHEMA is defined."""
        assert PUBCHEM_COMPOUND_SCHEMA is not None
        assert isinstance(PUBCHEM_COMPOUND_SCHEMA, pa.Schema)

    def test_pubmed_publication_schema_exists(self):
        """Verify PUBMED_PUBLICATION_SCHEMA is defined."""
        assert PUBMED_PUBLICATION_SCHEMA is not None
        assert isinstance(PUBMED_PUBLICATION_SCHEMA, pa.Schema)

    def test_uniprot_protein_schema_exists(self):
        """Verify UNIPROT_PROTEIN_SCHEMA is defined."""
        assert UNIPROT_PROTEIN_SCHEMA is not None
        assert isinstance(UNIPROT_PROTEIN_SCHEMA, pa.Schema)


class TestSystemFields:
    """Test that all schemas contain required system fields."""

    @pytest.mark.parametrize(
        "schema,name",
        [
            (CHEMBL_ACTIVITY_SCHEMA, "CHEMBL_ACTIVITY"),
            (CHEMBL_ASSAY_SCHEMA, "CHEMBL_ASSAY"),
            (CHEMBL_DOCUMENT_SCHEMA, "CHEMBL_DOCUMENT"),
            (CHEMBL_MOLECULE_SCHEMA, "CHEMBL_MOLECULE"),
            (CHEMBL_TARGET_SCHEMA, "CHEMBL_TARGET"),
            (CHEMBL_TARGET_COMPONENT_SCHEMA, "CHEMBL_TARGET_COMPONENT"),
            (PUBCHEM_COMPOUND_SCHEMA, "PUBCHEM_COMPOUND"),
            (PUBMED_PUBLICATION_SCHEMA, "PUBMED_PUBLICATION"),
            (UNIPROT_PROTEIN_SCHEMA, "UNIPROT_PROTEIN"),
        ],
    )
    def test_schema_has_all_system_fields(self, schema, name):
        """Verify schema contains all required system fields."""
        schema_field_names = {field.name for field in schema}
        missing_fields = REQUIRED_SYSTEM_FIELDS - schema_field_names
        assert (
            not missing_fields
        ), f"{name} schema missing system fields: {missing_fields}"

    @pytest.mark.parametrize(
        "schema,name",
        [
            (CHEMBL_ACTIVITY_SCHEMA, "CHEMBL_ACTIVITY"),
            (CHEMBL_ASSAY_SCHEMA, "CHEMBL_ASSAY"),
            (CHEMBL_DOCUMENT_SCHEMA, "CHEMBL_DOCUMENT"),
            (CHEMBL_MOLECULE_SCHEMA, "CHEMBL_MOLECULE"),
            (CHEMBL_TARGET_SCHEMA, "CHEMBL_TARGET"),
            (CHEMBL_TARGET_COMPONENT_SCHEMA, "CHEMBL_TARGET_COMPONENT"),
            (PUBCHEM_COMPOUND_SCHEMA, "PUBCHEM_COMPOUND"),
            (PUBMED_PUBLICATION_SCHEMA, "PUBMED_PUBLICATION"),
            (UNIPROT_PROTEIN_SCHEMA, "UNIPROT_PROTEIN"),
        ],
    )
    def test_system_fields_are_strings(self, schema, name):
        """Verify system fields have correct types."""
        for field_name in REQUIRED_SYSTEM_FIELDS:
            field = schema.field(field_name)
            assert (
                field.type == pa.string()
            ), f"{name}.{field_name} should be string, got {field.type}"


class TestChemblActivitySchema:
    """Tests for CHEMBL_ACTIVITY_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "activity_id" in CHEMBL_ACTIVITY_SCHEMA.names

    def test_activity_id_is_string(self):
        """Verify activity_id is string type."""
        field = CHEMBL_ACTIVITY_SCHEMA.field("activity_id")
        assert field.type == pa.string()

    def test_has_core_identifiers(self):
        """Verify core identifier fields exist."""
        expected = [
            "molecule_chembl_id",
            "target_chembl_id",
            "assay_chembl_id",
            "document_chembl_id",
        ]
        for field_name in expected:
            assert field_name in CHEMBL_ACTIVITY_SCHEMA.names

    def test_has_activity_values(self):
        """Verify activity value fields exist."""
        expected = ["value", "units", "standard_value", "standard_units"]
        for field_name in expected:
            assert field_name in CHEMBL_ACTIVITY_SCHEMA.names

    def test_value_fields_are_float64(self):
        """Verify numeric value fields are float64."""
        float_fields = [
            "value",
            "upper_value",
            "standard_value",
            "standard_upper_value",
            "pchembl_value",
        ]
        for field_name in float_fields:
            field = CHEMBL_ACTIVITY_SCHEMA.field(field_name)
            assert (
                field.type == pa.float64()
            ), f"{field_name} should be float64, got {field.type}"

    def test_ligand_efficiency_fields_exist(self):
        """Verify ligand efficiency metrics are present."""
        le_fields = [
            "ligand_efficiency_bei",
            "ligand_efficiency_le",
            "ligand_efficiency_lle",
            "ligand_efficiency_sei",
        ]
        for field_name in le_fields:
            assert field_name in CHEMBL_ACTIVITY_SCHEMA.names

    def test_field_count(self):
        """Verify expected number of fields."""
        # Should have approximately 60+ fields
        assert len(CHEMBL_ACTIVITY_SCHEMA) >= 50


class TestChemblAssaySchema:
    """Tests for CHEMBL_ASSAY_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "assay_chembl_id" in CHEMBL_ASSAY_SCHEMA.names

    def test_has_core_identifiers(self):
        """Verify core identifier fields exist."""
        expected = [
            "target_chembl_id",
            "document_chembl_id",
            "cell_chembl_id",
        ]
        for field_name in expected:
            assert field_name in CHEMBL_ASSAY_SCHEMA.names

    def test_has_biological_context(self):
        """Verify biological context fields exist."""
        expected = [
            "assay_organism",
            "assay_tax_id",
            "assay_cell_type",
        ]
        for field_name in expected:
            assert field_name in CHEMBL_ASSAY_SCHEMA.names

    def test_json_fields_are_strings(self):
        """Verify complex JSON fields are stored as strings."""
        json_fields = ["assay_classifications", "assay_parameters"]
        for field_name in json_fields:
            field = CHEMBL_ASSAY_SCHEMA.field(field_name)
            assert (
                field.type == pa.string()
            ), f"{field_name} should be string (JSON), got {field.type}"


class TestChemblMoleculeSchema:
    """Tests for CHEMBL_MOLECULE_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "molecule_chembl_id" in CHEMBL_MOLECULE_SCHEMA.names

    def test_has_flags(self):
        """Verify boolean flag fields exist."""
        expected_bool = ["oral", "parenteral", "topical", "therapeutic_flag"]
        for field_name in expected_bool:
            assert field_name in CHEMBL_MOLECULE_SCHEMA.names
            field = CHEMBL_MOLECULE_SCHEMA.field(field_name)
            assert (
                field.type == pa.bool_()
            ), f"{field_name} should be bool, got {field.type}"

    def test_has_complex_json_fields(self):
        """Verify complex JSON fields exist and are strings."""
        json_fields = [
            "molecule_hierarchy",
            "molecule_properties",
            "molecule_structures",
            "molecule_synonyms",
            "cross_references",
            "atc_classifications",
        ]
        for field_name in json_fields:
            assert field_name in CHEMBL_MOLECULE_SCHEMA.names
            field = CHEMBL_MOLECULE_SCHEMA.field(field_name)
            assert field.type == pa.string()


class TestChemblTargetSchema:
    """Tests for CHEMBL_TARGET_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "target_chembl_id" in CHEMBL_TARGET_SCHEMA.names

    def test_has_list_fields(self):
        """Verify list fields have correct types."""
        # Note: protein_classifications not available in /target endpoint
        # It's only in /target_component endpoint (CHEMBL_TARGET_COMPONENT_SCHEMA)
        list_fields = [
            "component_accessions",
            "component_types",
            "component_relationships",
            "component_descriptions",
        ]
        for field_name in list_fields:
            assert field_name in CHEMBL_TARGET_SCHEMA.names
            field = CHEMBL_TARGET_SCHEMA.field(field_name)
            assert isinstance(
                field.type, pa.ListType
            ), f"{field_name} should be list, got {field.type}"

    def test_component_ids_is_list_of_int64(self):
        """Verify component_ids is list of int64."""
        field = CHEMBL_TARGET_SCHEMA.field("component_ids")
        assert isinstance(field.type, pa.ListType)
        assert field.type.value_type == pa.int64()


class TestChemblDocumentSchema:
    """Tests for CHEMBL_DOCUMENT_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "document_chembl_id" in CHEMBL_DOCUMENT_SCHEMA.names

    def test_has_publication_identifiers(self):
        """Verify publication identifier fields exist."""
        expected = ["pubmed_id", "doi", "patent_id"]
        for field_name in expected:
            assert field_name in CHEMBL_DOCUMENT_SCHEMA.names

    def test_pubmed_id_is_int64(self):
        """Verify pubmed_id is int64."""
        field = CHEMBL_DOCUMENT_SCHEMA.field("pubmed_id")
        assert field.type == pa.int64()


class TestPubchemCompoundSchema:
    """Tests for PUBCHEM_COMPOUND_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "cid" in PUBCHEM_COMPOUND_SCHEMA.names

    def test_cid_is_string(self):
        """Verify cid is string type (from source)."""
        field = PUBCHEM_COMPOUND_SCHEMA.field("cid")
        assert field.type == pa.string()

    def test_has_structure_fields(self):
        """Verify structure fields exist."""
        expected = [
            "molecular_formula",
            "canonical_smiles",
            "isomeric_smiles",
            "inchi",
            "inchikey",
        ]
        for field_name in expected:
            assert field_name in PUBCHEM_COMPOUND_SCHEMA.names

    def test_all_fields_are_strings(self):
        """Verify all non-system fields are strings."""
        non_system_fields = [
            "cid",
            "molecular_formula",
            "molecular_weight",
            "canonical_smiles",
            "inchi",
            "inchikey",
            "iupac_name",
        ]
        for field_name in non_system_fields:
            field = PUBCHEM_COMPOUND_SCHEMA.field(field_name)
            assert (
                field.type == pa.string()
            ), f"{field_name} should be string, got {field.type}"


class TestUniprotProteinSchema:
    """Tests for UNIPROT_PROTEIN_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "accession" in UNIPROT_PROTEIN_SCHEMA.names

    def test_has_core_fields(self):
        """Verify core fields exist."""
        expected = ["entry_name", "protein_name", "organism_id", "sequence_length"]
        for field_name in expected:
            assert field_name in UNIPROT_PROTEIN_SCHEMA.names

    def test_gene_names_is_list(self):
        """Verify gene_names is list of strings."""
        field = UNIPROT_PROTEIN_SCHEMA.field("gene_names")
        assert isinstance(field.type, pa.ListType)
        assert field.type.value_type == pa.string()

    def test_organism_id_is_int64(self):
        """Verify organism_id is int64."""
        field = UNIPROT_PROTEIN_SCHEMA.field("organism_id")
        assert field.type == pa.int64()


class TestPubmedPublicationSchema:
    """Tests for PUBMED_PUBLICATION_SCHEMA."""

    def test_has_primary_key(self):
        """Verify primary key field exists."""
        assert "pmid" in PUBMED_PUBLICATION_SCHEMA.names

    def test_has_identifiers(self):
        """Verify identifier fields exist."""
        expected = ["doi", "pmc_id"]
        for field_name in expected:
            assert field_name in PUBMED_PUBLICATION_SCHEMA.names

    def test_has_list_fields(self):
        """Verify list fields exist and have correct types."""
        list_fields = ["authors", "publication_types", "keywords", "mesh_terms"]
        for field_name in list_fields:
            assert field_name in PUBMED_PUBLICATION_SCHEMA.names
            field = PUBMED_PUBLICATION_SCHEMA.field(field_name)
            assert isinstance(
                field.type, pa.ListType
            ), f"{field_name} should be list, got {field.type}"
            assert field.type.value_type == pa.string()

    def test_pub_year_is_int64(self):
        """Verify pub_year is int64."""
        field = PUBMED_PUBLICATION_SCHEMA.field("pub_year")
        assert field.type == pa.int64()

    def test_has_journal_info(self):
        """Verify journal information fields exist."""
        expected = ["journal", "journal_abbrev", "volume", "issue"]
        for field_name in expected:
            assert field_name in PUBMED_PUBLICATION_SCHEMA.names


class TestSchemaFieldCounts:
    """Test approximate field counts for each schema."""

    @pytest.mark.parametrize(
        "schema,name,min_fields",
        [
            (CHEMBL_ACTIVITY_SCHEMA, "CHEMBL_ACTIVITY", 50),
            (CHEMBL_ASSAY_SCHEMA, "CHEMBL_ASSAY", 25),
            (CHEMBL_DOCUMENT_SCHEMA, "CHEMBL_DOCUMENT", 15),
            (CHEMBL_MOLECULE_SCHEMA, "CHEMBL_MOLECULE", 20),
            (CHEMBL_TARGET_SCHEMA, "CHEMBL_TARGET", 15),
            (CHEMBL_TARGET_COMPONENT_SCHEMA, "CHEMBL_TARGET_COMPONENT", 10),
            (PUBCHEM_COMPOUND_SCHEMA, "PUBCHEM_COMPOUND", 10),
            (PUBMED_PUBLICATION_SCHEMA, "PUBMED_PUBLICATION", 20),
            (UNIPROT_PROTEIN_SCHEMA, "UNIPROT_PROTEIN", 10),
        ],
    )
    def test_minimum_field_count(self, schema, name, min_fields):
        """Verify schema has at least minimum expected fields."""
        actual = len(schema)
        assert (
            actual >= min_fields
        ), f"{name} has {actual} fields, expected at least {min_fields}"


class TestSchemaImmutability:
    """Test that schemas are effectively immutable."""

    def test_schema_is_frozen(self):
        """Verify schema cannot be modified in-place."""
        # PyArrow schemas are immutable by design
        # This test verifies the behavior
        original_names = list(CHEMBL_ACTIVITY_SCHEMA.names)

        # Attempt to create new schema with field would work,
        # but original should remain unchanged
        new_schema = CHEMBL_ACTIVITY_SCHEMA.append(pa.field("test", pa.string()))

        assert list(CHEMBL_ACTIVITY_SCHEMA.names) == original_names
        assert "test" in new_schema.names
        assert "test" not in CHEMBL_ACTIVITY_SCHEMA.names


class TestSilverSchemaValidation:
    """Tests for Silver schema data validation."""

    def test_silver_schema_valid(self):
        """Silver schema должна валидировать корректные данные."""
        # Create valid data according to CHEMBL_ACTIVITY_SCHEMA
        valid_record = {
            "entity_id": "ACT_12345",
            "content_hash": "abc123def456",
            "activity_id": "12345",
            "molecule_chembl_id": "CHEMBL25",
            "target_chembl_id": "CHEMBL1824",
            "assay_chembl_id": "CHEMBL829232",
            "document_chembl_id": "CHEMBL1122334",
            "record_id": 1001,
            "src_id": 1,
            "canonical_smiles": "CC(=O)OC1=CC=CC=C1C(=O)O",
            "molecule_pref_name": "ASPIRIN",
            "parent_molecule_chembl_id": "CHEMBL25",
            "target_pref_name": "Cyclooxygenase-2",
            "target_organism": "Homo sapiens",
            "target_tax_id": "9606",
            "assay_type": "B",
            "assay_description": "Binding assay",
            "assay_variant_accession": None,
            "assay_variant_mutation": None,
            "bao_endpoint": "BAO_0000190",
            "bao_format": "BAO_0000357",
            "bao_label": "single protein format",
            "type": "IC50",
            "value": 50.0,
            "units": "nM",
            "relation": "=",
            "upper_value": None,
            "text_value": None,
            "standard_type": "IC50",
            "standard_value": 50.0,
            "standard_units": "nM",
            "standard_relation": "=",
            "standard_upper_value": None,
            "standard_text_value": None,
            "standard_flag": 1,
            "pchembl_value": 7.3,
            "ligand_efficiency_bei": 15.2,
            "ligand_efficiency_le": 0.35,
            "ligand_efficiency_lle": 4.1,
            "ligand_efficiency_sei": 8.5,
            "qudt_units": "nM",
            "uo_units": "UO:0000065",
            "document_journal": "J Med Chem",
            "document_year": 2020,
            "activity_comment": None,
            "data_validity_comment": None,
            "data_validity_description": None,
            "potential_duplicate": 0,
            "action_type_action_type": "INHIBITOR",
            "action_type_description": "Enzyme inhibitor",
            "action_type_parent_type": "INHIBITOR",
            "activity_properties": "[]",
            "toid": None,
            "_run_id": "run_001",
            "_run_type": "incremental",
            "_source_batch_id": "batch_001",
            "_ingestion_ts": "2024-01-15T10:30:00Z",
        }

        # Create PyArrow table from valid data - should succeed without exception
        table = pa.Table.from_pylist([valid_record], schema=CHEMBL_ACTIVITY_SCHEMA)

        assert table.num_rows == 1
        assert table.num_columns == len(CHEMBL_ACTIVITY_SCHEMA)

    def test_silver_schema_valid_pubchem(self):
        """PUBCHEM_COMPOUND_SCHEMA должна валидировать корректные данные."""
        valid_record = {
            "entity_id": "CID_2244",
            "cid": "2244",
            "molecular_formula": "C9H8O4",
            "molecular_weight": "180.16",
            "canonical_smiles": "CC(=O)OC1=CC=CC=C1C(=O)O",
            "isomeric_smiles": "CC(=O)OC1=CC=CC=C1C(=O)O",
            "inchi": "InChI=1S/C9H8O4/c1-6(10)13-8-5-3-2-4-7(8)9(11)12/h2-5H,1H3,(H,11,12)",
            "inchikey": "BSYNRYMUTXBXSQ-UHFFFAOYSA-N",
            "iupac_name": "2-acetoxybenzoic acid",
            "content_hash": "xyz789",
            "_run_id": "run_002",
            "_run_type": "incremental",
            "_source_batch_id": "batch_002",
            "_ingestion_ts": "2024-01-15T11:00:00Z",
        }

        table = pa.Table.from_pylist([valid_record], schema=PUBCHEM_COMPOUND_SCHEMA)

        assert table.num_rows == 1
        assert table.num_columns == len(PUBCHEM_COMPOUND_SCHEMA)

    def test_silver_schema_valid_uniprot(self):
        """UNIPROT_PROTEIN_SCHEMA должна валидировать корректные данные."""
        valid_record = {
            "entity_id": "P00533",
            "accession": "P00533",
            "entry_name": "EGFR_HUMAN",
            "protein_name": "Epidermal growth factor receptor",
            "gene_names": ["EGFR", "ERBB1"],
            "organism_id": 9606,
            "sequence_length": 1210,
            "content_hash": "hash123",
            "_run_id": "run_003",
            "_run_type": "incremental",
            "_source_batch_id": "batch_003",
            "_ingestion_ts": "2024-01-15T12:00:00Z",
        }

        table = pa.Table.from_pylist([valid_record], schema=UNIPROT_PROTEIN_SCHEMA)

        assert table.num_rows == 1
        assert table.num_columns == len(UNIPROT_PROTEIN_SCHEMA)

    def test_silver_schema_rejects_invalid(self):
        """Silver schema должна отклонять некорректные данные."""
        # Invalid record: wrong types for numeric fields
        invalid_record = {
            "entity_id": "ACT_12345",
            "content_hash": "abc123",
            "activity_id": "12345",
            "molecule_chembl_id": "CHEMBL25",
            "target_chembl_id": "CHEMBL1824",
            "assay_chembl_id": "CHEMBL829232",
            "document_chembl_id": "CHEMBL1122334",
            "record_id": "not_an_integer",  # Should be int64
            "src_id": "not_an_integer",  # Should be int64
            "value": "not_a_float",  # Should be float64
            "standard_value": "not_a_float",  # Should be float64
            "_run_id": "run_001",
            "_run_type": "incremental",
            "_source_batch_id": "batch_001",
            "_ingestion_ts": "2024-01-15T10:30:00Z",
        }

        with pytest.raises((pa.ArrowInvalid, pa.ArrowTypeError)):
            pa.Table.from_pylist([invalid_record], schema=CHEMBL_ACTIVITY_SCHEMA)

    def test_silver_schema_rejects_wrong_list_type(self):
        """Silver schema должна отклонять некорректный тип списка."""
        # Invalid: gene_names should be list of strings, not list of ints
        invalid_record = {
            "entity_id": "P00533",
            "accession": "P00533",
            "entry_name": "EGFR_HUMAN",
            "protein_name": "Epidermal growth factor receptor",
            "gene_names": [123, 456],  # Should be list of strings
            "organism_id": 9606,
            "sequence_length": 1210,
            "content_hash": "hash123",
            "_run_id": "run_003",
            "_run_type": "incremental",
            "_source_batch_id": "batch_003",
            "_ingestion_ts": "2024-01-15T12:00:00Z",
        }

        with pytest.raises((pa.ArrowInvalid, pa.ArrowTypeError)):
            pa.Table.from_pylist([invalid_record], schema=UNIPROT_PROTEIN_SCHEMA)

    def test_silver_schema_allows_null_values(self):
        """Silver schema должна допускать NULL значения для необязательных полей."""
        # Record with many null values - should be valid
        minimal_record = {
            "entity_id": "ACT_12345",
            "content_hash": "abc123",
            "activity_id": "12345",
            "molecule_chembl_id": None,
            "target_chembl_id": None,
            "assay_chembl_id": None,
            "document_chembl_id": None,
            "record_id": None,
            "src_id": None,
            "canonical_smiles": None,
            "molecule_pref_name": None,
            "parent_molecule_chembl_id": None,
            "target_pref_name": None,
            "target_organism": None,
            "target_tax_id": None,
            "assay_type": None,
            "assay_description": None,
            "assay_variant_accession": None,
            "assay_variant_mutation": None,
            "bao_endpoint": None,
            "bao_format": None,
            "bao_label": None,
            "type": None,
            "value": None,
            "units": None,
            "relation": None,
            "upper_value": None,
            "text_value": None,
            "standard_type": None,
            "standard_value": None,
            "standard_units": None,
            "standard_relation": None,
            "standard_upper_value": None,
            "standard_text_value": None,
            "standard_flag": None,
            "pchembl_value": None,
            "ligand_efficiency_bei": None,
            "ligand_efficiency_le": None,
            "ligand_efficiency_lle": None,
            "ligand_efficiency_sei": None,
            "qudt_units": None,
            "uo_units": None,
            "document_journal": None,
            "document_year": None,
            "activity_comment": None,
            "data_validity_comment": None,
            "data_validity_description": None,
            "potential_duplicate": None,
            "action_type_action_type": None,
            "action_type_description": None,
            "action_type_parent_type": None,
            "activity_properties": None,
            "toid": None,
            "_run_id": "run_001",
            "_run_type": "incremental",
            "_source_batch_id": "batch_001",
            "_ingestion_ts": "2024-01-15T10:30:00Z",
        }

        # Should succeed with null values
        table = pa.Table.from_pylist([minimal_record], schema=CHEMBL_ACTIVITY_SCHEMA)
        assert table.num_rows == 1

    @pytest.mark.parametrize(
        "schema,primary_key,invalid_pk_value",
        [
            (CHEMBL_ACTIVITY_SCHEMA, "activity_id", 12345),  # Should be string
            (CHEMBL_ASSAY_SCHEMA, "assay_chembl_id", 12345),  # Should be string
            (PUBCHEM_COMPOUND_SCHEMA, "cid", 2244),  # Should be string
        ],
    )
    def test_silver_schema_rejects_invalid_primary_key_type(
        self, schema, primary_key, invalid_pk_value
    ):
        """Silver schema должна отклонять некорректный тип первичного ключа."""
        # Build minimal record with required system fields
        record = {
            "entity_id": "test",
            "content_hash": "hash",
            primary_key: invalid_pk_value,  # Wrong type - should be string
            "_run_id": "run",
            "_run_type": "incremental",
            "_source_batch_id": "batch",
            "_ingestion_ts": "2024-01-01T00:00:00Z",
        }

        with pytest.raises((pa.ArrowInvalid, pa.ArrowTypeError)):
            pa.Table.from_pylist([record], schema=schema)
