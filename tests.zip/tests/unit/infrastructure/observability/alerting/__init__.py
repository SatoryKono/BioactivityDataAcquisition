"""Tests for alerting module."""
