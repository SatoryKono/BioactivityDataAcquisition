"""Tests for CrossRef adapter."""
