"""Unit tests for CrossRef Transformer.

Tests for CrossRefTransformer (domain entity creation from Bronze records).

Note: Field extraction tests now use domain functions directly per REFACTOR-004.
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from bioetl.application.pipelines.crossref.transformer import CrossRefTransformer
from bioetl.domain.context import PipelineContext
from bioetl.domain.entities.crossref import CROSSREF_TYPE_MAP
from bioetl.domain.normalization import extract_first_string, normalize_doi
from bioetl.domain.types import RunID, RunType


@pytest.fixture
def transformer():
    """Create a CrossRefTransformer instance."""
    return CrossRefTransformer()


@pytest.fixture
def pipeline_context(noop_logger):
    """Create a minimal PipelineContext for testing."""
    return PipelineContext.create(
        run_id=RunID(uuid4()),
        run_type=RunType.INCREMENTAL,
        logger=noop_logger,
        started_at=datetime.now(UTC),
    )


@pytest.fixture
def sample_publication():
    """Create a sample CrossRef publication response."""
    return {
        "DOI": "10.1234/test.article",
        "title": ["Test Article Title"],
        "abstract": "<p>This is the <b>abstract</b> text.</p>",
        "author": [
            {"given": "John", "family": "Doe"},
            {"given": "Jane", "family": "Smith"},
            {"family": "Anonymous"},
        ],
        "container-title": ["Journal of Testing"],
        "ISSN": ["1234-5678", "8765-4321"],
        "publisher": "Test Publisher Inc.",
        "volume": "42",
        "issue": "3",
        "page": "123-145",
        "published-print": {"date-parts": [[2023, 6, 15]]},
        "published-online": {"date-parts": [[2023, 5, 1]]},
        "type": "journal-article",
        "is-referenced-by-count": 100,
        "references-count": 50,
        "language": "en",
        "license": [{"URL": "https://creativecommons.org/licenses/by/4.0/"}],
        "subject": ["Computer Science", "Information Systems"],
    }


@pytest.fixture
def minimal_publication():
    """Create a minimal CrossRef publication response."""
    return {
        "DOI": "10.5678/minimal",
        "type": "posted-content",
    }


# =============================================================================
# Field extraction tests (delegated to domain functions per REFACTOR-004)
# =============================================================================


def test_normalize_doi():
    """Test DOI normalization using domain function."""
    assert normalize_doi("10.1234/ABC.DEF") == "10.1234/abc.def"
    assert normalize_doi("  10.1234/test  ") == "10.1234/test"


def test_extract_title(sample_publication):
    """Test title extraction using domain function."""
    assert (
        extract_first_string(sample_publication.get("title", []))
        == "Test Article Title"
    )
    assert extract_first_string([]) is None


def test_extract_authors(transformer, sample_publication):
    """Test author extraction (CrossRef-specific logic)."""
    authors = transformer._extract_authors(sample_publication)
    assert authors == ["John Doe", "Jane Smith", "Anonymous"]


def test_extract_year(transformer, sample_publication):
    """Test year extraction (CrossRef-specific logic)."""
    assert transformer._extract_year(sample_publication) == 2023
    assert transformer._extract_year({}) is None


def test_map_doc_type():
    """Test document type mapping using domain constant."""
    assert CROSSREF_TYPE_MAP.get("journal-article", "PUBLICATION") == "PUBLICATION"
    assert CROSSREF_TYPE_MAP.get("posted-content", "PUBLICATION") == "PREPRINT"
    assert CROSSREF_TYPE_MAP.get("unknown", "PUBLICATION") == "PUBLICATION"


# =============================================================================
# Business data extraction tests
# =============================================================================


def test_extract_business_data_full(transformer, sample_publication):
    """Test extracting business data from full work record."""
    data = transformer._extract_business_data(sample_publication)

    assert data["doi"] == "10.1234/test.article"
    assert data["title"] == "Test Article Title"
    assert data["abstract"] == "This is the abstract text."
    assert data["authors"] == ["John Doe", "Jane Smith", "Anonymous"]
    assert data["journal"] == "Journal of Testing"
    assert data["year"] == 2023
    assert data["doc_type"] == "PUBLICATION"
    assert data["citation_count"] == 100
    assert data["source"] == "crossref"


def test_extract_business_data_minimal(transformer, minimal_publication):
    """Test extracting business data from minimal work record."""
    data = transformer._extract_business_data(minimal_publication)

    assert data["doi"] == "10.5678/minimal"
    assert data["title"] is None
    assert data["doc_type"] == "PREPRINT"
    assert data["source"] == "crossref"


# =============================================================================
# Transformation tests
# =============================================================================


@pytest.mark.asyncio
async def test_transform_full_record(transformer, pipeline_context, sample_publication):
    """Test transforming full work record to SilverRecord."""
    result = await transformer.transform(pipeline_context, sample_publication, index=0)

    assert result is not None
    assert result["doi"] == "10.1234/test.article"
    assert result["title"] == "Test Article Title"
    assert result["doc_type"] == "PUBLICATION"
    assert result["source"] == "crossref"
    # Check lineage fields
    assert "_run_id" in result
    assert "_run_type" in result
    assert "_ingestion_ts" in result
    assert "content_hash" in result


@pytest.mark.asyncio
async def test_transform_minimal_record(
    transformer, pipeline_context, minimal_publication
):
    """Test transforming minimal work record to SilverRecord."""
    result = await transformer.transform(pipeline_context, minimal_publication, index=1)

    assert result is not None
    assert result["doi"] == "10.5678/minimal"
    assert result["doc_type"] == "PREPRINT"


@pytest.mark.asyncio
async def test_transform_missing_doi_returns_none(transformer, pipeline_context):
    """Test that missing DOI results in None (skipped record)."""
    invalid_work = {"title": ["No DOI"]}
    result = await transformer.transform(pipeline_context, invalid_work, index=0)

    assert result is None


# =============================================================================
# Provider and entity type tests
# =============================================================================


def test_provider_is_crossref(transformer):
    """Test provider is set to crossref."""
    assert transformer.provider == "crossref"


def test_entity_type_is_publication(transformer):
    """Test entity type is set to publication (Ubiquitous Language, not CrossRef 'work')."""
    assert transformer.entity_type == "publication"
