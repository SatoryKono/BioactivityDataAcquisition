"""Tests for domain aggregates."""
