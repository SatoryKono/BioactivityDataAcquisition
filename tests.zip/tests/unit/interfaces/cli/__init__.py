"""Tests for CLI interfaces."""
