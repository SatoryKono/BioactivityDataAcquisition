"""Integration tests for the UniProt Protein pipeline.

Тестирует E2E трансформации и интеграцию с инфраструктурой.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from bioetl.application.core.pipeline_services import PipelineServices
from bioetl.application.pipelines.uniprot.protein import UniProtProteinPipeline
from bioetl.application.pipelines.uniprot.transformer import UniProtProteinTransformer
from bioetl.domain.config import PipelineConfig, RuntimeConfig
from bioetl.domain.context import PipelineContext
from bioetl.domain.types import RunType


@pytest.fixture
def uniprot_config() -> PipelineConfig:
    """Создаёт конфигурацию UniProt пайплайна."""
    return PipelineConfig(
        pipeline_name="uniprot_protein",
        provider="uniprot",
        entity_type="protein",
        primary_keys=["accession"],
        silver_table="uniprot.protein",
        gold_table="uniprot.protein_gold",
        batch_size=100,
        checkpoint_interval=1000,
        fields=[
            "accession",
            "entry_name",
            "protein_name",
            "gene_names",
            "organism_id",
            "sequence_length",
        ],
    )


@pytest.fixture
def uniprot_runtime() -> RuntimeConfig:
    """Создаёт runtime конфигурацию."""
    return RuntimeConfig(
        run_type=RunType.INCREMENTAL,
        resume=False,
        limit=None,
    )


@pytest.fixture
def mock_uniprot_services(mock_logger) -> PipelineServices:
    """Создаёт mock сервисы для тестирования."""
    mock_data_source = AsyncMock()
    mock_data_source.provider_name = "uniprot"
    mock_data_source.aclose = AsyncMock()

    mock_storage = AsyncMock()
    mock_storage.write_bronze = AsyncMock()
    mock_storage.write_silver = AsyncMock()
    mock_storage.write_gold = AsyncMock()
    mock_storage.aclose = AsyncMock()

    mock_lock = AsyncMock()
    mock_lock.acquire = AsyncMock(return_value=True)
    mock_lock.release = AsyncMock()

    mock_checkpoint = AsyncMock()
    mock_checkpoint.get_latest = AsyncMock(return_value=None)
    mock_checkpoint.save = AsyncMock()

    mock_quarantine = AsyncMock()
    mock_metrics = MagicMock()

    import structlog

    logger = structlog.get_logger()

    mock_tracing = MagicMock()

    return PipelineServices(
        data_source=mock_data_source,
        storage=mock_storage,
        lock=mock_lock,
        checkpoint=mock_checkpoint,
        quarantine=mock_quarantine,
        metrics=mock_metrics,
        tracing=mock_tracing,
        logger=logger,
    )


@pytest.fixture
def mock_logger():
    """Создаёт mock логгер."""
    logger = MagicMock()
    logger.bind = MagicMock(return_value=logger)
    return logger


@pytest.mark.integration
class TestUniProtProteinPipelineTransform:
    """Тесты трансформации UniProt пайплайна."""

    async def test_transform_bronze_to_silver_complete_record(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест трансформации полной записи Bronze → Silver."""
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        # Full UniProt record structure
        bronze_record = {
            "primaryAccession": "P12345",
            "uniProtkbId": "MYC_HUMAN",
            "proteinDescription": {
                "recommendedName": {"fullName": {"value": "Myc proto-oncogene protein"}}
            },
            "genes": [
                {"geneName": {"value": "MYC"}},
                {"geneName": {"value": "BHLHE39"}},
            ],
            "organism": {"taxonId": 9606},
            "sequence": {"length": 439, "value": "MDFFRVVENQQPPATMPLNVSFTNRNYDLDYD..."},
        }

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is not None
        assert silver_record["accession"] == "P12345"
        assert silver_record["entry_name"] == "MYC_HUMAN"
        assert silver_record["protein_name"] == "Myc proto-oncogene protein"
        assert silver_record["gene_names"] == ["MYC", "BHLHE39"]
        assert silver_record["organism_id"] == 9606
        assert silver_record["sequence_length"] == 439
        assert "entity_id" in silver_record
        assert "content_hash" in silver_record
        assert "_run_id" in silver_record

    async def test_transform_bronze_to_silver_minimal_record(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест трансформации минимальной записи с обязательными полями.

        Protein entity requires: accession, entry_name.
        Optional fields: protein_name, gene_names, organism_id, sequence_length.
        """
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        # Minimal valid record with only required fields (accession, entry_name)
        bronze_record = {
            "primaryAccession": "Q99999",
            "uniProtkbId": "TEST_HUMAN",
            # No proteinDescription - protein_name will be None
        }

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is not None
        assert silver_record["accession"] == "Q99999"
        assert silver_record["entry_name"] == "TEST_HUMAN"
        assert silver_record["protein_name"] is None
        assert silver_record["gene_names"] == []
        assert silver_record["organism_id"] is None
        assert silver_record["sequence_length"] is None
        assert "entity_id" in silver_record
        assert "content_hash" in silver_record
        assert "_run_id" in silver_record

    async def test_transform_bronze_to_silver_missing_accession_returns_none(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест: запись без primaryAccession возвращает None."""
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        bronze_record = {"uniProtkbId": "NO_ACCESSION"}  # No primaryAccession

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is None

    async def test_transform_bronze_to_silver_missing_protein_description_accepted(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест: запись без proteinDescription успешно обрабатывается.

        protein_name is optional, so records without
        proteinDescription.recommendedName.fullName.value are accepted.
        """
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        bronze_record = {
            "primaryAccession": "A0A000",
            "uniProtkbId": "UNKNOWN_HUMAN",
            "genes": [{"geneName": {"value": "GENE1"}}],
            "organism": {"taxonId": 9606},
            "sequence": {"length": 100},
            # Missing: proteinDescription - this is OK, protein_name is optional
        }

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is not None
        assert silver_record["accession"] == "A0A000"
        assert silver_record["protein_name"] is None
        assert silver_record["gene_names"] == ["GENE1"]
        assert "entity_id" in silver_record
        assert "_run_id" in silver_record

    async def test_transform_bronze_to_silver_empty_genes(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест трансформации записи с пустым списком генов."""
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        bronze_record = {
            "primaryAccession": "B0B000",
            "uniProtkbId": "NOGENE_HUMAN",
            "proteinDescription": {
                "recommendedName": {"fullName": {"value": "No Gene Protein"}}
            },
            "genes": [],
        }

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is not None
        assert silver_record["gene_names"] == []
        assert "_run_id" in silver_record


@pytest.mark.integration
class TestUniProtProteinPipelineCreate:
    """Тесты создания UniProt пайплайна."""

    def test_create_pipeline(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест создания пайплайна через factory method."""
        run_id = uuid4()
        pipeline = UniProtProteinPipeline.create(
            run_id=run_id,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            config=uniprot_config,
        )

        assert pipeline is not None
        assert isinstance(pipeline, UniProtProteinPipeline)
        assert pipeline.config == uniprot_config


@pytest.mark.integration
class TestUniProtProteinPipelineEdgeCases:
    """Тесты граничных случаев UniProt пайплайна."""

    async def test_transform_with_malformed_genes(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест трансформации с некорректной структурой genes."""
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        # Malformed genes - some missing geneName
        bronze_record = {
            "primaryAccession": "X00001",
            "uniProtkbId": "MALFORM_HUMAN",
            "proteinDescription": {
                "recommendedName": {"fullName": {"value": "Malformed Genes Protein"}}
            },
            "genes": [
                {"geneName": {"value": "VALID"}},
                {"otherField": "no geneName"},
                {"geneName": {}},  # Empty geneName
            ],
        }

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is not None
        # Should only include valid gene names
        assert "VALID" in silver_record["gene_names"]
        assert "_run_id" in silver_record

    async def test_transform_with_none_organism(
        self,
        uniprot_config,
        uniprot_runtime,
        mock_uniprot_services,
    ):
        """Тест трансформации с None organism."""
        run_id = uuid4()
        pipeline = UniProtProteinPipeline(
            config=uniprot_config,
            runtime=uniprot_runtime,
            services=mock_uniprot_services,
            run_id=run_id,
            transformer=UniProtProteinTransformer(provider="uniprot"),
        )

        context = PipelineContext(
            run_id=uuid4(),
            run_type=RunType.INCREMENTAL,
            logger=mock_uniprot_services.logger,
        )

        bronze_record = {
            "primaryAccession": "Y00001",
            "uniProtkbId": "NOORG_HUMAN",
            "proteinDescription": {
                "recommendedName": {"fullName": {"value": "No Organism Protein"}}
            },
            "organism": None,
        }

        silver_record = await pipeline.transform_bronze_to_silver(
            context, bronze_record
        )

        assert silver_record is not None
        assert silver_record["organism_id"] is None
        assert "_run_id" in silver_record
