"""Extend the original-image search to Grafana evidence in every local worktree."""
import hashlib
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

root = Path.cwd().resolve()
os.environ.update(GIT_CONFIG_COUNT="1", GIT_CONFIG_KEY_0="safe.directory", GIT_CONFIG_VALUE_0=root.as_posix())
audit = root / "reports/audit/issue-10186"
original_review = Path("E:/github/BioactivityDataAcquisition/reports/audit/grafana/issue-10186-closeout/historical-provenance-review.json")
report = json.loads(original_review.read_text())
wanted = {row["expected_png_sha256"] for row in report["dashboards"] if not row["matches"]}
worktrees = [Path(line.removeprefix("worktree ")) for line in subprocess.check_output(["git", "worktree", "list", "--porcelain"], text=True).splitlines() if line.startswith("worktree ")]
inventory, matches, failures, searched = [], [], [], []
for worktree in worktrees:
    for relative in ["reports/audit/grafana", "reports/observability"]:
        directory = worktree / relative
        if not directory.is_dir():
            continue
        searched.append(str(directory))
        for target in sorted(directory.rglob("*.png")):
            try:
                before = target.stat()
                with target.open("rb") as handle:
                    sha = hashlib.file_digest(handle, "sha256").hexdigest()
                after = target.stat()
                assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
                item = {"path":str(target), "sha256":sha, "bytes":after.st_size}
                inventory.append(item)
                if sha in wanted:
                    matches.append(item)
            except (OSError, AssertionError) as exc:
                failures.append({"path":str(target), "reason":type(exc).__name__})
report.update(checked_at=datetime.now(UTC).isoformat(), initial_review_checked_at=report["checked_at"],
              searched_roots=searched, pngs_searched=len(inventory), matching_originals=matches,
              read_failures=failures, local_worktrees_considered=len(worktrees))
index = audit / "historical-png-search-index.json"
index.write_text(json.dumps(inventory, indent=2), encoding="utf-8")
report["search_index_sha256"] = hashlib.sha256(index.read_bytes()).hexdigest()
(audit / "historical-provenance-review-expanded.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps({"searched_pngs":len(inventory), "searched_directories":len(searched), "worktrees":len(worktrees), "matching_originals":matches, "read_failures":failures}))
