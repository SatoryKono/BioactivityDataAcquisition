"""Recheck originals without changing any historical evidence."""
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
OLD = ROOT / 'reports/audit/grafana/2026-09-04T17-00-00Z/visual'
manifest_path = OLD / 'render-manifest--full-set--2026-09-04T17-00-00Z.json'
manifest = json.loads(manifest_path.read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rows = []
for dashboard in manifest['dashboards']:
    target = OLD / dashboard['file']
    expected = dashboard['screenshotEvidence']['sha256']
    actual = digest(target) if target.exists() else None
    rows.append({'uid': dashboard['uid'], 'expected_png_sha256': expected,
                 'actual_png_sha256': actual, 'matches': actual == expected})
wanted = {r['expected_png_sha256'] for r in rows if not r['matches']}
roots = [ROOT / 'reports/audit/grafana', ROOT / 'reports/observability']
matches = []
count = 0
for root in roots:
    for target in root.rglob('*.png'):
        count += 1
        sha = digest(target)
        if sha in wanted:
            matches.append({'path': target.relative_to(ROOT).as_posix(), 'sha256': sha})
result = {'checked_at': datetime.now(UTC).isoformat(),
          'historical_manifest': manifest_path.relative_to(ROOT).as_posix(),
          'historical_manifest_sha256': digest(manifest_path), 'dashboards': rows,
          'searched_roots': [p.relative_to(ROOT).as_posix() for p in roots],
          'pngs_searched': count, 'matching_originals': matches,
          'historical_acceptance': 'REJECTED', 'root_cause': 'UNKNOWN',
          'reason': 'PNG bytes disagree with immutable manifest; write-event history unavailable.'}
output = Path(__file__).with_name('historical-provenance-review.json')
output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
