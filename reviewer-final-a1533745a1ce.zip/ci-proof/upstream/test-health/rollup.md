# Test Health Rollup

Historical test-health evidence for recent recorded lane runs.

Runs analyzed: 9

## Current Authoritative Baseline

- Current merge-blocking truth comes from live CI status and the `coverage-verify` hard coverage gate.
- This rollup is historical evidence only and must not be read as the current pass/fail baseline.
- Committed baseline artifact: `configs/quality/test_telemetry_baseline.yaml`
- Source branch: `main`
- Source commit: `5c69cbb40942086db5bd48922ebd147ffd45f35f`
- Source run id: `34251820402`
- Refresh status: `captured`
- Coverage baseline: `96.71%` (threshold `85.0%`)
- Duration telemetry cases: `49958`

## Suites

| Suite | Runs | Non-green | Pass rate | Test failures | Unique failing tests | Skipped |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| contracts | 1 | 0 | 100.0% | 0 | 0 | 20 |
| integration-replay | 1 | 0 | 100.0% | 0 | 0 | 123 |
| memory | 1 | 0 | 100.0% | 0 | 0 | 0 |
| repo-backed-unit | 1 | 0 | 100.0% | 0 | 0 | 7 |
| security | 1 | 0 | 100.0% | 0 | 0 | 0 |
| serial-coverage | 1 | 0 | 100.0% | 0 | 0 | 2 |
| track-d | 1 | 0 | 100.0% | 0 | 0 | 0 |
| unit-fast | 1 | 0 | 100.0% | 0 | 0 | 30 |
| unit-scripts-tooling | 1 | 0 | 100.0% | 0 | 0 | 4 |
