# #10186 — reviewer evidence

Source commit: `a1533745a1ce7647f6a1fe55d12741e25bda1982`.
Immutable manifest: `capture/render-manifest--full-set--issue-10186-a1533745a1ce-20260908T174534Z.json`.
Manifest SHA-256: `9daa8be78d574b50f355a7ba3c1b09dd8c7f20365d6686763f1e02a747860438`.

Provenance PASS: 7/7 dashboards, with source JSON, bracketing API models,
browser-loaded models, observed URL/context and PNG in one capture occurrence.
Only root Grafana `id` and `version` are normalized; panel/query content is compared.
32 actual corruption/substitution/control cases passed on copies of this capture.
The original capture stayed unchanged. Acceptance selects the explicit immutable file.

Historical pack: REJECTED. Trust, DQ and Overview PNG disagree with the immutable
manifest. No matching originals were found among 8378 available PNG files in
197 evidence directories across 181 registered local worktrees; no read failures.
Root cause remains UNKNOWN. Original expected hashes are preserved.

This is provenance acceptance only. Layout, contrast, reflow and data correctness
retain their separate verdicts. The viewport capture preserves renderer layout
errors where panels fall outside the first screen; these are not converted to PASS.
The separately published `reviewer-layout-10165.zip` contains the independently
verified 7/7 expanded-dashboard occurrence from #10165 and its source Git bundle.

## Reproduce

Check out commit `a1533745a1ce7647f6a1fe55d12741e25bda1982` in a clone of SatoryKono/BioactivityDataAcquisition.
Extract this archive outside that checkout, then run from the checkout root:

```shell
python -m scripts.ops.observability.grafana.check_grafana_dashboard_audit_preflight --immutable-manifest /absolute/path/capture/render-manifest--full-set--issue-10186-a1533745a1ce-20260908T174534Z.json --manifest-sha256 9daa8be78d574b50f355a7ba3c1b09dd8c7f20365d6686763f1e02a747860438 --expected-commit a1533745a1ce7647f6a1fe55d12741e25bda1982 --acceptance-scope provenance --json
python /absolute/path/negative-controls.py /absolute/path/capture/render-manifest--full-set--issue-10186-a1533745a1ce-20260908T174534Z.json /absolute/path/new-empty-negative-output
```

Python and repository dependencies must be available. Verification does not need
Grafana, network access or credentials. `file-index.json` lists archive member
hashes; compare the ZIP SHA-256 with the separately published archive index.
`ci-proof` is the original GitHub Actions attestation, with its source SHA and run ID.
Local validations and their source identities are recorded separately.
The owner's initial 22-note approval, separate 5-note approval, conditional
21-file approval and actual deletion receipts are included. Conditional approval
permits deletion only after each listed expiry during this active closeout.
The byte-preserving backup ZIPs remain local and deleted files are in Git history.

## Local validation receipts

| Check | Exit code | Source SHA |
|---|---:|---|
| tests | 0 | `a1533745a1ce7647f6a1fe55d12741e25bda1982` |
| governance | 0 | `a1533745a1ce7647f6a1fe55d12741e25bda1982` |
| docs_runtime | 0 | `a1533745a1ce7647f6a1fe55d12741e25bda1982` |
| debt | 0 | `a1533745a1ce7647f6a1fe55d12741e25bda1982` |

Local governance logs retain their actual result. Every retention deletion is limited to an explicit owner-approved list and actual expiry; no TTL or budget was increased. Failures are not relabelled PASS by provenance acceptance or by the separate CI attestation.
