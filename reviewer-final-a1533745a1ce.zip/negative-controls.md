# Evidence integrity controls

| Case | Expected | Observed |
|---|---|---|
| `missing_png` | FAIL | FAIL |
| `corrupt_png` | FAIL | FAIL |
| `rehashed_truncation` | FAIL | FAIL |
| `rehashed_wrong_pixels` | FAIL | FAIL |
| `wrong_source` | FAIL | FAIL |
| `wrong_provisioned_before` | FAIL | FAIL |
| `wrong_provisioned_loaded` | FAIL | FAIL |
| `wrong_provisioned_after` | FAIL | FAIL |
| `cross_occurrence` | FAIL | FAIL |
| `subset` | FAIL | FAIL |
| `wrong_file_count` | FAIL | FAIL |
| `wrong_file_set` | FAIL | FAIL |
| `shifted_browser_time` | FAIL | FAIL |
| `wrong_variable` | FAIL | FAIL |
| `wrong_device_scale` | FAIL | FAIL |
| `wrong_css_viewport` | FAIL | FAIL |
| `wrong_css_height` | FAIL | FAIL |
| `root_zoom` | FAIL | FAIL |
| `visual_scale` | FAIL | FAIL |
| `timezone` | FAIL | FAIL |
| `undeclared_variable` | FAIL | FAIL |
| `kiosk_chrome` | FAIL | FAIL |
| `pinned_self_consistent_replacement` | FAIL | FAIL |
| `latest_pointer_moved` | PASS | PASS |
| `null_screenshot_metadata` | FAIL | FAIL |
| `list_screenshot_metadata` | FAIL | FAIL |
| `string_screenshot_metadata` | FAIL | FAIL |
| `rehashed_deflate_excess` | FAIL | FAIL |
| `rehashed_bad_ihdr` | FAIL | FAIL |
| `wrong_requested_rows` | FAIL | FAIL |
| `missing_row_inventory` | FAIL | FAIL |
| `contradictory_row_click` | FAIL | FAIL |
