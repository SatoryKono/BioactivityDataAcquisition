"""Exercise corruption and substitution against copies of a real capture."""
import copy
import hashlib
import json
import os
import shutil
import struct
import sys
import zlib
from datetime import UTC, datetime
from pathlib import Path

root = Path.cwd().resolve()
sys.path.insert(0, str(root))
os.environ.update(GIT_CONFIG_COUNT="1", GIT_CONFIG_KEY_0="safe.directory", GIT_CONFIG_VALUE_0=root.as_posix())
from scripts.ops.observability.grafana.capture_provenance import verify_capture

manifest_path = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
original = manifest_path.read_bytes()
manifest = json.loads(original)
pin = hashlib.sha256(original).hexdigest()
commit = manifest["source"]["commit_sha"]
baseline = verify_capture(manifest_path, repo_root=root, expected_sha256=pin, expected_commit=commit)
assert baseline["status"] == "PASS", baseline
results = []
cases = ["missing_png", "corrupt_png", "rehashed_truncation", "rehashed_wrong_pixels", "wrong_source", "wrong_provisioned_before", "wrong_provisioned_loaded", "wrong_provisioned_after", "cross_occurrence", "subset", "wrong_file_count", "wrong_file_set", "shifted_browser_time", "wrong_variable", "wrong_device_scale", "wrong_css_viewport", "wrong_css_height", "root_zoom", "visual_scale", "timezone", "undeclared_variable", "kiosk_chrome", "pinned_self_consistent_replacement", "latest_pointer_moved"]
cases += ["null_screenshot_metadata", "list_screenshot_metadata", "string_screenshot_metadata", "rehashed_deflate_excess", "rehashed_bad_ihdr", "wrong_requested_rows", "missing_row_inventory", "contradictory_row_click"]
for case in cases:
    directory = out / case
    shutil.copytree(manifest_path.parent, directory)
    candidate = directory / manifest_path.name
    payload = copy.deepcopy(manifest)
    dashboard = payload["dashboards"][0]
    png = directory / dashboard["file"]
    if case == "missing_png":
        png.unlink()
    elif case in {"corrupt_png", "rehashed_truncation", "rehashed_wrong_pixels"}:
        raw = png.read_bytes()
        if case == "corrupt_png":
            raw = raw[:80] + bytes([raw[80] ^ 1]) + raw[81:]
        elif case == "rehashed_truncation":
            raw = raw[:40]
        else:
            header = raw[12:16] + struct.pack(">I", 1367) + raw[20:29]
            raw = raw[:12] + header + struct.pack(">I", zlib.crc32(header)) + raw[33:]
        png.write_bytes(raw)
        if case != "corrupt_png":
            dashboard["screenshotEvidence"].update(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    elif case == "wrong_source":
        dashboard["dashboardSource"]["sha256"] = "0" * 64
    elif case.startswith("wrong_provisioned_"):
        phase = case.removeprefix("wrong_provisioned_")
        model = dashboard["provisionedModel"][phase]
        if phase == "loaded":
            model = model[0]
        model["title"] += " substituted"
    elif case == "cross_occurrence":
        dashboard["provisionedModel"]["captureId"] = "other-occurrence"
    elif case == "subset":
        payload["dashboards"].pop()
    elif case == "wrong_file_count":
        payload["file_count"] -= 1
    elif case == "wrong_file_set":
        payload["file_set"].pop()
    elif case == "shifted_browser_time":
        from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
        url = urlsplit(dashboard["provisionedModel"]["observedUrl"])
        query = dict(parse_qsl(url.query))
        query["from"] = str(int(payload["capture_context"]["time_range"]["from"]) + 1)
        dashboard["provisionedModel"]["observedUrl"] = urlunsplit(url._replace(query=urlencode(query)))
    elif case == "wrong_variable":
        dashboard["provisionedModel"]["observedUrl"] += "&var-run_id=substituted"
    elif case == "wrong_device_scale":
        dashboard["browserState"]["devicePixelRatio"] = 2
    elif case == "wrong_css_viewport":
        dashboard["browserState"]["layoutViewport"]["width"] = 1000
    elif case == "wrong_css_height":
        dashboard["browserState"]["layoutViewport"]["height"] = 100
    elif case == "root_zoom":
        dashboard["browserState"]["cssZoom"] = "2"
    elif case == "visual_scale":
        dashboard["browserState"]["visualViewportScale"] = 2
    elif case == "timezone":
        payload["capture_context"]["time_range"]["timezone"] = "Europe/Kiev"
        payload["scope_query"] = payload["scope_query"].replace("timezone=UTC", "timezone=Europe%2FKiev")
        for item in payload["dashboards"]:
            item["provisionedModel"]["observedUrl"] = item["provisionedModel"]["observedUrl"].replace("timezone=UTC", "timezone=Europe%2FKiev")
    elif case == "undeclared_variable":
        dashboard["provisionedModel"]["observedUrl"] += "&var-unknown_selector=foreign"
    elif case == "kiosk_chrome":
        payload["requested"]["kiosk_mode"] = "full"
        dashboard["browserState"]["actualKiosk"] = "full"
        dashboard["browserState"]["visibleGrafanaChrome"] = True
    elif case in {"null_screenshot_metadata", "list_screenshot_metadata", "string_screenshot_metadata"}:
        dashboard["screenshotEvidence"] = {"null_screenshot_metadata":None,"list_screenshot_metadata":[],"string_screenshot_metadata":"invalid"}[case]
    elif case in {"rehashed_deflate_excess", "rehashed_bad_ihdr"}:
        raw = png.read_bytes()
        if case == "rehashed_bad_ihdr":
            chunk = raw[12:29] + b"\0"
            raw = raw[:8] + struct.pack(">I",14) + chunk + struct.pack(">I",zlib.crc32(chunk)) + raw[33:]
        else:
            width,height,depth,color,*_ = struct.unpack(">IIBBBBB",raw[16:29])
            encoded = zlib.compress(b"\0" * ((1 + width * (3 if color == 2 else 4)) * height + 1))
            chunk = b"IDAT" + encoded
            raw = raw[:33] + struct.pack(">I",len(encoded)) + chunk + struct.pack(">I",zlib.crc32(chunk)) + raw[-12:]
        png.write_bytes(raw)
        dashboard["screenshotEvidence"].update(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
    elif case == "wrong_requested_rows":
        requested = not payload["expand_collapsed_rows"]
        payload["expand_collapsed_rows"] = requested
        payload["capture_context"]["row_state"]["expand_collapsed_rows"] = requested
    elif case == "missing_row_inventory":
        del dashboard["layoutGeometry"]["panelGeometry"]
    elif case == "contradictory_row_click":
        if payload["expand_collapsed_rows"]:
            dashboard["rowExpansion"][0]["clicked"] = False
        else:
            dashboard["rowExpansion"] = [{"title":"unexpected expansion", "clicked":True}]
    elif case == "pinned_self_consistent_replacement":
        payload["capture_id"] = "self-consistent-replacement"
        payload["immutable_manifest"] = "render-manifest--full-set--self-consistent-replacement.json"
        for item in payload["dashboards"]:
            item["provisionedModel"]["captureId"] = payload["capture_id"]
        candidate = directory / payload["immutable_manifest"]
    elif case == "latest_pointer_moved":
        (directory / "render-manifest.json").write_text('{"capture_id":"different-subset"}')
    if case != "latest_pointer_moved":
        candidate.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    result = verify_capture(candidate, repo_root=root, expected_commit=commit,
                            expected_sha256=pin if case == "pinned_self_consistent_replacement" else None)
    expected = "PASS" if case == "latest_pointer_moved" else "FAIL"
    assert result["status"] == expected, (case, result)
    results.append({"case":case, "expected":expected, "actual":result["status"], "errors":result["errors"], "dashboard_errors":[item for item in result["dashboards"] if item["errors"]]})
assert manifest_path.read_bytes() == original
assert verify_capture(manifest_path, repo_root=root, expected_sha256=pin, expected_commit=commit)["status"] == "PASS"
report = {"status":"PASS", "tested_at":datetime.now(UTC).isoformat(), "source_commit":commit,
          "manifest_sha256":pin, "baseline":baseline, "cases":results, "original_preserved":True}
(out / "negative-controls.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps({"status":"PASS", "cases":len(results), "manifest_sha256":pin}))
