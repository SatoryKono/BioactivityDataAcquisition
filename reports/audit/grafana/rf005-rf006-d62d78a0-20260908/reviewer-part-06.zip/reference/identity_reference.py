"""Independent compact identity expectations from immutable local artifacts."""
import hashlib
import json
from pathlib import Path
ROOT=Path('E:/github/BioactivityDataAcquisition')
OUT=Path(__file__).parent
RUN='b9d2eeff-8e4b-5678-ae32-b288ced27968'
MID='53230537-8841-5e0b-a972-f361077fc200'
anchors=[]
def artifact(relative,lines=False):
    p=ROOT/relative;b=p.read_bytes()
    anchors.append({'path':relative,'sha256':hashlib.sha256(b).hexdigest()})
    return [json.loads(s) for s in b.decode().splitlines()] if lines else json.loads(b)
m=artifact(f'data/output/control/run_manifest/{MID}.json')
ledger=artifact(f'data/output/control/run_ledger/{MID}.jsonl',True)
r=artifact(f'reports/run-reports/pipeline/chembl_assay/{RUN}/pipeline-run-report.json')
idx=artifact(f'data/output/checkpoints/.history/by_manifest/{MID}.json')
cp=artifact('data/output/checkpoints/'+idx['history_path'].replace('\\','/'))['metadata']
code=m['code_provenance'];launch=m['launch_context'];identity=r['identity']
assert m['run_id']==identity['run_id']==idx['run_id']==RUN
assert all(x['run_id']==RUN and x['manifest_id']==MID for x in ledger)
assert any(x['event_type']=='run_started' for x in ledger)
assert any(x['event_type']=='run_finished' and x['status']=='success' for x in ledger)
snapshots=[s for ref in m['source_refs'] for s in ref.get('input_snapshots',[])]
fields=('snapshot_id','content_hash','immutable_uri','query_fingerprint','storage_provider','object_bucket','object_key','object_version_id','etag','last_modified','captured_at')
normalized=[{k:str(s[k]).strip() for k in fields if s.get(k) is not None and str(s[k]).strip()} for s in snapshots]
normalized.sort(key=lambda s:tuple(s.get(k,'') for k in fields))
fp=hashlib.sha256(json.dumps({'input_snapshots':normalized},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
checkpoint_expected={'manifest_id':MID,'execution_fingerprint':m['execution_fingerprint'],'effective_config_hash':code['effective_config_hash'],'effective_config_artifact_id':code['effective_config_artifact_id'],'input_snapshot_fingerprint':fp}
checkpoint_checks={k:cp.get(k)==v for k,v in checkpoint_expected.items()}
assert all(checkpoint_checks.values()),checkpoint_checks
assert cp['input_snapshot_refs']==snapshots
assert not cp.get('composite_run_identity')
# Registry P0 applicability: this is a non-replay isolated run; parent/composite
# anchors are N/A. Every remaining graph anchor must be independently present.
assert launch['execution_context']=='isolated' and not launch['exact_replay']
required={k:m.get(k) for k in ('run_id','manifest_id','pipeline_name','provider','entity','run_type','execution_fingerprint')}
required.update({k:code.get(k) for k in ('git_commit','pipeline_version','effective_config_hash','effective_config_artifact_id','contract_ref','contract_version','contract_schema_hash')})
required.update(input_snapshot_identity_fingerprint=fp,input_snapshot_count=len(snapshots),checkpoint_anchor_status='OK',replay_mode=m['run_type'])
gap_count=sum(v in (None,'',[]) for v in required.values())
assert gap_count==0
assert all(s.get('snapshot_id') and s.get('content_hash') and s.get('immutable_uri') for s in snapshots)
assert m['replay_capability']=='exact_replay_supported' and launch['exact_replay_ready'] is True
expected={
 'Run ID [Pipeline]':RUN,'Manifest ID [Control Plane]':MID,
 'Provider.Entity [Version]':f"{m['provider']}.{m['entity']} [{code['pipeline_version']}]",
 'Contract [Schema]':f"{code['contract_ref']}.{code['contract_version']} [{code['contract_schema_hash']}]",
 'Execution [Type|Context|Git]':f"{m['run_type']} | {launch['execution_context']} | git={code['git_commit']}",
 'Resume|Dry run|Cached Bronze':' | '.join('Yes' if v else 'No' for v in (launch['resume'],launch['dry_run'],launch['cached_bronze']['enabled'])),
 'Replay [Capability.Mode]':'Yes [Supported.Backfill]',
 'Checkpoint [Anchors]':'OK','Identity Health [Gaps]':f'Complete [{gap_count} gaps]',
 'Status':identity['status'],'Started at':identity['started_at'],'Completed at':identity['completed_at'],'Duration seconds':str(identity['duration_seconds']),
 'Tracking coverage':r['tracking_coverage'],'Workflow ID':identity['workflow_id'],'Workflow Run ID':identity['workflow_run_id'],'Workflow Step ID':identity['workflow_step_id']}
receipt={'artifacts':anchors,'checkpoint_comparisons':checkpoint_checks,'snapshot_fingerprint':fp,'snapshot_count':len(snapshots),'applicable_graph_anchors':required,'graph_gap_count':gap_count,'scope':'Run identity and checkpoint compatibility; replay execution is not performed. Report started/completed times preserve report scope, ledger lifecycle times are separate.','expected_rows':[{'parameter':k,'value':v} for k,v in expected.items()]}
(OUT/'identity-artifact-reference.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
