"""Compare complete Grafana transforms with independently seeded inputs and files."""
import bisect
import hashlib
import json
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from reconcile import scalar_ref, prom_table_ref, frame_rows, project, canonical, http_ref
from identity_reference import expected as identity_expected

OUT=Path(__file__).parent
ROOT=Path('E:/github/BioactivityDataAcquisition')
def read(n):return json.loads((OUT/n).read_text(encoding='utf-8'))
captures=read('captures.json');transforms={r['id']:r for r in read('transformed-complete.json')}
manifest=read('input-manifest.json');persisted=read('persisted-references.json')
seeded={json.dumps(s['labels'],sort_keys=True):s for s in manifest['series']}
def value_at(s,at):
    samples=s['samples'];idx=bisect.bisect_right([x[0] for x in samples],at)-1
    if idx<0:return None
    t,v=samples[idx]
    return None if v=='STALE' or at-t>300000 else v
def validate_sources(item):
    checked=0
    for source in item['reference']['sources']:
        for row in source['body'].get('data',{}).get('result',[]):
            s=seeded[json.dumps(row['metric'],sort_keys=True)]
            for t,v in row.get('values',[row['value']] if 'value' in row else []):
                expected=value_at(s,int(float(t)*1000))
                assert expected is not None and abs(float(v)-expected)<1e-9,(item['id'],row['metric'],t,v,expected)
                checked+=1
    return checked

results=[]
for item in captures:
    # Positive numeric acceptance includes both 15-minute and 6-hour independent samples.
    if item['scenario'] not in ('normal-15m','normal-6h'):continue
    t=transforms[item['id']];calc=item['reference']['calculation'];status='PASS';note='';expected=None;actual=None;count=0
    try:
        assert item['status']==200
        assert 'error' not in t,t.get('error')
        if calc!='persisted_http':count=validate_sources(item)
        if item['uid']=='bioetl-runtime' and item['panel_id']==9102:
            expected={'Endpoint':1,'Baseline':0,'Rule age':10}
            actual={d['display']['title']:d['display']['numeric'] for d in t['displays']}
        elif item['panel']['type'] in ('stat','gauge'):
            expected=scalar_ref(item)
            displays=[d['display']['numeric'] for d in t['displays'] if d.get('name')!='No data']
            actual=displays[-1] if displays else None
        elif calc=='incident_top5':
            sources=[s for s in manifest['series'] if s['labels']['__name__'].startswith('bioetl_incident_ranked_')]
            source_rows=sorted([{**s['labels'],'Value':value_at(s,item['to'])} for s in sources],key=lambda r:-r['Value'])[:5]
            for rank,r in enumerate(source_rows,1):r.update(Rank=rank,confidence='UNVERIFIED',object=r['pipeline']+' / '+r['provider'],action_detail=r['action'])
            expected=project(source_rows,t['frames']);actual=frame_rows(t['frames'])
        elif calc=='route_top2':
            raw=item['reference']['sources'][0]['body']['data']['result'];groups={}
            for s in raw:
                labels={k:v for k,v in s['metric'].items() if k not in ('run_type','__name__')};key=json.dumps(labels,sort_keys=True)
                groups[key]=dict(labels,Value=max(groups.get(key,{}).get('Value',0),float(s['value'][1])))
            expected=project(sorted(groups.values(),key=lambda r:-r['Value'])[:2],t['frames']);actual=frame_rows(t['frames'])
        elif calc=='alert_history':
            # Entire expected time/label/value set is derived from our recorded write input,
            # including explicit stale NaN; range API cannot erase the reference markers.
            expected=[];actual=[]
            for s in manifest['series']:
                if s['labels']['__name__']!='ALERTS':continue
                labels={k:v for k,v in s['labels'].items() if k!='__name__'}
                for at in range(item['from'],item['to']+1,30000):
                    v=value_at(s,at)
                    if v is not None:expected.append(dict(labels,Time=at,Value=v*(2 if labels['alertstate']=='pending' else 1)))
            for f in t['frames']:
                times=next(x['values'] for x in f['fields'] if x['type']=='time')
                for field in [x for x in f['fields'] if x['type']=='number']:
                    labels={k:v for k,v in field['labels'].items() if k!='__name__'}
                    actual.extend(dict(labels,Time=at,Value=v) for at,v in zip(times,field['values']) if v is not None)
        elif calc=='persisted_http':
            expected,note=http_ref(item,persisted);actual=frame_rows(t['frames']);count=len(actual)
            if item['panel_id'] in (9403,3023):actual={r['parameter'].split(' ',1)[1]:int(r['value'].replace(' ','')) for r in actual}
            else:expected=project(expected,t['frames']) if expected is not None else None
            if item['panel_id'] in (9402,3022):
                expected=[{'parameter':k,'value':v} for k,v in identity_expected.items()]
                note='Independent hashed manifest, ledger, checkpoint history and pipeline report; checkpoint fields and P0 graph anchors checked separately.'
            if item['panel_id'] in (3010,3020):
                query=parse_qs(urlparse(item['request']['queries'][0]['url']).query)
                kind='pipeline' if item['panel_id']==3010 else 'workflow';owner=query[kind][0];limit=int(query['limit'][0])
                paths=list((ROOT/'reports/run-reports'/kind/owner).glob('*/'+kind+'-run-report.json'))
                paths.sort(key=lambda p:p.stat().st_mtime,reverse=True)
                expected_paths=[p.relative_to(ROOT).as_posix() for p in paths[:limit]]
                actual_paths=[r['json_path'].replace('/app/','') for r in item['reference']['sources'][0]['body']['items']]
                assert actual_paths==expected_paths,(actual_paths,expected_paths)
                note='Every row anchored to its hashed report; newest-N membership/order independently checked from source file mtimes, not execution timestamps.'
        else:expected=project(prom_table_ref(item),t['frames']);actual=frame_rows(t['frames'])
        equal=canonical(actual)==canonical(expected) if isinstance(actual,list) and isinstance(expected,list) else actual==expected
        if isinstance(actual,(int,float)) and isinstance(expected,(int,float)):
            equal=abs(actual-expected)<=1e-9
        if not equal:status='FAIL'
        if expected is None:status='NOT_VERIFIABLE'
    except Exception as e:status='FAIL';note=str(e)
    results.append({'id':item['id'],'status':status,'method':calc,'input_sample_count':count,'actual':actual,'expected':expected,'note':note})
summary=dict(Counter(r['status'] for r in results))
(OUT/'conformance-results.json').write_text(json.dumps({'candidate_ref':'07528418e7abfa5535ed50aee009b73f9fb87899','input_manifest_sha256':hashlib.sha256((OUT/'input-manifest.json').read_bytes()).hexdigest(),'scope':'Controlled numeric conformance plus actual persisted HTTP artifacts; live UNKNOWN assessment remains separate.','summary':summary,'results':results},indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(summary))
for r in results:
    if r['status']!='PASS':print(r['id'],r['status'],r['note'],str(r['actual'])[:220],str(r['expected'])[:220])
