"""Known cumulative histograms and store/operation labels for original legend retests."""
import ast,hashlib,json,struct
from pathlib import Path
import requests
OUT=Path(__file__).parent
for node in ast.parse((OUT/'seed.py').read_text()).body:
    if isinstance(node,ast.FunctionDef) and node.name in ('varint','field','encode'):exec(compile(ast.Module(body=[node],type_ignores=[]),'seed.py','exec'))
END=1788858000;START=END-1800;series=[]
def add(name,labels,mult):
    series.append({'labels':{'__name__':name,**labels},'samples':[[t*1000,1000+mult*(t-START)//10] for t in range(START,END+1,10)]})
for bucket,count in [('0.1',2),('0.5',8),('1',10),('+Inf',10)]:
    add('bioetl_health_check_latency_seconds_bucket',{'provider':'chembl','le':bucket},count)
    for store,operation in [('run_manifest','get'),('run_ledger','list')]:add('bioetl_control_plane_read_duration_seconds_bucket',{'store':store,'operation':operation,'status':'success','le':bucket},count)
for store,operation in [('run_manifest','get'),('run_ledger','list')]:add('bioetl_control_plane_reads_total',{'store':store,'operation':operation,'status':'success'},10)
raw=b''.join(map(encode,series));length=len(raw)-1;n=max(1,(length.bit_length()+7)//8)
compressed=varint(len(raw))+bytes([(59+n)<<2])+length.to_bytes(n,'little')+raw
data=json.dumps({'scope':'isolated histogram/legend fixture','expected_p95_seconds':0.875,'histogram_bucket_event_rates_per_10s':[2,8,10,10],'series':series},indent=2).encode();(OUT/'latency-input-manifest.json').write_bytes(data)
r=requests.post('http://127.0.0.1:9094/api/v1/write',data=compressed,headers={'Content-Encoding':'snappy','Content-Type':'application/x-protobuf','X-Prometheus-Remote-Write-Version':'0.1.0'},timeout=60)
if r.status_code!=204:print(r.text)
r.raise_for_status();(OUT/'latency-seed-receipt.json').write_text(json.dumps({'status':r.status_code,'series':len(series),'sha256':hashlib.sha256(data).hexdigest()}));print(r.status_code,len(series))
