"""Add independent zero-only series; preserve the prior positive fixture."""
import ast
import hashlib
import json
import struct
from pathlib import Path
import requests
OUT=Path(__file__).parent
tree=ast.parse((OUT/'seed.py').read_text())
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in ('varint','field','encode'):
        exec(compile(ast.Module(body=[node],type_ignores=[]),'seed.py','exec'))
END=1788858000;START=END-1800
series=[]
def add(name,labels,v):
    series.append({'labels':{'__name__':name,**labels},'samples':[[t*1000,v(t) if callable(v) else v] for t in range(START,END+1,30)]})
scope={'pipeline':'chembl_reference_zero','run_type':'backfill'}
for name in ('bioetl_replay_safety_blockers_15m','bioetl_control_plane_current_status_trusted','bioetl_l0_status','bioetl_runtime_current_status_trusted','bioetl_trust_replay_blocker_integrity','bioetl_stage_lag_seconds'):add(name,scope,0)
add('bioetl_trust_replay_blocker_events_total',scope,100)
add('bioetl_pipeline_runs_total',{**scope,'status':'failed'},100)
add('bioetl_runtime_pipeline_run_type_universe_scoped',scope,1)
add('bioetl_dq_current_status',{'pipeline':scope['pipeline']},0)
add('bioetl_dq_current_reason',{'pipeline':scope['pipeline'],'severity':'crit','reason':'reference_zero'},0)
add('bioetl_dq_first_window_reason',{'pipeline':scope['pipeline'],'severity':'crit','reason':'reference_zero'},0)
add('bioetl_data_freshness_seconds',{'pipeline':scope['pipeline']},lambda t:t)
raw=b''.join(map(encode,series));length=len(raw)-1;n=max(1,(length.bit_length()+7)//8)
compressed=varint(len(raw))+bytes([(59+n)<<2])+length.to_bytes(n,'little')+raw
data=json.dumps({'scope':'known zero, isolated reference, not live pipeline','series':series},indent=2).encode()
(OUT/'zero-input-manifest.json').write_bytes(data)
r=requests.post('http://127.0.0.1:9094/api/v1/write',data=compressed,headers={'Content-Encoding':'snappy','Content-Type':'application/x-protobuf','X-Prometheus-Remote-Write-Version':'0.1.0'},timeout=60)
if r.status_code!=204:print(r.text)
r.raise_for_status()
(OUT/'zero-seed-receipt.json').write_text(json.dumps({'status':r.status_code,'series':len(series),'sha256':hashlib.sha256(data).hexdigest()}))
print(r.status_code,len(series))
