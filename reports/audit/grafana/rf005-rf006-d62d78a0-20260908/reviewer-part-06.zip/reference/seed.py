"""Known inputs sent to an isolated Prometheus; all timestamps and values retained."""
import hashlib
import json
import struct
from pathlib import Path
import requests

OUT=Path(__file__).parent
END=1788858000
START=END-13*3600
SERIES=[]
def add(name, labels, value):
    samples=[]
    for t in range(START,END+601,30):
        v=value(t) if callable(value) else value
        if v is not None:samples.append([t*1000,v])
    SERIES.append({'labels':{'__name__':name,**labels},'samples':samples})

for p,offset in [('chembl_assay',0),('chembl_publication',1)]:
    for rt,factor in [('backfill',1),('incremental',2)]:
        labels={'pipeline':p,'run_type':rt}
        for name,v in [('bioetl_replay_safety_blockers_15m',offset+factor),('bioetl_control_plane_current_status_trusted',2),('bioetl_l0_status',2),('bioetl_runtime_current_status_trusted',1),('bioetl_runtime_pipeline_run_type_universe_scoped',1)]:add(name,labels,v)
        add('bioetl_trust_replay_blocker_events_total',labels,lambda t,f=factor:100+f*((t-START)//300))
        add('bioetl_trust_replay_blocker_integrity',labels,1)
        # A genuine counter reset one hour before the end; independently reconstructable.
        add('bioetl_pipeline_runs_total',{**labels,'status':'failed'},lambda t,f=factor: f*((t-(END-3600))//300) if t>=END-3600 else 100+f*((t-START)//300))
        add('bioetl_stage_lag_seconds',{**labels,'stage':'silver'},60+offset*10+factor)
        for target,score,uid in [('runtime',20,'bioetl-runtime'),('dq',30,'bioetl-dq-v2')]:
            add('bioetl_l0_next_action_route',{**labels,'input':target,'action_target':target,'action_reason':target+'_reference_signal','action_dashboard_uid':uid},score+offset)
    add('bioetl_dq_current_status',{'pipeline':p},2-offset)
    add('bioetl_dq_current_reason',{'pipeline':p,'severity':'crit','reason':'silver_validation_failure'},1-offset)
    add('bioetl_dq_first_window_reason',{'pipeline':p,'severity':'crit','reason':'silver_validation_failure','action_target':'data_quality','action_dashboard_uid':'bioetl-dq-v2'},7-offset)
    add('bioetl_data_freshness_seconds',{'pipeline':p},lambda t,o=offset:t-3600*(o+1))
add('bioetl_l0_next_action_no_route',{'action_target':'no_route','action_reason':'selected_scope_not_present','action_dashboard_uid':'bioetl-overview-v2'},0)
add('up',{'job':'bioetl','instance':'reference-fixture'},1)
add('bioetl_runtime_trust_gap_status_10m',{},0)
add('prometheus_rule_group_last_evaluation_timestamp_seconds',{'rule_group':'bioetl_reference'},lambda t:t-10)
for provider,status,cause in [('chembl',2,'rate_limit'),('pubchem',1,'latency')]:
    add('bioetl_provider_current_status',{'provider':provider},status)
    add('bioetl_provider_current_cause',{'provider':provider,'cause':cause},status)
for domain,score in [('runtime',30),('provider',20),('dq',10)]:
    add('bioetl_incident_ranked_'+domain,{'domain':domain,'pipeline':'chembl_assay','provider':'chembl','signal':'reference_'+domain,'action':'inspect','action_dashboard_uid':{'runtime':'bioetl-runtime','provider':'bioetl-provider-health-v2','dq':'bioetl-dq-v2'}[domain],'action_scope':'var-pipeline=chembl_assay'},score)
# The explicit stale NaN terminates the pending series, then firing starts.
add('ALERTS',{'alertname':'ReferenceTransition','alertstate':'pending','severity':'warning'},lambda t:1 if END-1800<=t<END-900 else 'STALE' if t==END-900 else None)
add('ALERTS',{'alertname':'ReferenceTransition','alertstate':'firing','severity':'warning'},lambda t:1 if t>=END-900 else None)
add('ALERTS',{'alertname':'ReferenceResolved','alertstate':'firing','severity':'warning'},lambda t:1 if END-2400<=t<END-1200 else 'STALE' if t==END-1200 else None)

def varint(n):
    b=bytearray()
    while n>127:b.append((n&127)|128);n>>=7
    b.append(n);return bytes(b)
def field(n,b):return varint(n*8+2)+varint(len(b))+b
def encode(s):
    b=b''.join(field(1,field(1,k.encode())+field(2,v.encode())) for k,v in sorted(s['labels'].items()))
    for t,v in s['samples']:
        raw=struct.pack('<Q',0x7ff0000000000002) if v=='STALE' else struct.pack('<d',v)
        b+=field(2,b'\x09'+raw+b'\x10'+varint(t))
    return field(1,b)
raw=b''.join(map(encode,SERIES))
length=len(raw)-1
n=max(1,(length.bit_length()+7)//8)
compressed=varint(len(raw))+bytes([(59+n)<<2])+length.to_bytes(n,'little')+raw
manifest={'scope':'isolated deterministic conformance, not production telemetry','start':START,'end':END,'step_seconds':30,'counter_reset_at':END-3600,'series':SERIES}
manifest_bytes=json.dumps(manifest,indent=2).encode()
(OUT/'input-manifest.json').write_bytes(manifest_bytes)
r=requests.post('http://127.0.0.1:9094/api/v1/write',data=compressed,headers={'Content-Encoding':'snappy','Content-Type':'application/x-protobuf','X-Prometheus-Remote-Write-Version':'0.1.0'},timeout=60)
r.raise_for_status()
q=requests.get('http://127.0.0.1:9094/api/v1/query',params={'query':'count({__name__=~"bioetl_.*|ALERTS|up|prometheus_rule_group_last_evaluation_timestamp_seconds"})','time':END},timeout=30)
q.raise_for_status()
receipt={'input_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'write_status':r.status_code,'series_count':len(SERIES),'samples':sum(len(s['samples']) for s in SERIES),'query':q.json()}
(OUT/'seed-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
