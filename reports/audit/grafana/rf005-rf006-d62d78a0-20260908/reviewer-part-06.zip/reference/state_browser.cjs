const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('C:/Users/Fedor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const out=path.join(__dirname,'state-browser');fs.mkdirSync(out,{recursive:true});
(async()=>{const b=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});try{
 const ctx=await b.newContext({viewport:{width:1366,height:768},deviceScaleFactor:1,timezoneId:'UTC'}),p=await ctx.newPage(),rows=[];
 for(const [scope,pipeline] of [['known-zero','chembl_reference_zero'],['missing','absent_reference_pipeline']])for(const uid of ['bioetl-control-plane-v1','bioetl-dq-v2','bioetl-runtime']){
  const q=new URLSearchParams({'var-pipeline':pipeline,'var-run_type':'backfill','var-run_id':'-',from:'2026-09-08T08:45:00.000Z',to:'2026-09-08T09:00:00.000Z',timezone:'utc',theme:'dark'});
  await p.goto('http://127.0.0.1:3005/d/'+uid+'/'+uid+'?'+q,{waitUntil:'networkidle'});await p.waitForTimeout(500);
  const file=uid+'-'+scope;const png=await p.screenshot({path:path.join(out,file+'.png')});const dom=await p.locator('body').ariaSnapshot();fs.writeFileSync(path.join(out,file+'.txt'),dom);
  const body=await p.locator('body').innerText();const row={uid,scope,pipeline,url:p.url(),captured_at:new Date().toISOString(),png_sha256:crypto.createHash('sha256').update(png).digest('hex'),body,geometry:await p.evaluate(()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio,scale:visualViewport.scale}))};
  if(uid==='bioetl-dq-v2')row.expected_reason_visible=body.includes(scope==='known-zero'?'No active reasons (OK)':'Evidence unavailable (UNKNOWN)');
  rows.push(row);fs.writeFileSync(path.join(out,'observations.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify({uid,scope,reason:row.expected_reason_visible}));
 }
 }finally{await b.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
