import copy
import json
from pathlib import Path
import requests
OUT=Path(__file__).parent
captures=json.loads((OUT/'captures.json').read_text(encoding='utf-8'))
rows=[]
for item in captures:
    if item['scenario']!='normal-15m' or item['reference']['calculation']=='persisted_http':continue
    x=copy.deepcopy(item);x['id']=x['id'].replace('normal-15m','controlled-zero');x['scenario']='controlled-zero'
    x['variables']['pipeline']='chembl_reference_zero'
    for q in x['request']['queries']:q['expr']=q['expr'].replace('chembl_assay','chembl_reference_zero')
    r=requests.post('http://127.0.0.1:3005/api/ds/query',json=x['request'],timeout=60);r.raise_for_status()
    x['response']=r.json();x.pop('reference');x['scope']='Isolated known-zero pipeline; global/provider/incident queries retain their documented global scope.'
    rows.append(x)
(OUT/'zero-captures.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('Captured',len(rows))
