"""Separate numeric proofs, selection/absence states and deliberate invalid queries."""
import hashlib,json
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from reconcile import frame_rows,canonical,http_ref,project
O=Path(__file__).parent;ROOT=Path('E:/github/BioactivityDataAcquisition')
def read(n):return json.loads((O/n).read_text(encoding='utf-8'))
raw=read('matrix-conformance-results.json');captures={r['id']:r for r in read('captures.json')};transforms={r['id']:r for r in read('transformed-complete.json')};persisted=read('persisted-references.json')
rows=[]
for previous in raw['results']:
 r=dict(previous);item=captures[r['id']];t=transforms[r['id']];status=r['status'];reason='';body=item['reference']['sources'][0]['body'];calc=r['method']
 if status!='PASS':
  try:
   if item['status']==400:
    assert calc=='persisted_http' and 'error' in body
    assert ('Missing required query parameter' in body['error'] or 'pipeline' in body['error'])
    status='PASS_EXPECTED_QUERY_ERROR';reason='Deliberately invalid/empty HTTP selector is rejected with explicit 400; this is not numeric evidence.'
   elif calc=='persisted_http' and item['panel_id'] in (9402,3022):
    assert body.get('resolved_via') in ('selection_required','no_manifest_for_scope','selected_run_id_not_found'),body.get('resolved_via')
    actual=frame_rows(t['frames'])
    assert not any('Complete [' in str(x.get('value','')) for x in actual)
    assert body.get('selected_run_id') in (None,'00000000-0000-0000-0000-000000000000')
    status='PASS_STATE_ONLY';reason='No exact manifest selected/found. Identity placeholders or selection-required empty rows do not claim complete identity. The positive-run identity reference does not apply.'
   elif calc=='persisted_http' and item['panel_id'] in (3010,3020):
    query=parse_qs(urlparse(item['request']['queries'][0]['url']).query);kind='pipeline' if item['panel_id']==3010 else 'workflow';owner=query.get(kind,[''])[0];limit=int(query['limit'][0])
    assert owner in ('.*','')
    paths=list((ROOT/'reports/run-reports'/kind).glob('*/*/'+kind+'-run-report.json'));paths.sort(key=lambda p:p.stat().st_mtime,reverse=True)
    expected_paths=[p.relative_to(ROOT).as_posix() for p in paths[:limit]]
    actual_paths=[x['json_path'].replace('/app/','') for x in body['items']]
    assert actual_paths==expected_paths
    expected,_=http_ref(item,persisted);expected=project(expected,t['frames']);assert canonical(frame_rows(t['frames']))==canonical(expected)
    status='PASS';reason='All-owner index independently enumerated across every owner directory and ordered by source file mtime. Every displayed row reconciles to its hashed report.'
   elif calc=='persisted_http':
    assert not item['variables'].get('run_id') or item['variables']['run_id'] in ('-','00000000-0000-0000-0000-000000000000')
    actual=frame_rows(t['frames']);text=json.dumps(actual)
    assert not actual or any(s in text for s in ('UNKNOWN','SELECT RUN','TELEMETRY MISSING'))
    status='PASS_STATE_ONLY';reason='No persisted exact-run numeric reference exists for this selector; observed selection/missing state is retained without fabricated counts.'
   elif calc=='dq_reasons_top5':
    assert r['input_sample_count']==0 and r['actual']==[{'reason':'Evidence unavailable (UNKNOWN)'}]
    status='PASS_STATE_ONLY';reason='Missing input series produce the explicit UNKNOWN reason sentinel; empty raw series are not the healthy no-active-reasons state.'
   elif calc=='route_top2':
    assert body['data']['result']==[] and len(r['actual'])==1 and r['actual'][0]['action_reason']=='selected_scope_not_present' and r['actual'][0]['action_target']=='no_route'
    status='PASS_STATE_ONLY';reason='Absent selected scope produces a no_route diagnostic sentinel, not a healthy route or fabricated suspect.'
   elif status=='NOT_VERIFIABLE':
    assert r['expected'] is None and r['actual'] is None
    assert r['input_sample_count']==0 or (calc=='stage_lag' and all(s['metric']['pipeline']!=item['variables']['pipeline'] for s in body['data']['result']))
    assert all(d['name']=='No data' and d['display']['text']=='UNKNOWN' for d in t.get('displays',[]))
    status='PASS_STATE_ONLY';reason='No matching selected-scope samples and no numeric result (broad stage-lag reference may contain other pipelines). Grafana No data presentation uses an internal numeric=0 placeholder but displays UNKNOWN in the missing-data color; that placeholder is explicitly excluded from numeric reconciliation. This proves absence handling only.'
  except (AssertionError,KeyError,TypeError,ValueError) as e:
   status='UNRESOLVED';reason=str(e)
 rows.append({**r,'original_harness_status':r['status'],'status':status,'adjudication':reason})
summary=dict(Counter(r['status'] for r in rows))
(O/'matrix-adjudication.json').write_text(json.dumps({'candidate_ref':raw['candidate_ref'],'original_harness_sha256':hashlib.sha256((O/'matrix-conformance-results.json').read_bytes()).hexdigest(),'summary':summary,'scope':'All 225 captured variable/window cases. PASS_STATE_ONLY and expected query errors are not numeric reconciliation or production completeness.','results':rows},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary))
for r in rows:
 if r['status'] not in ('PASS','PASS_STATE_ONLY','PASS_EXPECTED_QUERY_ERROR'):print(r['id'],r['status'],r['adjudication'])
