# RF-005 / RF-006 final regression acceptance

Candidate: `d62d78a0db36118df302f5f63e6ed992e01154dc`. Reviewer: **Astra, AI agent**. The canonical [release gate](release-gate.json) is PASS; all 48 baseline findings have proved dispositions. This bundle supports #10185 acceptance followed by #10171 tracker closure. RF-004 #10167 was already accepted under the owner's explicit AI-only scope.

The owner accepted AI verification of 21 diagnostic scenarios and a controlled known-input reference with separate live UNKNOWN checks. **Human usability is NOT_MEASURED (N=0); live telemetry completeness is not claimed; replay was not executed.** These limitations are retained in the gate and raw receipts.

## Review route

1. Read [contract](contract.json), [scope](reviews/profile-scope.json), [owner numeric scope](reviews/owner-data-integrity-scope.json) and [AI scope](reviews/operator-scope-decision.json).
2. Check [final source equivalence](reviews/final-source-equivalence.json). Capture refs remain unchanged: Stream A `68ec26b17b`, integration `07528418e7a`, Windows `cab240755d`. Git objects on applicable runtime surfaces equal final candidate; old rewritten history is not claimed as ancestry.
3. Inspect [findings](gates/findings.json), [original issue snapshots](baseline/retest-cases.json), [attempt dispositions](reviews/attempt-dispositions.json) and the table below. Historical failed/incomplete attempts are evidence of attempts, not passing captures.
4. Inspect [numeric conformance](reference/conformance-results.json), [all variable cases](reference/matrix-adjudication.json), [critical lineage](reference/critical-panel-lineage.json), [live integrity](live-integrity/reference-adjudication.json), [focused original retests](reviews/focused-retests.json).
5. Inspect [Windows full profile](windows/windows-cab-full-profile/receipt.json), [source binding adjudication](reviews/windows-source-adjudication.json), [final CI checks](final-ci-d62d78a0db.json), [downloaded producer receipt](ci/receipt.json), [archived Proof verification](ci/archived-verification.json).

## Results and limits

| Evidence | Result |
| --- | --- |
| Stream A layout / accessibility | 15 profiles, 105 dashboard observations; 8402/8402 required text and 1886/1886 graphics contrast samples; 45 disabled-graphic exemptions retained; zero color-only meanings |
| Live browser regression | 84 observations at900/1366; 560 navigation/context assertions; 14 query-error popovers |
| Original 1000-width supplement | Seven expanded dashboards and seven actual query-error popovers; separate identity panel1000/1366 and six timeline tooltip observations |
| Set range to run | 20 assertions, selected report bounds plus margin, IN RANGE after return |
| Numeric reference | 50/50 primary cases (25 data panels ×15m/6h); all225 variable cases adjudicated:161 numeric/table,56 state-only,8 expected invalid-query responses |
| Zero / absent data | Ten known-zero stats;55 table field configurations keep null/NaN distinct; live UNKNOWN remains explicit |
| Operator integration | 21/21 tasks;N=21 attempts,one AI;elapsed median42.929s/max635.914s;clicks median1/max2;interactions2/6;context loss0;back navigation0/2 |
| Windows | Canonical main and monitoring status exit0;5/5targets UP;2469Python hashes and7dashboard models match |
| CI final main | Tests34242865248 succeeded; Proof ADMIT/errors0/degradations0; architecture succeeded; no failed checks |

Operator elapsed time includes tool waits and recorded interruptions/repair time;635.914s includes concurrent work/compaction, not a human understanding measure. Original RF-004 metrics and its immutable publication remain separate. Live116 NOT_VERIFIABLE cases are not converted into numeric passes by the approved reference fixture. Initial cold Windows readiness failure is retained and resolved by bounded retest with unchanged3s limits. Protected `docker-push` remains approval-waiting; no publication approval or policy bypass was performed.

No dashboard child issue was reimplemented during this final retest. The necessary CI repair is merged PR#10238: canonical telemetry regeneration from main producer34238177700, with26 focused tests passing and unchanged budgets/thresholds. Runtime mirrors were not changed in that repair; exact-final CI provides docs/runtime governance evidence. No additional full local suite was rerun after successful exact-source CI. Root secret `.env` was read only.

## Reproduce offline

Download every `reviewer-part-*.zip` listed in `archive-index.json` alongside this README, verify archive SHA256, and extract all parts into one new directory. Paths are relative and each file occurs once. Run `python verify_bundle.py` from that directory. The verifier checks every manifest byte/hash and the canonical regression contract. `stream-a/` retains its original ZIPs/source bundle and archive round-trip receipts. Large raw responses and browser PNGs are included; tools record their actual runtime prerequisites and are not silently rerun against live services.

`manifest.json` covers all bundle files except itself. The external archive index hashes each independently extractable ZIP and the manifest. The immutable Git commit of the publication binds README, gate, index and archives. The gate was written once with final candidate checked against a clean owned worktree.

## Original finding dispositions

| ID | Severity | Disposition | Evidence |
| --- | --- | --- | --- |
| D01 | P2 | FIXED | [review](reviews/findings/D01.json) |
| D02 | P2 | FIXED | [review](reviews/findings/D02.json) |
| D03 | P2 | FIXED | [review](reviews/findings/D03.json) |
| E01 | P2 | FIXED | [review](reviews/findings/E01.json) |
| E02 | P2 | FIXED | [review](reviews/findings/E02.json) |
| E03 | P2 | FIXED | [review](reviews/findings/E03.json) |
| E04 | P2 | FIXED | [review](reviews/findings/E04.json) |
| E05 | P2 | FIXED | [review](reviews/findings/E05.json) |
| E06 | P2 | FIXED | [review](reviews/findings/E06.json) |
| E07 | P1 | FIXED | [review](reviews/findings/E07.json) |
| F01 | P1 | FIXED | [review](reviews/findings/F01.json) |
| F02 | P1 | FIXED | [review](reviews/findings/F02.json) |
| F03 | P1 | FIXED | [review](reviews/findings/F03.json) |
| F04 | P2 | FIXED | [review](reviews/findings/F04.json) |
| F05 | P2 | FIXED | [review](reviews/findings/F05.json) |
| F06 | P2 | FIXED | [review](reviews/findings/F06.json) |
| F07 | P2 | FIXED | [review](reviews/findings/F07.json) |
| F08 | P2 | FIXED | [review](reviews/findings/F08.json) |
| F09 | P2 | FIXED | [review](reviews/findings/F09.json) |
| F10 | P2 | FIXED | [review](reviews/findings/F10.json) |
| F11 | P2 | FIXED | [review](reviews/findings/F11.json) |
| F12 | P2 | FIXED | [review](reviews/findings/F12.json) |
| F13 | P2 | FIXED | [review](reviews/findings/F13.json) |
| F14 | P1 | FIXED | [review](reviews/findings/F14.json) |
| F15 | P1 | FIXED | [review](reviews/findings/F15.json) |
| F16 | P2 | FIXED | [review](reviews/findings/F16.json) |
| F17 | P2 | FIXED | [review](reviews/findings/F17.json) |
| F18 | P2 | FIXED | [review](reviews/findings/F18.json) |
| F19 | P3 | FIXED | [review](reviews/findings/F19.json) |
| F20 | P2 | FIXED | [review](reviews/findings/F20.json) |
| G01 | P1 | FIXED | [review](reviews/findings/G01.json) |
| G02 | P1 | FIXED | [review](reviews/findings/G02.json) |
| G03 | P3 | FIXED | [review](reviews/findings/G03.json) |
| I01 | P1 | FIXED | [review](reviews/findings/I01.json) |
| I02 | P1 | FIXED | [review](reviews/findings/I02.json) |
| I03 | P2 | FIXED | [review](reviews/findings/I03.json) |
| I04 | P2 | FIXED | [review](reviews/findings/I04.json) |
| O01 | P2 | FIXED | [review](reviews/findings/O01.json) |
| O02 | P2 | FIXED | [review](reviews/findings/O02.json) |
| O03 | P2 | FIXED | [review](reviews/findings/O03.json) |
| P01 | P2 | FIXED | [review](reviews/findings/P01.json) |
| P02 | P2 | FIXED | [review](reviews/findings/P02.json) |
| P03 | P2 | FIXED | [review](reviews/findings/P03.json) |
| R01 | P2 | FIXED | [review](reviews/findings/R01.json) |
| R02 | P2 | FIXED | [review](reviews/findings/R02.json) |
| T01 | P1 | FIXED | [review](reviews/findings/T01.json) |
| T02 | P2 | FIXED | [review](reviews/findings/T02.json) |
| T03 | P2 | FIXED | [review](reviews/findings/T03.json) |
