const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const { chromium } = require('C:/Users/Fedor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const out = path.join(__dirname, 'operator-07528418e7a', 'controlled-session');
fs.mkdirSync(out, { recursive: true });
const candidate = '07528418e7abfa5535ed50aee009b73f9fb87899';
const params = new URLSearchParams({ 'var-workflow':'$__all', 'var-pipeline':'chembl_assay', 'var-run_type':'backfill', 'var-run_id':'b9d2eeff-8e4b-5678-ae32-b288ced27968', 'var-provider':'chembl','var-pipeline_context':'chembl_assay','var-provider_hint':'chembl','var-stage':'$__all', from:'2026-09-08T08:30:00.000Z',to:'2026-09-08T09:00:00.000Z',timezone:'utc',theme:'dark',refresh:''});
let browser, context, page, task = null, sequence = Math.max(0,...fs.readdirSync(out).map(n=>Number(n.match(/^(\d+)-/)?.[1])||0));
const records = fs.existsSync(path.join(out,'observations.json')) ? JSON.parse(fs.readFileSync(path.join(out,'observations.json'),'utf8')).records : [];
let resumeUid = null;
const artifactResume=path.join(out,'artifact-resume-state.json');
if(fs.existsSync(artifactResume) && !records.some(r=>r.task_id==='bioetl-run-explorer-v1:Q3')) records.push(JSON.parse(fs.readFileSync(artifactResume,'utf8')));
if(records.at(-1)?.measurement_state==='PAUSED_HARNESS_REPAIR') {
  task=records.pop();
  task.started_ms=Date.parse(task.started_at);
  task.path.push('Harness repaired; restored same dashboard and continued original attempt');
  task.interactions++;
  task.measurement_state='RESUMED';
  resumeUid=task.task_id.split(':')[0];
}
function write(name, data) { fs.writeFileSync(path.join(out,name),JSON.stringify(data,null,2)); }
async function capture(label) {
  await page.bringToFront();
  await page.waitForLoadState('networkidle');
  await page.getByRole('button',{name:'Cancel',exact:true}).waitFor({state:'hidden',timeout:20000});
  await page.getByText('Loading ...',{exact:true}).waitFor({state:'hidden',timeout:20000});
  await page.waitForTimeout(100);
  const prefix = String(++sequence).padStart(3,'0')+'-'+label.replace(/[^a-zA-Z0-9-]/g,'-');
  const geometry = await page.evaluate(()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio,scale:visualViewport.scale}));
  const screenshot = prefix+'.png';
  await page.screenshot({path:path.join(out,screenshot)});
  const snapshot = await page.locator('body').ariaSnapshot();
  fs.writeFileSync(path.join(out,prefix+'.txt'),snapshot);
  const evidence = {captured_at:new Date().toISOString(),candidate_ref:candidate,url:page.url(),geometry,screenshot,snapshot:prefix+'.txt'};
  write(prefix+'.json',evidence);
  if (task) task.evidence.push(prefix+'.json');
  if (task) write('active-task.json',task);
  return evidence;
}
async function execute(c) {
  if (c.action==='open') {
    await page.goto('http://127.0.0.1:3004/d/'+c.uid+'/'+c.uid+'?'+params,{waitUntil:'networkidle'});
    await page.getByText('Navigate Dashboards',{exact:true}).waitFor();
    const menu=page.getByRole('button',{name:'Close menu',exact:true});
    if(await menu.isVisible()) await menu.click();
    if(c.uid==='bioetl-provider-health-v2') {
      const runtimeUrl=await page.getByRole('link',{name:'2. Pipeline Diagnostics',exact:true}).getAttribute('href');
      if(new URL(runtimeUrl,'http://127.0.0.1:3004').searchParams.get('var-pipeline')!=='chembl_assay') throw Error('Provider fixture pipeline_context mismatch');
    }
    return capture('ready-'+c.uid);
  }
  if(c.action==='start') {
    if(task) throw Error('Task already active');
    task={task_id:c.task_id,started_at:new Date().toISOString(),started_ms:Date.now(),candidate_ref:candidate,participant:'Astra',participant_type:'AI_AGENT',prior_exposure:'Astra AI; prior RF004 session accepted on 1895351a8a; repeated integration regression on 07528418e7a with canonical Grafana clock. Extensive source and UI exposure; no human usability measurement.',attempt:1,first_correct_seconds:null,clicks:0,interactions:0,context_loss:0,back_navigation:0,diagnostic_depth:0,evidence:[],path:['Read current dashboard']};
    return capture('start-'+c.task_id);
  }
  if(c.action==='click') {
    const target=page.getByRole(c.role||'link',{name:c.name,exact:true});
    await target.click({timeout:10000});
    if(task){task.clicks++;task.interactions++;task.path.push(c.name);}
    await page.waitForLoadState('networkidle');
    return capture('click');
  }
  if(c.action==='scroll') {
    await page.mouse.move(c.x || 1355,550);
    await page.mouse.wheel(0,c.dy);
    await page.waitForTimeout(350);
    if(task){task.interactions++;task.path.push('scroll '+c.dy);}
    return capture('scroll');
  }
  if(c.action==='row') {
    await page.getByRole('button',{name:'Expand row',exact:true}).filter({has:page.getByRole('heading',{name:c.name,exact:true})}).click();
    if(task){task.clicks++;task.interactions++;task.path.push('Expand '+c.name);}
    return capture('expand');
  }
  if(c.action==='artifact') {
    const [popup]=await Promise.all([context.waitForEvent('page',{timeout:15000}),page.getByRole('link',{name:c.name,exact:true}).click({timeout:15000})]);
    if(task){task.clicks++;task.interactions++;task.path.push(c.name);}
    page=popup;
    await page.waitForLoadState('networkidle');
    return capture('artifact');
  }
  if(c.action==='returnTab') {
    page=context.pages()[0];
    await page.bringToFront();
    if(task){task.interactions++;task.back_navigation++;task.path.push('Return to dashboard tab');}
    return capture('return-tab');
  }
  if(c.action==='back') {
    await page.goBack({waitUntil:'networkidle'});
    if(task){task.clicks++;task.interactions++;task.back_navigation++;task.path.push('Browser Back');}
    return capture('return');
  }
  if(c.action==='capture') return capture('observe');
  if(c.action==='finish') {
    if(!task) throw Error('No active task');
    const ended=Date.now();
    Object.assign(task,c.result,{ended_at:new Date(ended).toISOString(),elapsed_seconds:(ended-task.started_ms)/1000});
    delete task.started_ms;
    records.push(task);task=null;
    write('observations.json',{candidate_ref:candidate,human_usability_status:'NOT_MEASURED',human_sample_size:0,records});
    return records.at(-1);
  }
  if(c.action==='stop') {await browser.close();process.exit(0);}
  throw Error('Unknown action');
}
(async()=>{
  browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
  context=await browser.newContext({viewport:{width:1366,height:768},deviceScaleFactor:1,locale:'en-US',timezoneId:'UTC',colorScheme:'dark'});
  context.setDefaultTimeout(20000);
  context.setDefaultNavigationTimeout(30000);
  page=await context.newPage();
  if(resumeUid) {
    if(task.resume_view_panel) {
      await page.goto('http://127.0.0.1:3004/d/'+resumeUid+'/'+resumeUid+'?'+params+'&viewPanel='+task.resume_view_panel,{waitUntil:'networkidle'});
      await capture('restored-artifact-panel');
    } else await execute({action:'open',uid:resumeUid});
  }
  console.log(JSON.stringify({ready:true,output:out}));
  const input=readline.createInterface({input:process.stdin,crlfDelay:Infinity});
  for await (const line of input) {
    try{console.log(JSON.stringify({ok:true,result:await execute(JSON.parse(line))}));}
    catch(e){console.log(JSON.stringify({ok:false,error:String(e)}));}
  }
  await browser.close();
})();
