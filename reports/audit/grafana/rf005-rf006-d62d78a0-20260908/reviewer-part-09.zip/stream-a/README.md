# Stream A: provenance, layout и accessibility

Capture source: `68ec26b17b6bec5d88704b547ee195251985c286`. Набор подготовлен для RF-001 #10186, RF-002 #10165 и RF-003 #10170. Публикация и итоговый GitHub CI проверяются отдельно.

- 15 профилей, 105 captures: 7 dashboards на каждом; три viewport, Dark/Light, collapsed/expanded, physical 1366×768 при 100%/200%, повтор 1440×900 Dark.
- Provenance, layout/reflow/typography и обязательная contrast-проверка: PASS. Text: 8402/8402; graphics: 1886/1886; 45 наблюдений disabled controls исключены явно. Color-only = 0.
- Все 205 панелей наблюдались в каждом expanded-профиле. В collapsed-профилях скрытые панели сохраняют NOT_VERIFIABLE; это не пропуск обязательного expanded coverage.
- 200% реализован CSS viewport 683×384 и deviceScaleFactor 2 при physical 1366×768. Вертикальная прокрутка разрешена. CSS zoom остаётся 1.
- Недоступный valid-zero сценарий и неиндуцированный QUERY ERROR сохраняют NOT_VERIFIABLE. Числовая корректность метрик, operator timing и полная WCAG-сертификация этим набором не утверждаются.
- Native ellipsis в таблицах сохранён; полные DOM-значения и клавиатурный путь меню панели → Inspect → Data/JSON проверены отдельно. Hover-кнопка инспектора ячейки пропускается обычным Tab; подробности находятся в supplemental evidence.

[Индекс архивов и hashes](archive-index.json), [accessibility verdict](accessibility-status.json), [contrast measurements](contrast-measurements.json), [reflow и panel coverage](reflow-results.json), [source-bound ручной review](cue-review.json), [runtime identity](runtime-identity.json), [полный matrix index](matrix-manifest.json).

Дополнительные измерения: [supplemental-evidence.zip](supplemental-evidence.zip), [его hashes и состав](supplement-index.json). Исторические несовпадения: [provenance review](historical/historical-provenance-review.json), [статусы пригодности доступных наборов](historical/historical-pack-fitness-v2.json), [поиск оригиналов](historical/original-search.json). Исторические hashes не изменялись; root cause неподтверждённых замен остаётся UNKNOWN.

Каждый профильный ZIP содержит исходный immutable manifest и все связанные PNG/tiles/table pages/series frames. Пути внутри manifest не переписаны. Индекс объединяет два независимых запуска: все 15 profile exit codes равны 0; Light-only часть имеет общий exit 1 только из-за отсутствующего в этой части repeat-профиля. Полный набор проверяет repeat geometry и имеет PASS; исходные manifests обеих частей сохранены локально.

## Воспроизведение

Используйте полный clone репозитория с актуальным validator и зависимостями проекта. [capture-source.bundle](capture-source.bundle) сохраняет исходный commit снимков после исправления сообщений merge-коммитов. Bundle требует историю публичного main до `9f0601ef7528164fc586c4e93bf8d01177c672db`.

```sh
git bundle verify reports/observability/stream-a-evidence-68ec26b17b/capture-source.bundle
git fetch reports/observability/stream-a-evidence-68ec26b17b/capture-source.bundle refs/heads/codex/stream-a-capture-source-68ec26b17b:refs/remotes/evidence/stream-a-capture
```

Распакуйте 15 профильных ZIP в один новый каталог, сохранив имена подпапок профилей. Перед распаковкой сверяйте SHA-256 с archive-index.json. Передайте все `render-manifest--full-set--*.json` модулю `scripts.ops.observability.grafana.capture_acceptance`, укажите `--repo-root`, новый `--output-dir` и `--cue-review` на `cue-review.json` этого набора. Validator должен вернуть exit 0 и accessibility PASS. Семь JSON в checkout должны совпадать с capture source; hash-требования нельзя обходить переименованием manifest или заменой hashes.

Windows-разделители дополнительных PNG поддерживаются validator на Linux; абсолютные пути, drive paths и traversal отвергаются. Отдельный Linux negative-control включён в supplemental evidence. [Полная проверка распакованного набора на Windows](archive-roundtrip-verification.json) подтверждает совпадение всех verdicts; [проверка 1183 PNG на Linux](linux-attachment-verification.json) подтверждает hashes, размеры и пути. Git identity на Linux отдельно не проверялась: в минимальном runtime-образе отсутствует Git.

- [1366x768-dark](1366x768-dark.zip) — 1969610 bytes.

- [1366x768-dark-full](1366x768-dark-full.zip) — 11978975 bytes.

- [1366x768-dark-zoom-200](1366x768-dark-zoom-200.zip) — 2983960 bytes.

- [1440x900-dark](1440x900-dark.zip) — 2096564 bytes.

- [1440x900-dark-full](1440x900-dark-full.zip) — 11772761 bytes.

- [1440x900-dark-repeat](1440x900-dark-repeat.zip) — 2097505 bytes.

- [1920x1080-dark](1920x1080-dark.zip) — 2177944 bytes.

- [1920x1080-dark-full](1920x1080-dark-full.zip) — 11373850 bytes.

- [1366x768-light](1366x768-light.zip) — 1927033 bytes.

- [1366x768-light-full](1366x768-light-full.zip) — 11807081 bytes.

- [1366x768-light-zoom-200](1366x768-light-zoom-200.zip) — 2936695 bytes.

- [1440x900-light](1440x900-light.zip) — 2045750 bytes.

- [1440x900-light-full](1440x900-light-full.zip) — 11575859 bytes.

- [1920x1080-light](1920x1080-light.zip) — 2131335 bytes.

- [1920x1080-light-full](1920x1080-light-full.zip) — 11218088 bytes.
