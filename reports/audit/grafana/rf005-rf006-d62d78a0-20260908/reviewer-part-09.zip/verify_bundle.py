import hashlib,importlib.util,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for row in manifest['files']:
 p=(root/row['path']).resolve();assert p.is_relative_to(root),row['path']
 raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
spec=importlib.util.spec_from_file_location('regression_acceptance',root/'tools/regression_acceptance.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.evaluate(root/'contract.json');assert result['release_passed'],result
assert result==json.loads((root/'release-gate.json').read_text(encoding='utf-8'))
print(json.dumps({'files_verified':len(manifest['files']),'candidate_ref':result['candidate_ref'],'release_passed':True}))
