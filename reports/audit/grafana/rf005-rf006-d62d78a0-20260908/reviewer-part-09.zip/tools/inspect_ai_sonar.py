import json
from pathlib import Path
import requests
from dotenv import dotenv_values

root = Path(__file__).parent
values = dotenv_values('E:/github/BioactivityDataAcquisition/.env')
session = requests.Session()
token = values.get('SONAR_TOKEN') or values.get('SONARQUBE_TOKEN')
if token:
    session.auth = (token, '')
query = {'componentKeys': 'SatoryKono_BioactivityDataAcquisition', 'pullRequest': '10232', 'resolved': 'false', 'ps': 500}
r = session.get('https://sonarcloud.io/api/issues/search', params=query, timeout=90)
if r.status_code in (401, 403):
    r = requests.get('https://sonarcloud.io/api/issues/search', params=query, timeout=90)
r.raise_for_status()
data = r.json()
(root / 'sonar-issues.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps({'total':data.get('total'), 'issues':[{k:i.get(k) for k in ('key','rule','severity','component','line','message','textRange','flows')} for i in data.get('issues',[])]}), flush=True)
r = session.get('https://sonarcloud.io/api/qualitygates/project_status', params={'projectKey':query['componentKeys'], 'pullRequest':'10232'}, timeout=90)
print('quality_gate_http', r.status_code)
if r.ok:
    (root/'sonar-gate.json').write_text(json.dumps(r.json(), indent=2), encoding='utf-8')
    print(json.dumps(r.json()))
