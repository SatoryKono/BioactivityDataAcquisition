import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from dotenv import dotenv_values

out = Path(__file__).parent
repo = 'SatoryKono/BioactivityDataAcquisition'
expected = '3ae5907f634e9f44dffc0b3ea2b9653d4b49f260'
env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']

def gh(*args):
    result = subprocess.run(['gh', *args], env=env, capture_output=True, text=True, encoding='utf-8', timeout=120)
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout

evidence = json.loads((out / expected / 'final-ci-evidence.json').read_text(encoding='utf-8'))
assert evidence['pr']['headRefOid'] == expected
assert all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in evidence['runs'])
assert any(p['verification']['outcome'] == 'ADMIT' for p in evidence['proof_verification'])
assert evidence['sonar']['quality_gate']['projectStatus']['status'] == 'OK'
pr = json.loads(gh('pr', 'view', '10232', '--repo', repo, '--json', 'headRefOid,state,mergeable,isDraft,statusCheckRollup'))
assert pr['headRefOid'] == expected and pr['state'] == 'OPEN' and not pr['isDraft']
assert pr['mergeable'] == 'MERGEABLE'
assert all(c.get('conclusion') in ('SUCCESS', 'SKIPPED', 'NEUTRAL') if c.get('__typename') == 'CheckRun' else c.get('state') == 'SUCCESS' for c in pr['statusCheckRollup'])
gh('pr', 'edit', '10232', '--repo', repo, '--body-file', str(out / 'ai-scope-pr.md'))
gh('pr', 'merge', '10232', '--repo', repo, '--squash', '--match-head-commit', expected)
merged = json.loads(gh('pr', 'view', '10232', '--repo', repo, '--json', 'state,headRefOid,mergeCommit,mergedAt,url'))
assert merged['state'] == 'MERGED', merged
receipt = {'captured_at': datetime.now(timezone.utc).isoformat(), 'pr': merged}
(out / 'ai-scope-merge.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
