import hashlib
import json
import sys
from pathlib import Path
from datetime import datetime, timezone
import requests

sys.stdout.reconfigure(encoding='utf-8')
root=Path('E:/github/BioactivityDataAcquisition')
out=Path(__file__).parent
dashboard=json.loads((root/'grafana/dashboards/bioetl-run-explorer-v1.json').read_text(encoding='utf-8'))
def panels(rows):
    for row in rows:
        yield row
        yield from panels(row.get('panels',[]))
targets=[{'id':p['id'],'targets':p['targets']} for p in panels(dashboard['panels']) if p['id'] in (3011,3012)]
print(json.dumps(targets),flush=True)
session=requests.Session()
session.headers['Cache-Control']='no-cache'
queries={
    'ready':'http://127.0.0.1:8000/health/ready',
    'index':'http://127.0.0.1:8000/ops/observability/pipeline-run-reports?pipeline=chembl_assay&limit=3',
}
for name,url in queries.items():
    try:
        r=session.get(url,timeout=20)
        payload=r.json()
        (out/(name+'-before.json')).write_text(json.dumps({'captured_at':datetime.now(timezone.utc).isoformat(),'url':url,'status':r.status_code,'payload':payload},indent=2),encoding='utf-8')
        print(json.dumps({'name':name,'status':r.status_code,'payload':payload}),flush=True)
    except requests.RequestException as exc:
        print(json.dumps({'name':name,'error':type(exc).__name__}),flush=True)
