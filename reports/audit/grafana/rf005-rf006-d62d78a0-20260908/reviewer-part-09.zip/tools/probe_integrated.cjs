const fs=require('node:fs');
const {chromium}=require('C:/Users/Fedor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 const page=await browser.newPage({viewport:{width:900,height:768},deviceScaleFactor:1});
 await page.goto('http://127.0.0.1:3004/d/bioetl-control-plane-v1/bioetl-control-plane-v1?var-pipeline=chembl_assay&var-run_type=backfill&var-run_id=-&from=1788856200000&to=1788858000000&timezone=utc&theme=dark',{waitUntil:'networkidle'});
 await page.getByText('Navigate Dashboards',{exact:true}).waitFor();
 await page.waitForTimeout(600);
 const state={url:page.url(),body:await page.locator('body').ariaSnapshot(),panels:await page.locator('[data-testid]').evaluateAll(nodes=>nodes.map(n=>({tag:n.tagName,testid:n.getAttribute('data-testid')})).filter(n=>/panel|row/i.test(n.testid)).slice(0,40))};
 fs.writeFileSync(__dirname+'/integrated-07528418e7a/probe.json',JSON.stringify(state,null,2));
 await page.screenshot({path:__dirname+'/integrated-07528418e7a/probe.png'});
 console.log(JSON.stringify(state).slice(0,9000));
 await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1;});
