import os
import subprocess
from dotenv import dotenv_values
root = 'E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908'
env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
env.update(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='safe.directory', GIT_CONFIG_VALUE_0=root)
for args in [
    ['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential', 'fetch', 'origin', 'main'],
    ['git', 'log', '--oneline', 'e2a83a96..origin/main'],
    ['git', 'diff', '--stat', 'e2a83a96..origin/main'],
]:
    result = subprocess.run(args, cwd=root, env=env, capture_output=True, text=True, encoding='utf-8', timeout=180)
    print(result.stdout or result.stderr, flush=True)
    result.check_returncode()
