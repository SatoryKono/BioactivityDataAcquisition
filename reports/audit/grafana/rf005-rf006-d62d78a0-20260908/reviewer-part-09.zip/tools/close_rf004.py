"""Close only the completed, user-approved AI operator evidence task."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
base=Path(__file__).parent
bundle=base/'rf004-reviewer-bundle-1895351a8a'
pub=json.loads((base/'rf004-publication.json').read_text(encoding='utf-8'))
verification=json.loads((base/'rf004-publication-verification.json').read_text(encoding='utf-8'))
gate=json.loads((bundle/'operator-gate.json').read_text(encoding='utf-8'))
metrics=json.loads((bundle/'operator-metrics.json').read_text(encoding='utf-8'))
assert gate['result']['status']=='PASS'
assert metrics['task_coverage']['passed']==21 and metrics['drill_down_coverage']['destination_and_return_verified']==7
assert verification['public_download_sha256_verified']
assert any(p['result']['outcome']=='ADMIT' for p in verification['source_ci_proof'])
for file in json.loads((bundle/'manifest.json').read_text(encoding='utf-8'))['files']:
    assert hashlib.sha256((bundle/file['path']).read_bytes()).hexdigest()==file['sha256']
s=requests.Session();s.headers['Authorization']='Bearer '+dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition/issues/10167'
r=s.get(api,timeout=30);r.raise_for_status();issue=r.json()
assert issue['state']=='open' and 'Принять только AI-проверку сценариев' in issue['body']
closeout=f'''<!-- rf004-ai-accepted-1895351a8a -->
## RF-004 закрыта в согласованном scope AI_SCENARIOS

- [x] Семь page goals и диагностическая роль Astra подтверждены владельцем.
- [x] 21/21 Q1–Q3 выполнены на source-bound candidate `{pub['candidate_ref']}`; ответы проверены по сохранённым reference evidence.
- [x] Protocol, CSV observations, success, elapsed, clicks/interactions, paths, diagnostic depth, back-navigation/context loss, first/repeat classification, sample size, median/max сохранены.
- [x] Task Coverage 21/21; фактические destination/return для Q3 — 7/7.
- [x] Отклонения и инструментальные задержки объяснены; prior exposure, исключённые предварительные попытки и неопределённость времени сохранены.
- [x] [Reviewer bundle]({pub['readme_url']}) опубликован, скачан обратно и проверен по SHA-256 `{pub['archive_sha256']}`.
- [x] Canonical AI operator verifier PASS; source CI на том же SHA и его Proof-or-Stop ADMIT проверены.

Human N=0, human usability NOT_MEASURED. Это закрытие операторской задачи по явно изменённому владельцем критерию. Layout, accessibility, lineage/data integrity, исходные regression scenarios и Windows full-profile остаются обязательными для #10185/#10171. При изменении candidate операторский пакет должен пройти проверку применимости и необходимые повторные измерения в итоговой acceptance. Закрытие RF-004 не является разрешением выпуска.

---

'''
r=s.patch(api,json={'body':closeout+issue['body'],'state':'closed','state_reason':'completed'},timeout=30);r.raise_for_status()
r=s.get(api,timeout=30);r.raise_for_status();after=r.json()
assert after['state']=='closed' and '<!-- rf004-ai-accepted-1895351a8a -->' in after['body']
receipt={'closed_at':after['closed_at'],'verified_at':datetime.now(timezone.utc).isoformat(),'number':10167,'state':after['state'],'url':after['html_url'],'candidate_ref':pub['candidate_ref'],'evidence_commit':pub['evidence_commit'],'scope':'AI_SCENARIOS; human usability NOT_MEASURED; RF-005/RF-006 not accepted'}
(base/'rf004-closed.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
