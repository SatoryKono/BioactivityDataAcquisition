"""Provision an isolated localhost Viewer surface for mechanical route checks."""
import hashlib
import json
import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
out=Path(__file__).parent
runtime=out/'browser-runtime'
candidate=root/'.worktrees/operator-acceptance-closeout-20260908'
source=json.loads((out/'candidate.json').read_text())
backend=json.loads((out/'isolated-backend.json').read_text())
env=os.environ.copy()
values=dotenv_values(root/'.env')
env['GF_SECURITY_ADMIN_USER']=values.get('GRAFANA_USERNAME') or values.get('GF_SECURITY_ADMIN_USER') or 'admin'
env['GF_SECURITY_ADMIN_PASSWORD']=values.get('GRAFANA_PASSWORD') or values.get('GF_SECURITY_ADMIN_PASSWORD')
assert env['GF_SECURITY_ADMIN_PASSWORD'], 'Root .env must provide Grafana password'
env['BIOETL_EXPECTED_RUNTIME_SOURCE_ID']=backend['data_source_id']
def run(args):
    r=subprocess.run(args,env=env,capture_output=True,text=True,encoding='utf-8',timeout=60,check=True)
    return r.stdout.strip()
a=json.loads(run(['docker','inspect','bioetl-stream-a-grafana']))[0]
plugins=next(m['Source'] for m in a['Mounts'] if m['Destination']=='/var/lib/grafana/plugins')
datasources={'apiVersion':1,'datasources':[
    {'name':'Prometheus','uid':'prometheus','type':'prometheus','access':'proxy','url':'http://prometheus:9090','isDefault':True,'jsonData':{'timeInterval':'30s'}},
    {'name':'BioETL Ops HTTP','uid':'bioetl-ops-http','type':'yesoreyeram-infinity-datasource','access':'proxy','url':'http://bioetl-stream-b-backend:8000','jsonData':{'allowedHosts':['http://bioetl-stream-b-backend:8000'],'auth_method':'none'}}]}
providers={'apiVersion':1,'providers':[{'name':'BioETL','orgId':1,'folder':'BioETL','folderUid':'bioetl','type':'file','disableDeletion':True,'allowUiUpdates':False,'options':{'path':'/var/lib/grafana/dashboards'}}]}
for directory,payload in [('datasources',datasources),('dashboards',providers)]:
    path=runtime/'provisioning'/directory/'capture.yaml'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(payload,indent=2),encoding='utf-8')
args=['docker','run','-d','--name','bioetl-stream-b-grafana','--network','bioetl-monitoring','--publish','127.0.0.1:3003:3000',
      '--memory','512m','--cpus','1','--label','io.bioetl.acceptance=supplementary-stream-b',
      '--env','GF_AUTH_ANONYMOUS_ENABLED=true','--env','GF_AUTH_ANONYMOUS_ORG_ROLE=Viewer',
      '--env','GF_SECURITY_ADMIN_USER','--env','GF_SECURITY_ADMIN_PASSWORD','--env','BIOETL_EXPECTED_RUNTIME_SOURCE_ID']
for host,target in [(candidate/'grafana/dashboards','/var/lib/grafana/dashboards'),(runtime/'provisioning','/etc/grafana/provisioning'),(Path(plugins),'/var/lib/grafana/plugins')]:
    args+=['--mount',f'type=bind,source={host},target={target},readonly']
args+=[a['Image']]
receipt={'candidate_ref':source['source_sha'],'container_id':run(args),'image_id':a['Image'],'url':'http://127.0.0.1:3003','access':'localhost anonymous Viewer; root .env admin credentials','backend':backend,'dashboard_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (candidate/'grafana/dashboards').glob('*.json')}}
(out/'browser-runtime.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({'url':receipt['url'],'candidate_ref':receipt['candidate_ref'],'container_id':receipt['container_id']}))
