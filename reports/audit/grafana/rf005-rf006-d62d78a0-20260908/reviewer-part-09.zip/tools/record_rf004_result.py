import json
from pathlib import Path
import requests
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
base=Path(__file__).parent
pub=json.loads((base/'rf004-publication.json').read_text(encoding='utf-8'))
verified=json.loads((base/'rf004-publication-verification.json').read_text(encoding='utf-8'))
assert verified['public_download_sha256_verified']
assert any(p['result']['outcome']=='ADMIT' for p in verified['source_ci_proof'])
body=f'''<!-- rf004-ai-evidence-1895351a8a -->
На source-bound candidate `{pub['candidate_ref']}` завершён полный AI-прогон Astra: **21/21 Q1–Q3**, Task Coverage **21/21**, фактические Q3 destination и return **7/7**. Canonical operator verifier: **PASS**. Human N=0, `human_usability_status=NOT_MEASURED`, согласно принятому владельцем изменению scope.

Доступны [reviewer summary]({pub['readme_url']}) и [полный reviewer bundle]({pub['download_url']}). SHA-256 ZIP: `{pub['archive_sha256']}`. Публичное скачивание повторено, хеш совпал.

| Метрика | N | Median | Max |
| --- | ---: | ---: | ---: |
| AI elapsed, s | 21 | 20.888 | 474.778 |
| Clicks | 21 | 0 | 6 |
| Interactions | 21 | 0 | 11 |
| Diagnostic depth | 21 | 0 | 1 |
| Context loss | 21 | 0 | 0 |
| Back-navigation | 21 | 0 | 2 |

Сохранены protocol, CSV observations, метрики, 79 PNG 1366×768/DPR1/scale1, DOM, ответы, paths, raw reference queries, scope receipt, исходные и повторные проверки source/runtime parity. Семь dashboard models и 2469 Python files совпадают с candidate; контейнеры и исходники не менялись во время измерений.

Ограничения: один AI-участник с prior exposure, self-review. Предварительные 20 задач с неверным viewport и незавершённый 12-task fixture run сохранены отдельно и не засчитаны. DQ Q2 и Run Explorer Q3 включают ремонт инструмента в elapsed; старт последней задачи ограничен интервалом 0.111 s, использована консервативная граница. Human target 5–10 s неприменим. Incident намеренно открывает global-object route; исходный context восстановлен при возврате. Replay не запускался.

Source CI [Tests]({verified['source_ci_run']}) успешен; архивный CI Proof-or-Stop повторно проверен: **ADMIT**, exact SHA совпадает. Это отдельная аттестация source, а не обозначение AI-измерений как CI-generated.

Поток A ещё изменяет layout/accessibility. Этот опубликованный результат сохраняется как candidate-specific RF-004 evidence. Перед общей #10185/#10171 acceptance нужно проверить применимость к окончательному совместному candidate и повторить затронутые задачи; текущий комментарий не объявляет общий release gate пройденным.
'''
s=requests.Session();s.headers['Authorization']='Bearer '+dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
url='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition/issues/10167/comments'
r=s.get(url,params={'per_page':100},timeout=30);r.raise_for_status()
assert not any('<!-- rf004-ai-evidence-1895351a8a -->' in c['body'] for c in r.json()), 'Already posted'
r=s.post(url,json={'body':body},timeout=30);r.raise_for_status()
result={'comment_url':r.json()['html_url'],'issue_state_changed':False}
(base/'rf004-issue-update.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
