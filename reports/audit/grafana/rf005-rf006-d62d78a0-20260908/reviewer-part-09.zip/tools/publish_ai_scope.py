import json
import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values

root = Path('E:/github/BioactivityDataAcquisition')
work = root / '.worktrees/operator-acceptance-closeout-20260908'
out = Path(__file__).parent
env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values(root / '.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
env.update(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='safe.directory', GIT_CONFIG_VALUE_0=work.as_posix())
def run(args):
    result = subprocess.run(args, cwd=work, env=env, capture_output=True, text=True, encoding='utf-8', timeout=240)
    print(result.stdout[-2500:] or result.stderr[-2500:])
    result.check_returncode()
    return result.stdout.strip()
branch = 'codex/operator-acceptance-closeout-10167-10185-10171'
assert run(['git', 'branch', '--show-current']) == branch
assert not run(['git', 'status', '--porcelain'])
run(['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential', 'push', '-u', 'origin', branch])
existing = json.loads(run(['gh', 'pr', 'list', '--head', branch, '--json', 'number,url']))
if not existing:
    run(['gh', 'pr', 'create', '--draft', '--base', 'main', '--head', branch, '--title', 'fix(grafana): accept explicitly approved AI operator scenarios', '--body-file', str(out/'ai-scope-pr.md')])
