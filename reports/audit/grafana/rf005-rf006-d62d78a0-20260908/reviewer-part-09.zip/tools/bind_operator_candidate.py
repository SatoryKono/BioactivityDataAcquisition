"""Verify reused runtime source bytes before starting a new AI observation set."""
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import requests

root = Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
candidate = '1895351a8a95f2ca451115be6639b10afba16e03'
out = Path(__file__).parent / 'operator-1895351a8a'
out.mkdir(exist_ok=True)
os.environ.update(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='safe.directory', GIT_CONFIG_VALUE_0=root.as_posix())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True, encoding='utf-8').strip()
assert git('rev-parse', 'HEAD') == candidate
assert not git('status', '--porcelain', '--untracked-files=no')
files = git('ls-files', 'src/bioetl').splitlines()
expected = {p.removeprefix('src/bioetl/'): hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
code = 'import json,sys,pathlib,hashlib,bioetl; root=pathlib.Path(bioetl.__file__).parent; names=json.load(sys.stdin); print(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).is_file() else None for p in names}))'
p = subprocess.run(['docker', 'exec', '-i', 'bioetl-stream-b-backend', 'python', '-c', code], input=json.dumps(list(expected)), capture_output=True, text=True, timeout=45, check=True)
deployed = json.loads(p.stdout)
mismatches = [p for p, digest in expected.items() if deployed.get(p) != digest]
dashboard_rows = []
for path in sorted((root/'grafana/dashboards').glob('*.json')):
    source = json.loads(path.read_text(encoding='utf-8'))
    response = requests.get('http://127.0.0.1:3003/api/dashboards/uid/' + source['uid'], timeout=20)
    response.raise_for_status()
    payload = response.json()
    runtime = payload['dashboard']
    (out/(source['uid']+'-runtime.json')).write_text(json.dumps(payload, indent=2), encoding='utf-8')
    uid = source['uid']
    for obj in (source, runtime):
        obj.pop('id', None)
        obj.pop('version', None)
    dashboard_rows.append({'uid': uid, 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'runtime_equal_except_id_version': source == runtime})
result = {'captured_at': datetime.now(timezone.utc).isoformat(), 'candidate_ref': candidate,
          'runtime_build_ref': 'e2a83a96f8aa9baf944c34ca735e59d3541f5c4c',
          'binding_method': 'New observation of all tracked src/bioetl file hashes in reused container, plus seven provisioned Grafana models compared with current candidate. The image build ref is preserved.',
          'source_file_count': len(expected), 'expected_hashes': expected, 'deployed_hashes': deployed,
          'source_mismatches': mismatches, 'dashboards': dashboard_rows,
          'passed': not mismatches and len(dashboard_rows) == 7 and all(r['runtime_equal_except_id_version'] for r in dashboard_rows)}
(out/'source-binding.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('expected_hashes','deployed_hashes')}))
raise SystemExit(0 if result['passed'] else 1)
