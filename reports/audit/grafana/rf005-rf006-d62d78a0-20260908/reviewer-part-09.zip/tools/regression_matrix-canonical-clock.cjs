const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {chromium}=require('C:/Users/Fedor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const width=Number(process.argv[2]||900);
const base=path.join(__dirname,'integrated-07528418e7a');
const out=path.join(base,'regression-canonical-clock-'+width);
fs.mkdirSync(out,{recursive:true});
const candidate='07528418e7abfa5535ed50aee009b73f9fb87899';
const uids=['bioetl-control-plane-v1','bioetl-overview-v2','bioetl-runtime','bioetl-provider-health-v2','bioetl-dq-v2','bioetl-incident-v1','bioetl-run-explorer-v1'];
const labels=['0. Trust','1. Overview','2. Pipeline Diagnostics','3. Provider Health','4. Data Quality','5. Incident Workspace','6. Run Explorer'];
const run='b9d2eeff-8e4b-5678-ae32-b288ced27968';
const modes=['all','single-outside','single-inside','multi','missing','query-error'];
const records=[];
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
let context,page;
function params(mode){
 const p=new URLSearchParams({'var-workflow':'$__all','var-pipeline':'chembl_assay','var-run_type':mode==='all'?'$__all':'backfill','var-run_id':mode==='all'?'-':mode==='missing'?'00000000-0000-0000-0000-000000000000':run,'var-provider':'chembl','var-pipeline_context':'chembl_assay','var-provider_hint':'chembl','var-stage':'$__all',from:mode==='single-inside'||mode==='multi'?'2026-09-08T05:10:00.000Z':'2026-09-08T08:30:00.000Z',to:mode==='single-inside'||mode==='multi'?'2026-09-08T05:15:00.000Z':'2026-09-08T09:00:00.000Z',timezone:'utc',theme:'dark'});
 if(mode==='multi')p.append('var-run_type','incremental');
 return p;
}
async function settled(){
 await page.waitForLoadState('networkidle',{timeout:25000});
 await page.getByText('Navigate Dashboards',{exact:true}).waitFor({timeout:20000});
 await page.waitForTimeout(400);
}
async function capture(name){
 const png=name+'.png',dom=name+'.txt';
 await page.screenshot({path:path.join(out,png)});
 fs.writeFileSync(path.join(out,dom),await page.locator('body').ariaSnapshot());
 const measured=await page.evaluate(()=>({viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,scale:visualViewport.scale},pageHorizontalOverflow:document.documentElement.scrollWidth>innerWidth+1,regions:[...document.querySelectorAll('section[aria-label]')].map(el=>{const r=el.getBoundingClientRect();return {name:el.getAttribute('aria-label'),x:r.x,y:r.y,width:r.width,height:r.height,visible:r.bottom>0&&r.top<innerHeight,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth};})}));
 const value={candidate_ref:candidate,captured_at:new Date().toISOString(),url:page.url(),...measured,png:{path:png,sha256:hash(fs.readFileSync(path.join(out,png)))},dom:{path:dom,sha256:hash(fs.readFileSync(path.join(out,dom)))}};
 fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify(value,null,2));
 return {path:name+'.json',sha256:hash(fs.readFileSync(path.join(out,name+'.json')))};
}
const normalizedTypes=url=>new URL(url).searchParams.getAll('var-run_type').flatMap(v=>v.split(',')).sort();
async function expandAndCapture(prefix){
 const evidence=[];
 const seen=new Set();
 for(let step=0;step<22;step++){
   const buttons=page.getByRole('button',{name:'Expand row',exact:true});
   for(let j=0;j<await buttons.count();j++){
     const b=buttons.nth(j);const text=await b.innerText();
     if(seen.has(text))continue;
     await b.scrollIntoViewIfNeeded();await b.click();seen.add(text);j--;
     await page.waitForTimeout(250);
   }
   evidence.push(await capture(prefix+'-expanded-'+step));
   const moved=await page.evaluate(()=>{
     const candidates=[...document.querySelectorAll('*')].filter(el=>el.clientHeight>200&&el.scrollHeight>el.clientHeight+10&&/auto|scroll/.test(getComputedStyle(el).overflowY)).sort((a,b)=>b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight);
     const el=candidates[0];if(!el)return false;const before=el.scrollTop;el.scrollTop=Math.min(el.scrollHeight-el.clientHeight,before+600);return Math.abs(el.scrollTop-before)>1;
   });
   if(!moved)break;
   await page.waitForTimeout(450);
 }
 return {expanded_rows:[...seen],evidence};
}
(async()=>{
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 try{
  context=await browser.newContext({viewport:{width,height:768},deviceScaleFactor:1,timezoneId:'UTC'});
  page=await context.newPage();
  const binding=[];
  for(const uid of uids){
    const response=await context.request.get('http://127.0.0.1:3004/api/dashboards/uid/'+uid);
    const runtime=(await response.json()).dashboard,source=JSON.parse(fs.readFileSync(path.join(base,'dashboards',uid+'.json'),'utf8'));
    for(const obj of [runtime,source]){delete obj.id;delete obj.version;}
    const canonical=v=>JSON.stringify(v,Object.keys(v));
    const equal=require('node:util').isDeepStrictEqual(runtime,source);
    if(!equal)throw Error('Source model mismatch '+uid);
    binding.push({uid,equal_except_id_version:true,source_sha256:hash(fs.readFileSync(path.join(base,'dashboards',uid+'.json')))});
  }
  fs.writeFileSync(path.join(out,'source-binding.json'),JSON.stringify({candidate_ref:candidate,captured_at:new Date().toISOString(),dashboards:binding},null,2));
  for(const mode of modes){
   if(mode==='query-error')await page.route('**/api/ds/query*',route=>route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({message:'Controlled regression query error',error:'acceptance_fault_injection'})}));
   for(let i=0;i<uids.length;i++){
    const uid=uids[i],prefix=uid+'-'+mode;
    const row={candidate_ref:candidate,uid,mode,viewport:[width,768],started_at:new Date().toISOString(),status:'OBSERVED',fault_injection:mode==='query-error'};
    try{
     await page.goto('http://127.0.0.1:3004/d/'+uid+'/'+uid+'?'+params(mode),{waitUntil:'networkidle',timeout:35000});
     await settled();
     if(width===1366){const open=page.getByRole('button',{name:'Open menu',exact:true});if(await open.isVisible())await open.click();const pin=page.getByRole('button',{name:'Pin menu',exact:true});if(await pin.isVisible())await pin.click();}
     row.initial=await capture(prefix+'-initial');
     row.body_signals=await page.locator('body').innerText().then(text=>['SELECT RUN','INCOMPLETE','UNKNOWN','TELEMETRY MISSING','VALID EMPTY','QUERY ERROR','OUT OF RANGE','success','Controlled regression query error'].filter(s=>text.toLowerCase().includes(s.toLowerCase())));
     if(mode==='query-error'){
      row.query_error_visible=(await page.locator('body').innerText()).toLowerCase().includes('error');
      row.error_indicators=await page.locator('[aria-label],[title]').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('aria-label')||n.getAttribute('title')).filter(t=>/error/i.test(t||'')));
     }else{
      const sourceUrl=page.url();
      const next=(i+1)%uids.length;
      await page.getByRole('link',{name:labels[next],exact:true}).click();
      await settled();
      const targetUrl=page.url(),p=new URL(targetUrl).searchParams,original=new URL(sourceUrl).searchParams;
      row.navigation={source:sourceUrl,destination:targetUrl,expected_uid:uids[next],destination_uid_preserved:targetUrl.includes('/d/'+uids[next]+'/'),pipeline_preserved:p.get('var-pipeline')===original.get('var-pipeline'),run_id_preserved:p.get('var-run_id')===original.get('var-run_id'),run_types_preserved:JSON.stringify(normalizedTypes(targetUrl))===JSON.stringify(normalizedTypes(sourceUrl)),from_preserved:Date.parse(p.get('from'))===Date.parse(original.get('from')),to_preserved:Date.parse(p.get('to'))===Date.parse(original.get('to')),timezone_preserved:p.get('timezone')==='utc'};
      row.destination=await capture(prefix+'-destination');
      await page.goBack({waitUntil:'networkidle'});await settled();
      row.returned=await capture(prefix+'-return');
      row.navigation.return_uid_preserved=page.url().includes('/d/'+uid+'/');
      if(mode==='single-outside')row.expanded=await expandAndCapture(prefix);
     }
    }catch(e){row.status='HARNESS_OR_PRODUCT_ERROR';row.error=String(e.stack||e);try{row.error_capture=await capture(prefix+'-error');}catch{}}
    row.ended_at=new Date().toISOString();records.push(row);
    fs.writeFileSync(path.join(out,'observations.json'),JSON.stringify({candidate_ref:candidate,records},null,2));
    console.log(JSON.stringify({width,uid,mode,status:row.status,navigation:row.navigation?Object.entries(row.navigation).filter(([k,v])=>k.endsWith('preserved')&&v===false).map(([k])=>k):null,error:row.error?.split('\n')[0]}));
   }
   if(mode==='query-error')await page.unroute('**/api/ds/query*');
  }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
