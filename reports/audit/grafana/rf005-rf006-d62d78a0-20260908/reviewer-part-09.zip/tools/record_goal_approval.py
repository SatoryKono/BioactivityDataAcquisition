import json
from pathlib import Path
import requests
from dotenv import dotenv_values
session=requests.Session()
session.headers['Authorization']='Bearer '+dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
base='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition/issues/'
marker='<!-- bioetl-ai-page-goals:20260908 -->'
text='''Семь page goals и диагностическая роль Astra подтверждены владельцем: «Подтверждаю эти семь целей». Trust — evidence для replay; Overview — fleet/первое действие; Runtime — blockers/missing telemetry; Provider — влияние/причина; DQ — current quality/range rejects; Incident — гипотеза/основание/безопасный переход; Run Explorer — поиск run/exact-run evidence. Replay не запускается.

Протокол и fail-closed AI gate реализованы в [PR #10232](https://github.com/SatoryKono/BioactivityDataAcquisition/pull/10232). Подтверждение целей не заменяет результаты 21 задачи и общую regression acceptance.
'''
receipts=[]
for n in (10167,10185,10171):
    r=session.get(base+str(n),timeout=30); r.raise_for_status(); issue=r.json()
    if marker in issue['body']:
        continue
    assert '<!-- bioetl-ai-operator-scope:20260908 -->' in issue['body']
    body=marker+'\n'+text+'\n---\n\n'+issue['body']
    payload={'body':body}
    if n==10167:
        payload['title']='[P2][Grafana][LAY-003] Проверить AI-сценарии Q1–Q3 и diagnostic click depth'
    r=session.patch(base+str(n),json=payload,timeout=30); r.raise_for_status()
    receipts.append({'number':n,'state':r.json()['state'],'updated_at':r.json()['updated_at']})
Path(__file__).with_name('page-goal-approval-publication.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
print(json.dumps(receipts))
