import json
import sys
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

sys.stdout.reconfigure(encoding='utf-8')
root = Path('E:/github/BioactivityDataAcquisition')
session = requests.Session()
session.headers.update({'Authorization': 'Bearer ' + dotenv_values(root / '.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'], 'Cache-Control': 'no-cache'})
base = 'https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(path):
    response = session.get(base + path, timeout=30)
    response.raise_for_status()
    return response.json()
data = {'captured_at': datetime.now(timezone.utc).isoformat(), 'main_sha': get('/commits/main')['sha'], 'prs': get('/pulls?state=open&per_page=30'), 'issues': [get(f'/issues/{n}') for n in (10167,10185,10171,10186,10165,10170)]}
path = Path(__file__).parent / ('scope-live-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.json')
path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'path': str(path), 'main_sha': data['main_sha'], 'prs': [{'number': p['number'], 'branch': p['head']['ref'], 'sha': p['head']['sha']} for p in data['prs']], 'issues': [{'number': i['number'], 'state': i['state'], 'title': i['title']} for i in data['issues']]}, ensure_ascii=False))
