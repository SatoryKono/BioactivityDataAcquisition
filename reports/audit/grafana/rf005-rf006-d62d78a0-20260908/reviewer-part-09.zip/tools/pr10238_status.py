import json
from datetime import datetime,timezone
from pathlib import Path
import requests
from dotenv import dotenv_values
b=Path(__file__).parent;s=requests.Session();s.headers['Authorization']='Bearer '+dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'];api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(p):
 r=s.get(api+p,timeout=30);r.raise_for_status();return r.json()
pr=get('/pulls/10238');checks=get('/commits/'+pr['head']['sha']+'/check-runs?per_page=100')['check_runs'];issues=[get('/issues/'+str(n)) for n in (10186,10165,10170)];result={'at':datetime.now(timezone.utc).isoformat(),'pr':pr,'checks':checks,'dependencies':issues};(b/'pr10238-status.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'head':pr['head']['sha'],'state':pr['state'],'mergeable':pr['mergeable'],'mergeable_state':pr['mergeable_state'],'checks':len(checks),'unfinished':[c['name'] for c in checks if c['status']!='completed'],'failures':[c['name'] for c in checks if c['conclusion'] in ('failure','cancelled','timed_out')],'dependencies':[{ 'id':i['number'],'state':i['state']} for i in issues]}))
