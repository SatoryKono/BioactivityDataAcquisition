"""Compare old/fresh HTTP projections with the immutable selected-run report."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import requests

root = Path('E:/github/BioactivityDataAcquisition')
out = Path(__file__).parent
run_id = 'b9d2eeff-8e4b-5678-ae32-b288ced27968'
raw_path = root / f'reports/run-reports/pipeline/chembl_assay/{run_id}/pipeline-run-report.json'
raw_bytes = raw_path.read_bytes()
raw = json.loads(raw_bytes)
session = requests.Session()
session.headers['Cache-Control'] = 'no-cache'
captured = datetime.now(timezone.utc).isoformat()
observations = []
for label, port in [('old', 8000), ('candidate', 8002)]:
    for scenario, selection in [('selected', run_id), ('unselected', '-'), ('missing', '00000000-0000-0000-0000-000000000000')]:
        url = f'http://127.0.0.1:{port}/ops/observability/pipeline-run-report'
        response = session.get(url, params={'pipeline': 'chembl_assay', 'run_id': selection}, timeout=30)
        response.raise_for_status()
        payload = response.json()
        evidence = {'captured_at': captured, 'url': response.url, 'http_status': response.status_code, 'payload': payload}
        filename = f'backend-{label}-{scenario}.json'
        (out / filename).write_text(json.dumps(evidence, indent=2), encoding='utf-8')
        checks = {'display_selectors_present': all(k in payload for k in ('funnel_display', 'reasons_top_n_display', 'artifacts_display'))}
        if scenario == 'selected':
            checks['exact_run_id'] = payload['identity']['run_id'] == run_id
            checks['raw_funnel_rows_preserved'] = all(all(actual.get(k) == value for k, value in expected.items()) for actual, expected in zip(payload['funnel'], raw['funnel'], strict=True))
            checks['reason_rows_equal_raw'] = payload['reasons_top_n'] == raw['reasons_top_n']
            checks['display_funnel_equals_actual'] = payload.get('funnel_display') == payload['funnel']
            checks['display_reasons_equals_actual'] = payload.get('reasons_top_n_display') == payload['reasons_top_n']
        else:
            state = 'SELECT RUN' if scenario == 'unselected' else 'TELEMETRY MISSING'
            checks['state_preserved'] = any(state in row.values() for row in payload.get('funnel_display', []))
            checks['raw_arrays_stay_empty'] = payload['funnel'] == payload['reasons_top_n'] == []
        observations.append({'runtime': label, 'scenario': scenario, 'evidence': filename, 'checks': checks})
code = "import hashlib,json,pathlib; import bioetl.interfaces.http._pipeline_run_report_table as m; p=pathlib.Path(m.__file__); print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))"
module_hashes = {}
for container in ('bioetl', 'bioetl-stream-b-backend'):
    result = subprocess.run(['docker', 'exec', container, 'python', '-c', code], capture_output=True, text=True, timeout=30, check=True)
    module_hashes[container] = json.loads(result.stdout)
source_path = root / '.worktrees/operator-acceptance-closeout-20260908/src/bioetl/interfaces/http/_pipeline_run_report_table.py'
source_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
result = {'captured_at': captured, 'source_ref': 'e2a83a96f8aa9baf944c34ca735e59d3541f5c4c', 'raw_report_path': str(raw_path),
          'raw_report_sha256': hashlib.sha256(raw_bytes).hexdigest(), 'observations': observations,
          'deployed_module_hashes': module_hashes, 'candidate_module_sha256': source_hash,
          'source_matches_deployed': source_hash == module_hashes['bioetl-stream-b-backend']['sha256'],
          'scope': 'Real selected, unselected and missing HTTP scenarios. VALID EMPTY is unit-tested, not a real-run measurement here.'}
result['candidate_passed'] = result['source_matches_deployed'] and all(all(r['checks'].values()) for r in observations if r['runtime'] == 'candidate')
(out / 'backend-regression-proof.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['candidate_passed'] else 1)
