"""Post-session read-only parity and additional RF-004 reviewer artifacts."""
import csv
import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
import requests

base = Path(__file__).parent
bundle = base / 'rf004-reviewer-bundle-1895351a8a'
repo = Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
original = json.loads((bundle/'source-binding.json').read_text(encoding='utf-8'))
candidate = original['candidate_ref']
expected = original['expected_hashes']
code = 'import json,sys,pathlib,hashlib,bioetl; root=pathlib.Path(bioetl.__file__).parent; names=json.load(sys.stdin); print(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).is_file() else None for p in names}))'
result = subprocess.run(['docker','exec','-i','bioetl-stream-b-backend','python','-c',code],input=json.dumps(list(expected)),capture_output=True,text=True,check=True,timeout=45)
deployed = json.loads(result.stdout)
assert deployed == original['deployed_hashes'], 'Runtime source changed during session'
dashboards = []
for path in sorted((repo/'grafana/dashboards').glob('*.json')):
    source = json.loads(path.read_text(encoding='utf-8'))
    response = requests.get('http://127.0.0.1:3003/api/dashboards/uid/'+source['uid'],timeout=20)
    response.raise_for_status()
    runtime = response.json()['dashboard']
    for model in (source,runtime):
        model.pop('id',None); model.pop('version',None)
    dashboards.append({'uid':source['uid'],'equal_except_id_version':source==runtime})
assert len(dashboards)==7 and all(d['equal_except_id_version'] for d in dashboards)
containers=[]
for name, identity in [('bioetl-stream-b-backend','f63c8c6e8e5f294f7882f9c2174a18f6c50ff431f98b9c4931bd5da0dabfb6ed'),('bioetl-stream-b-grafana','a2326c297d95929dd1d1adee380cd4045c0646788e5fdbba85021fe685beb857')]:
    output=subprocess.check_output(['docker','inspect','--format','{{.Id}} {{.Image}} {{.State.Running}}',name],text=True).strip().split()
    assert output[0]==identity and output[2]=='true'
    containers.append({'name':name,'id':output[0],'image':output[1],'running':True})
def write(name,data):
    (bundle/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
write('post-session-parity.json',{'captured_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':candidate,'status':'PASS','source_hashes_unchanged':True,'python_files':sum(p.endswith('.py') for p in expected),'dashboards':dashboards,'containers':containers,'scope':'Endpoint identities and source bytes verified before and after session; this does not establish final Stream A parity.'})
receipt=json.loads((bundle/'operator-receipt.json').read_text(encoding='utf-8'))
records=receipt['observations']
fields=['task_id','participant_id','participant_type','attempt_kind','success','elapsed_seconds','clicks','interactions','diagnostic_depth','context_loss','back_navigation','first_correct_seconds','started_at','ended_at','answer','path','destination_verified','return_verified','prior_exposure','attempt_kind_definition']
with (bundle/'operator-observations.csv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=fields)
    writer.writeheader()
    for row in records:
        writer.writerow({key:json.dumps(row.get(key),ensure_ascii=False) if isinstance(row.get(key),(list,dict)) else row.get(key) for key in fields})
gate=json.loads((bundle/'operator-gate.json').read_text(encoding='utf-8'))
q3=[r for r in records if r['task_id'].endswith(':Q3')]
write('operator-metrics.json',{'candidate_ref':candidate,'task_coverage':{'passed':sum(r['success'] for r in records),'required':21,'percent':100},'drill_down_coverage':{'destination_and_return_verified':sum(r['destination_verified'] and r['return_verified'] for r in q3),'required':7,'percent':100},'ai_participants':1,'human_participants':0,'human_usability_status':'NOT_MEASURED','human_target_comparison':'NOT_APPLICABLE_BY_APPROVED_SCOPE','statistics':gate['result']['statistics']})
(bundle/'layout-observation-report.md').write_text('# RF-004 observed layout and navigation\n\nCandidate '+candidate+'. All 21 tasks were completed at 1366x768, dark theme, DPR 1 and viewport scale 1. Task coverage 21/21; Q3 destination and return 7/7. These are observed AI task metrics; full layout/accessibility release acceptance remains with RF-005 and Stream A.\n\nMeasured friction: Run Explorer panel 3013 required nested table scrolling and row expansion to reach the artifact link. Q2 took 232.261 s; Q3 took 474.778 s including a capture harness repair. No product layout change is justified by these mixed tool/model execution times alone. A future human study can test whether an earlier exact-run artifact link reduces search effort. No human timing target or layout PASS is inferred. DQ Q2 took 190.730 s including a scroll-target repair; the range cards correctly remained UNKNOWN.\n\nTool handling: the corrected capture harness brings the page to the foreground and bounds animation-frame waiting; scrolling uses the visible dashboard surface. Repair pauses and unsuccessful preliminary attempts remain in the bundle. No failed product finding was silently waived.\n',encoding='utf-8')
with (bundle/'README.md').open('a',encoding='utf-8') as f:
    f.write('\nPost-session verification: all source hashes, seven dashboard models and both container identities remain unchanged. CSV observations, explicit Task Coverage 21/21 and Drill-down Coverage 7/7, and a bounded layout observation report are included.\n')
inventory=[{'path':p.relative_to(bundle).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(bundle.rglob('*')) if p.is_file() and p.name!='manifest.json']
write('manifest.json',{'candidate_ref':candidate,'files':inventory})
archive_path=base/'rf004-reviewer-bundle-1895351a8a-sealed.zip'
with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(bundle.rglob('*')):
        if p.is_file():archive.write(p,p.relative_to(bundle).as_posix())
print(json.dumps({'status':'PASS','candidate_ref':candidate,'archive':str(archive_path),'sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),'size_bytes':archive_path.stat().st_size,'files':len(inventory)}))
