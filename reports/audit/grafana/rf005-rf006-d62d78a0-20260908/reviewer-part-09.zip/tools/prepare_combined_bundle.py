"""Collect original evidence with unchanged bytes and explicit source scopes."""
import hashlib,json,shutil,subprocess
from datetime import datetime,timezone
from pathlib import Path
base=Path(__file__).parent
bundle=base/'combined-reviewer-bundle'
bundle.mkdir(exist_ok=True)
a=Path('E:/github/BioactivityDataAcquisition-stream-a/reports/observability/stream-a-evidence-68ec26b17b')
allowed={'.json','.png','.txt','.md','.cjs','.py','.ts','.gz','.zip','.bundle','.xml','.log','.yml'}
def copy_tree(src,dest,exclude=()):
 for p in src.rglob('*'):
  rel=p.relative_to(src)
  if not p.is_file() or any(part in exclude for part in rel.parts) or p.suffix not in allowed:continue
  q=bundle/dest/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
copy_tree(a,Path('stream-a'))
copy_tree(base/'operator-integration-reviewer-bundle',Path('operator'))
copy_tree(base/'retest-preparation',Path('baseline'))
copy_tree(base/'integrated-07528418e7a',Path('integration'),('regression-900','regression-1366','supplement-900','supplement-1366','data'))
copy_tree(base/'reference-fixture',Path('reference'),('data','grafana-data','plugins','node_modules'))
copy_tree(base/'integrity-1895351a8a',Path('live-integrity'))
copy_tree(base/'windows-full-profile-readback',Path('windows'))
for folder in ('windows-final-main-check','windows-final-main-start','windows-final-monitoring-start'):
 copy_tree(base/folder,Path('windows')/folder)
for p in base.glob('*.py'):
 q=bundle/'tools'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
for p in base.glob('*.cjs'):shutil.copyfile(p,bundle/'tools'/p.name)
for name in ('backlog-history.json','backlog-retest-register.json','ai-scope-decision.json','final-candidate-equivalence-preflight.json','backend-regression-proof.json'):
 shutil.copyfile(base/name,bundle/name)
def dump(name,value):
 p=bundle/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def desc(name):return {'path':name,'sha256':hashlib.sha256((bundle/name).read_bytes()).hexdigest()}
access=json.loads((bundle/'stream-a/accessibility-status.json').read_text())
assert access['status']=='PASS' and access['matrix']['status']=='PASS'
totals={k:{'passed':0,'required':0,'failed':0,'unmeasured':0,'exempt_disabled':0} for k in ('text','graphics')}
for profile in access['profiles']:
 assert profile['layout_status']=='PASS' and profile['accessibility_status']=='PASS'
 for dashboard in profile['dashboards']:
  for kind in totals:
   r=dashboard['accessibility'][kind]
   for output,key in [('passed','numerator'),('required','denominator'),('failed','failed'),('unmeasured','unmeasured'),('exempt_disabled','exempt_disabled')]:totals[kind][output]+=r.get(key,0)
dump('reviews/accessibility-consumption.json',{'source':desc('stream-a/accessibility-status.json'),'profiles':len(access['profiles']),'dashboard_observations':sum(len(p['dashboards']) for p in access['profiles']),'totals':totals,'layout_passed':all(p['layout_status']=='PASS' for p in access['profiles']),'scope':'Original Stream A capture and cue review, with separate numeric reference/live-UNKNOWN supplements. No capture source SHA or runtime variables were retagged.'})
nav=[]
for width in (900,1366):
 p=f'integration/regression-canonical-clock-{width}/observations.json';d=json.loads((bundle/p).read_text())
 nav.append({'width':width,'records':len(d['records']),'errors':sum(r['status']!='OBSERVED' for r in d['records']),'navigation': [r['navigation'] for r in d['records'] if r.get('navigation')],'source':desc(p)})
dump('reviews/navigation-consumption.json',{'profiles':nav})
dump('reviews/owner-data-integrity-scope.json',{'approved_by':'task owner, explicit conversation reply','approved_at':'2026-09-08','reply':'Использовать изолированный эталонный набор и отдельно проверить живые UNKNOWN-состояния','interpretation':'Known-input numerical conformance is accepted as the numeric reference; live missing telemetry remains NOT_VERIFIABLE/UNKNOWN and does not become production completeness or replay approval.','human_usability_status':'NOT_MEASURED'})
dump('collection-receipt.json',{'collected_at':datetime.now(timezone.utc).isoformat(),'files':sum(p.is_file() for p in bundle.rglob('*')),'bytes':sum(p.stat().st_size for p in bundle.rglob('*') if p.is_file()),'status':'COLLECTED_PENDING_FINAL_ACCEPTANCE','source_scopes':['Stream A captures 68ec26b17b, fixed 00:00–06:00 UTC','Stream B integration models 07528418e7a, live selected-run 08:30–09:00 and 05:10–05:15 UTC','Reference Prometheus known input, separate 15-minute and 6-hour windows','Canonical Windows runtime source bound by separate receipt']})
print(json.dumps({'bundle':str(bundle),'accessibility':totals,'files':sum(p.is_file() for p in bundle.rglob('*'))}))
