import concurrent.futures
import json
import os
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from dotenv import dotenv_values

repo = 'SatoryKono/BioactivityDataAcquisition'
env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
out = Path(__file__).parent

def gh(args):
    p = subprocess.run(['gh', *args], env=env, capture_output=True, text=True, encoding='utf-8', timeout=150)
    if p.returncode:
        raise RuntimeError(p.stderr)
    return p.stdout

pr = json.loads(gh(['pr', 'view', '10232', '--repo', repo, '--json', 'number,url,headRefOid,baseRefOid,isDraft,state,mergeable,statusCheckRollup']))
sha = pr['headRefOid']
pr['captured_at'] = datetime.now(timezone.utc).isoformat()
out = out / sha
out.mkdir(exist_ok=True)
(out / 'pr.json').write_text(json.dumps(pr, indent=2), encoding='utf-8')
runs = json.loads(gh(['run', 'list', '--repo', repo, '--commit', sha, '--limit', '100', '--json', 'databaseId,name,status,conclusion,event,headSha,url']))
(out / 'runs.json').write_text(json.dumps(runs, indent=2), encoding='utf-8')
print(json.dumps({'sha': sha, 'mergeable': pr['mergeable'], 'runs': [{'id': r['databaseId'], 'name': r['name'], 'status': r['status'], 'conclusion': r['conclusion']} for r in runs]}), flush=True)

def failure(run):
    data = json.loads(gh(['run', 'view', str(run['databaseId']), '--repo', repo, '--json', 'jobs']))
    (out / f"{run['databaseId']}-jobs.json").write_text(json.dumps(data, indent=2), encoding='utf-8')
    jobs = [j for j in data['jobs'] if j['conclusion'] == 'failure']
    for job in jobs:
        if (out / f"{job['databaseId']}.log").exists():
            continue
        log = gh(['api', f"repos/{repo}/actions/jobs/{job['databaseId']}/logs"])
        (out / f"{job['databaseId']}.log").write_text(log, encoding='utf-8')
    return {'run': run['name'], 'failed_jobs': [{'id': j['databaseId'], 'name': j['name'], 'steps': [s['name'] for s in j['steps'] if s['conclusion'] == 'failure']} for j in jobs], 'unfinished': [j['name'] for j in data['jobs'] if j['status'] != 'completed']}

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(failure, [r for r in runs if r['conclusion'] == 'failure' or r['status'] == 'in_progress']):
        print(json.dumps(result), flush=True)
