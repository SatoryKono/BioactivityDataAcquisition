import concurrent.futures
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
import requests

base = Path(__file__).parent
out = base / 'operator-07528418e7a'
root = Path('E:/github/BioactivityDataAcquisition-stream-a')
candidate = '07528418e7abfa5535ed50aee009b73f9fb87899'
binding = json.loads((out/'source-binding.json').read_text(encoding='utf-8'))
omitted = binding['source_mismatches']
assert all(p.endswith('/README.md') or p in ('README.md', 'application/core/.gitkeep') for p in omitted)
assert all(binding['deployed_hashes'][p] is None for p in omitted)
python_files = [p for p in binding['expected_hashes'] if p.endswith('.py')]
assert all(binding['expected_hashes'][p] == binding['deployed_hashes'][p] for p in python_files)
assert all(r['runtime_equal_except_id_version'] for r in binding['dashboards'])
adjudication = {'candidate_ref': candidate, 'runtime_source_status': 'PASS', 'python_files_checked': len(python_files), 'omitted_non_runtime_files': omitted, 'disposition': 'Seven README.md files are excluded by the existing .dockerignore *.md rule. The remaining empty .gitkeep is a source-control directory placeholder, not executable package content. All other tracked package file hashes and all seven provisioned dashboard models match.', 'original_observation': {'path': 'source-binding.json', 'sha256': hashlib.sha256((out/'source-binding.json').read_bytes()).hexdigest()}}
(out/'source-binding-adjudication.json').write_text(json.dumps(adjudication, indent=2), encoding='utf-8')
protocol = json.loads((root/'docs/03-guides/dashboards/contracts/operator-task-protocol.json').read_text(encoding='utf-8'))
values = {'pipeline':'chembl_assay', 'run_type':'backfill', 'run_id':'b9d2eeff-8e4b-5678-ae32-b288ced27968', 'workflow':'.*', 'provider':'chembl', 'stage':'.*', 'provider_hint':'chembl', 'pipeline_context':'chembl_assay', '__range':'30m', '__range_s':'1800', '__interval':'30s', '__rate_interval':'1m'}
start = int(datetime(2026,9,8,8,30,tzinfo=timezone.utc).timestamp())
end = start + 1800
def interpolate(text, url=False):
    def replace(m):
        name = m.group(1) or m.group(3)
        value = values.get(name, m.group(0))
        if url and m.group(2) == 'percentencode':
            return quote(value, safe='')
        return value
    return re.sub(r'\$\{(\w+)(?::(\w+))?\}|\$(\w+)', replace, text)
def panels(rows):
    for panel in rows:
        yield panel
        yield from panels(panel.get('panels', []))
jobs = {}
task_keys = []
for task in protocol['tasks']:
    source = json.loads((root/f"grafana/dashboards/{task['dashboard_uid']}.json").read_text(encoding='utf-8'))
    panel_map = {p['id']:p for p in panels(source['panels'])}
    target_refs=[]
    for descriptor in task['target_panels']:
        panel = panel_map.get(descriptor['panel_id'])
        if panel is None:
            continue
        for i,target in enumerate(panel.get('targets', [])):
            expr = interpolate(target.get('expr',''))
            url = interpolate(target.get('url',''), url=True)
            if not expr and not url:
                continue
            key = f"{source['uid']}-{panel['id']}-{i}"
            jobs[key] = {'id':key,'panel_id':panel['id'],'title':panel.get('title'), 'description':panel.get('description'), 'field_config':panel.get('fieldConfig'), 'expr':expr, 'ops_path':url, 'instant':target.get('instant',False)}
            target_refs.append(key+'.json')
    task_keys.append({'task_id':task['task_id'],'question':task['question'],'page_goal':task['page_goal'],'answer_rubric':task['answer_rubric'],'reference_files':target_refs,'q3_rule':'Observed safe destination and return with allowed context; no replay execution' if task['task_id'].endswith(':Q3') else None})
raw = out/'answer-key-raw'
raw.mkdir(exist_ok=True)
def fetch(item):
    endpoint = 'http://127.0.0.1:9090/api/v1/' + ('query' if item['instant'] else 'query_range')
    params = {'query':item['expr'], 'time':end} if item['instant'] else {'query':item['expr'],'start':start,'end':end,'step':30}
    if item['ops_path']:
        endpoint = 'http://127.0.0.1:8002'+item['ops_path']
        params = None
    payload = {'captured_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':candidate,'source':item,'endpoint':endpoint,'params':params,'scope':'Ops endpoints are current-state projections, not historical replay; Prometheus is evaluated at the fixed window.'}
    try:
        response=requests.get(endpoint,params=params,timeout=20)
        payload.update(http_status=response.status_code,response=response.json())
    except (requests.RequestException,ValueError) as exc:
        payload['error']=type(exc).__name__
    (raw/(item['id']+'.json')).write_text(json.dumps(payload,indent=2),encoding='utf-8')
    return {'id':item['id'],'http_status':payload.get('http_status'),'error':payload.get('error')}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(fetch,jobs.values()))
keys={'candidate_ref':candidate,'fixture_id':'observed-chembl-assay-report-degraded-telemetry','time_range':{'from':start*1000,'to':end*1000,'timezone':'UTC'},'variables':values,'tasks':task_keys,'reference_inventory':results,'reviewer':'Astra AI, source/rubric review; not an independent human reviewer','human_usability_status':'NOT_MEASURED'}
(out/'answer-keys.json').write_text(json.dumps(keys,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'operator-task-protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'python_source_files_equal':len(python_files),'tasks':len(task_keys),'reference_requests':len(results),'request_errors':[r for r in results if r['error'] or r['http_status']!=200]}))
