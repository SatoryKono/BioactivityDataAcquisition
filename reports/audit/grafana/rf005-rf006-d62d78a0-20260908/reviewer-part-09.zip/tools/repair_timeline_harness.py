from pathlib import Path
b=Path(__file__).parent
s=(b/'timeline-tooltip-retest-v2.cjs').read_text().replace("'timeline-tooltips-v2'","'timeline-tooltips-v3'")
needle="await page.getByRole('button',{name:'Expand row',exact:true}).filter({hasText:'Review Alert Evidence'}).click();"
replacement="""await page.getByText('Navigate Dashboards',{exact:true}).waitFor();
await page.mouse.move(width-8,700);
for(let n=0;n<8 && await page.getByRole('button',{name:'Expand row',exact:true}).count()===0;n++){await page.mouse.wheel(0,450);await page.waitForTimeout(300);}
const rows=page.getByRole('button',{name:'Expand row',exact:true}); result.row_texts=await rows.allTextContents();
await rows.filter({hasText:'Review Alert Evidence'}).click();"""
assert needle in s;s=s.replace(needle,replacement)
(b/'timeline-tooltip-retest-v3.cjs').write_text(s)
s=s.replace("'timeline-tooltips-v3'","'timeline-tooltips-v4'").replace("const panel=page.locator('[data-viz-panel-key=\"panel-2006\"]');await panel.scrollIntoViewIfNeeded();", "const panel=page.locator('[data-viz-panel-key=\"panel-2006\"]');for(let n=0;n<8 && await panel.count()===0;n++){await page.mouse.move(width-8,700);await page.mouse.wheel(0,350);await page.waitForTimeout(300);}await panel.scrollIntoViewIfNeeded();")
(b/'timeline-tooltip-retest-v4.cjs').write_text(s)
