import json
import sys
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

sys.stdout.reconfigure(encoding='utf-8')
out = Path(__file__).parent
session = requests.Session()
session.headers.update({'Authorization': 'Bearer ' + dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']})
base = 'https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition/issues/'
marker = '<!-- bioetl-ai-operator-scope:20260908 -->'
revision = '''## Согласованное изменение операторской приёмки · 08.09.2026

Владелец подтвердил: «Astra — AI-агент», затем явно выбрал «Принять только AI-проверку сценариев».

Этот раздел заменяет требование human tasks только для #10167 и операторской части #10185/#10171. Выполняются 21 AI-сценарий (семь dashboards × Q1–Q3) на source-bound candidate. Результат: `AI_SCENARIOS`, `human_usability_status=NOT_MEASURED`, human N=0, человеческие timing/success aggregates — null. AI elapsed time включает задержки инструментов и модели и не сравнивается с human target 5–10 s.

Для закрытия нужны подтверждённые page goals/роль, ответы и проверка по evidence, success, elapsed time, clicks/interactions, path, back-navigation/context loss, first/repeat и sample size, median/max. Q3 требует фактически проверенных destination и return. Неизмеренный маршрут не засчитывается. Решение об изменении scope включается hashed receipt с candidate SHA в reviewer bundle.

Provenance, layout, accessibility, data integrity, исходные regression scenarios и Windows full-profile остаются обязательными. Исторические результаты ниже сохраняются; этот scope update сам по себе не означает PASS или закрытие issue.
'''
receipts = []
for number in (10167, 10185, 10171):
    response = session.get(base + str(number), timeout=30)
    response.raise_for_status()
    issue = response.json()
    original = issue['body'] or ''
    if marker in original:
        continue
    body = marker + '\n' + revision + '\n---\n\n' + original
    (out / f'issue-{number}-before-ai-scope.md').write_text(original, encoding='utf-8')
    (out / f'issue-{number}-ai-scope.md').write_text(body, encoding='utf-8')
    if '--publish' in sys.argv:
        response = session.patch(base + str(number), json={'body': body}, timeout=30)
        response.raise_for_status()
        updated = response.json()
        assert updated['state'] == issue['state']
        receipts.append({'number': number, 'url': updated['html_url'], 'updated_at': updated['updated_at'], 'state': updated['state']})
print(json.dumps({'captured_at': datetime.now(timezone.utc).isoformat(), 'published': receipts}, ensure_ascii=False))
