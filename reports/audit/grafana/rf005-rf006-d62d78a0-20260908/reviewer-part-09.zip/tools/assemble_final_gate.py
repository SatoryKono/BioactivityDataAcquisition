"""Assemble reviewed measurements; retain raw failed/historical observations."""
import hashlib,json,re,shutil,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
b=Path(__file__).parent;out=b/'combined-reviewer-bundle';work=Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
sys.path.insert(0,str(work))
from scripts.ops.observability.grafana.regression_acceptance import UIDS,evaluate,write_report
sha='d62d78a0db36118df302f5f63e6ed992e01154dc'
def read(p):return json.loads((out/p).read_text(encoding='utf-8'))
def desc(p):return {'path':p,'sha256':hashlib.sha256((out/p).read_bytes()).hexdigest()}
def dump(p,d):
 q=out/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');return desc(p)
def copy(src,dest):
 for p in src.rglob('*'):
  if not p.is_file():continue
  q=out/dest/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
copy(b/'main-d62-proof',Path('ci'))
copy(b/'reference-fixture/timeline-tooltips-v4',Path('reference/timeline-tooltips-v4'))
copy(b/'reference-fixture/expanded-settled-1000',Path('reference/expanded-settled-1000'))
copy(b/'integrated-07528418e7a/identity-panel-retest',Path('integration/identity-panel-retest'))
shutil.copyfile(b/'final-ci-d62d78a0db.json',out/'final-ci-d62d78a0db.json')
equiv=read('reviews/final-source-equivalence.json');assert all(c['status']=='PASS' for c in equiv['comparisons'])
access=read('stream-a/accessibility-status.json');assert access['status']=='PASS'
assert len(access['profiles'])==15
assert sum(d['accessibility']['color_only_encoding_count'] for p in access['profiles'] for d in p['dashboards'])==0
binding=read('windows/windows-cab-source-binding/source-binding.json')
pyfiles=[p for p in binding['expected_hashes'] if p.endswith('.py')]
assert len(pyfiles)==2469 and all(binding['expected_hashes'][p]==binding['deployed_hashes'][p] for p in pyfiles)
assert len(binding['dashboards'])==7 and all(d['runtime_equal_except_id_version'] for d in binding['dashboards'])
nav=read('reviews/navigation-consumption.json');assert sum(p['records'] for p in nav['profiles'])==84
navigation=[v for p in nav['profiles'] for row in p['navigation'] for k,v in row.items() if k.endswith('_preserved')]
assert len(navigation)==560 and all(navigation)
for width in (900,1366):
 supplement=read(f'integration/supplement-canonical-clock-{width}/observations.json')
 assert len(supplement['records'])==7 and all(r['error_text_observed'] for r in supplement['records'])
extra=read('reference/expanded-settled-1000/observations.json')
assert len(extra['records'])==7 and all(r['status']=='CAPTURED' and r['error_text_observed'] and r['rows']['remaining']==0 for r in extra['records'])
setrange=[]
for width,folder in [(900,'set-range-retest-settled-900'),(1366,'set-range-retest-v4')]:
 row=next(r for r in read(f'integration/{folder}/observations.json')['records'] if r['width']==width)
 assert row['status']=='PASS' and len(row['checks'])==10 and all(row['checks'].values());setrange.append(row)
timeline=[]
for width in (1000,1366):
 row=read(f'reference/timeline-tooltips-v4/{width}.json');assert row['status']=='OBSERVED'
 expected=[('ReferenceResolved · firing','2026-09-08 08:30','10m'),('ReferenceTransition · firing','2026-09-08 08:45','15m'),('ReferenceTransition · pending','2026-09-08 08:30','15m')]
 for cap,tokens in zip(row['captures'],expected,strict=True):assert all(t in cap['text'] for t in tokens)
 timeline.append({'width':width,'states':3,'status':'PASS','reference':'Seeded resolved interval 08:30–08:40, pending 08:30–08:45, firing 08:45–09:00 UTC. Tooltip start + duration, full row label, bar boundary and fixed time picker jointly expose bounds. Native final axis tick clips at chart edge; full end is available in picker and start+duration.','evidence':desc(f'reference/timeline-tooltips-v4/{width}.json')})
identity=read('integration/identity-panel-retest/observations.json');assert len(identity['records'])==2 and all(r['status']=='OBSERVED' for r in identity['records'])
for row in identity['records']:
 for uuid in ['b9d2eeff-8e4b-5678-ae32-b288ced27968','53230537-8841-5e0b-a972-f361077fc200']:
  cells=[c for c in row['cells'] if c['text']==uuid];assert cells and cells[0]['width']>300
matrix=read('reference/matrix-adjudication.json');assert matrix['summary']=={'PASS':161,'PASS_STATE_ONLY':56,'PASS_EXPECTED_QUERY_ERROR':8}
positive=read('reference/conformance-results.json');assert positive['summary']=={'PASS':50}
states=read('reference/state-conformance-results.json');assert states['status']=='PASS' and len(states['zero_stat_cases'])==10 and states['table_cell_field_count']==55
lineage=read('reference/critical-panel-lineage.json');assert lineage['status']=='PASS' and lineage['complete_configuration_traces']==25
win=read('windows/windows-cab-full-profile/receipt.json');assert win['all_statuses_passed'] and win['targets_up']==5
ci=read('final-ci-d62d78a0db.json');assert ci['candidate_ref']==sha
assert not [c for c in ci['checks'] if c['conclusion'] in ('failure','cancelled','timed_out')]
assert all(c['status']=='completed' or c['name']=='docker-push' for c in ci['checks'])
proof=read('ci/archived-verification.json');assert proof['outcome']=='ADMIT' and not proof['errors'] and not proof['degradations']
dump('reviews/focused-retests.json',{'reviewer':'Astra (AI agent)','candidate_ref':sha,'timeline':timeline,'set_range':setrange,'identity_panel':desc('integration/identity-panel-retest/observations.json'),'original_1000_width':desc('reference/expanded-settled-1000/observations.json'),'inspection':'Timeline PNGs at 1000 and 1366 reviewed directly. Live source and browser model parity are separately bound; fixtures are controlled samples, not production completeness.'})
dump('reviews/attempt-dispositions.json',{'reviewer':'Astra (AI agent)','candidate_ref':sha,'open_product_regressions':[],'resolved_attempts':[
 {'category':'cold Windows startup','status':'RESOLVED_BY_RETEST','details':'Initial 3-second health requests timed out after image rebuild; original failure retained. Stabilized response ~0.005s, canonical start and full-profile passed unchanged limits.'},
 {'category':'Set range harness','status':'INVALID_ATTEMPTS_RETAINED','details':'Initial network-idle/loading and attempted navigation from viewPanel were not eligible. Final 900/1366 attempts wait for settled Overview IN RANGE and pass all 20 assertions.'},
 {'category':'timeline harness','status':'INVALID_ATTEMPTS_RETAINED','details':'v1/v2 searched lazy rows before scrolling; v3 searched lazy panel before scrolling. v4 captures all six expected tooltips after actual scroll and checks independent seed values.'},
 {'category':'numeric reconciliation harness','status':'ADJUDICATED','details':'Original 15 failure/77 not-verifiable exploration and later full-matrix statuses retained. Final known-input reconciliation validates 50 positive cases and all 225 variable cases; 56 state-only and 8 intentional HTTP400 are not numeric passes.'},
 {'category':'incomplete expanded captures','status':'INELIGIBLE_FOR_VALUES','details':'Earlier preclock/loading/timeout captures retained. Canonical live matrices, settled known-input 900/1000, controlled operator and primary Stream A source-bound profiles provide final evidence.'},
 {'category':'broad package source scan','status':'ADJUDICATED','details':'Raw false from seven README and one .gitkeep omissions retained. All 2469 Python modules and seven dashboards match; no code mismatch waived.'},
 {'category':'CI provenance','status':'FIXED_AND_MERGED','details':'PR10238 regenerates telemetry from exact successful main producer; final d62 Tests and architecture pass, Proof ADMIT. Thresholds and budgets unchanged.'}],
 'limitations':['Human usability NOT_MEASURED; AI-only scope explicitly approved.','Live telemetry completeness remains NOT_VERIFIABLE where absent. Reference data proves query/transform/render conformance only.','Replay was not executed.','Protected Docker publication remains approval-waiting and outside this acceptance.']})
common={'candidate_ref':sha,'occurrence_id':'stream-b-final-d62d78a0-20260908','time_range':{'from':1788825600000,'to':1788858000000,'timezone':'UTC'},'variable_matrix':[{'profile':'Stream A layout','window':'2026-09-08T00:00:00Z/2026-09-08T06:00:00Z','run_id':'-','themes':['dark','light'],'zoom':[100,200]},{'profile':'Stream B live integration','windows':['08:30–09:00 UTC','05:10–05:15 UTC','run bounds + margin'],'modes':['All','single','multi','missing-run','query-error'],'source_ref':'07528418e7abfa5535ed50aee009b73f9fb87899'},{'profile':'Known-input reference','windows':['15m','6h'],'cases':225,'scope':'isolated fixture plus separate live UNKNOWN'}],'viewports':[[1366,768],[900,768],[1000,768],[1440,900],[1920,1080]],'dashboard_uids':sorted(UIDS)}
dump('reviews/profile-scope.json',{'candidate_ref':sha,'scope':common,'meaning':'Top-level time_range is the campaign evidence window, not a claim that every capture used one range. Each immutable raw capture retains its own actual source, range, variable values, viewport, theme and runtime. Final wrapper consumes equivalent source receipts; it does not retag capture metadata.','runtime_config_difference':'Stream A uses its recorded kiosk/date profile; Stream B canonical clock/normal chrome is separately captured. Both actual configurations remain explicit.'})
baseline={'baseline_ref':'e2a83a96f8aa9baf944c34ca735e59d3541f5c4c','approved_by':'Task owner: explicit original Stream B acceptance request and subsequent AI/reference scope decisions; predicate inventory assembled by Astra without changing original criteria.','findings':[],'required_measurements':{}}
artifacts={}
def gate(name,rows):
 measurements=[]
 def object_ref(p):
  value=read(p)
  if isinstance(value,dict):return desc(p)
  return dump('reviews/array-references/'+hashlib.sha256(p.encode()).hexdigest()[:16]+'.json',{'original':desc(p),'rows':value,'note':'Object envelope for canonical verifier; original array bytes remain unchanged.'})
 for ident,actual,expected,source,reference,description in rows:
  measurements.append({'id':ident,'actual':actual,'expected':expected,'comparison':'eq','tolerance':0,'evidence':object_ref(source),'reference':object_ref(reference),'description':description})
 baseline['required_measurements'][name]={'checks':[{k:r[k] for k in ('id','expected','comparison','tolerance')} for r in measurements]}
 artifacts[name]=dump('gates/'+name+'.json',{**common,'measurements':measurements})
gate('provenance',[('equivalent_source_scopes',4,4,'reviews/final-source-equivalence.json','reviews/profile-scope.json','Four immutable source scopes compare equal on applicable runtime surfaces.'),('python_package_hashes',2469,2469,'windows/windows-cab-source-binding/source-binding.json','reviews/windows-source-adjudication.json','All executable Python modules match; packaging-only omissions explicitly reviewed.'),('source_bound_layout_profiles',15,15,'stream-a/accessibility-status.json','stream-a/archive-roundtrip-verification.json','Source-bound original archives verified.')])
gate('layout',[('layout_profiles',sum(p['layout_status']=='PASS' for p in access['profiles']),15,'stream-a/accessibility-status.json','stream-a/matrix-manifest.json','Original first-window, expanded, zoom and theme acceptance.'),('narrow_matrix_observations',84,84,'reviews/navigation-consumption.json','reviews/profile-scope.json','Actual 900/1366 browser matrices.'),('original_1000_profiles',7,7,'reference/expanded-settled-1000/observations.json','reviews/profile-scope.json','All original 1000-width rows expanded and captured.')])
gate('lineage',[('critical_data_panels',25,25,'reference/critical-panel-lineage.json','reference/dashboards.json','Each data panel traced through source/query/transform/display; nav-only panel explicitly NA.')])
gate('integrity',[('positive_numeric_cases',50,50,'reference/conformance-results.json','reference/input-manifest.json','Known-input 15m/6h independent reconciliation, unchanged tolerance 1e-9.'),('variable_case_dispositions',225,225,'reference/matrix-adjudication.json','reference/captures.json','161 numeric/table cases, 56 missing/selection states, 8 expected query errors; all explicitly classified.'),('known_zero_stats',10,10,'reference/state-conformance-results.json','reference/zero-input-manifest.json','Real zero samples remain zero.'),('null_nan_field_states',55,55,'reference/state-conformance-results.json','reference/zero-transformed.json','Actual field display processors keep null/NaN distinct from healthy zero.')])
totals=read('reviews/accessibility-consumption.json')['totals']
for gate_name,kind in [('text_contrast','text'),('graphics_contrast','graphics')]:gate(gate_name,[(kind+'_required_samples',totals[kind]['passed'],totals[kind]['required'],'stream-a/accessibility-status.json','stream-a/contrast-measurements.json','Required observed samples; disabled graphic exemptions remain separately counted.')])
gate('color_only',[('unresolved_color_only',0,0,'stream-a/accessibility-status.json','stream-a/cue-review.json','Zero unresolved color-only meanings across 105 dashboard profile observations; not an empty inventory percentage.')])
gate('semantic_parity',[('traced_critical_panel_semantics',25,25,'reference/critical-panel-lineage.json','reference/conformance-results.json','Display transformations and source values reconciled per critical panel.'),('timeline_tooltips',6,6,'reviews/focused-retests.json','reference/input-manifest.json','Full names, states, starts and durations agree with seed.')])
gate('regression_search',[('navigation_context_assertions',560,560,'reviews/navigation-consumption.json','reviews/profile-scope.json','Seven dashboard transitions, five modes and two widths.'),('set_range_assertions',20,20,'reviews/focused-retests.json','reference/identity-artifact-reference.json','Set range from persisted run bounds and return IN RANGE.'),('query_error_popovers',14,14,'reviews/attempt-dispositions.json','integration/supplement-canonical-clock-900/observations.json','Actual 503 error popovers on all seven dashboards at both original widths.'),('final_ci_proof',1,1,'ci/archived-verification.json','final-ci-d62d78a0db.json','Exact final main Tests/architecture and mandatory checks passed; protected publication waiting excluded explicitly.')])
gate('windows_full_profile',[('canonical_status_checks',2,2,'windows/windows-cab-full-profile/receipt.json','reviews/windows-source-adjudication.json','Canonical main and monitoring status exit0 on native Windows.'),('prometheus_targets_up',win['targets_up'],5,'windows/windows-cab-full-profile/receipt.json','windows/windows-cab-full-profile/receipt.json','Every configured target UP; no threshold changes.')])
operator=read('operator/operator-receipt.json')
for row in operator['observations']:
 for key in ('evidence','answer_key_evidence'):row[key]['path']='operator/'+row[key]['path']
artifacts['operator']=dump('gates/operator.json',{**operator,**common,'consumed_original_receipt':desc('operator/operator-receipt.json'),'binding_note':'Original per-attempt capture source remains 075; final consumption uses proven runtime source equivalence.'})
scope=dump('reviews/operator-scope-decision.json',{'candidate_ref':sha,'acceptance_mode':'AI_SCENARIOS','human_usability_status':'NOT_MEASURED','task_count':21,'approved_by':'task owner (explicit conversation reply)','approved_at':'2026-09-08','reason':'User: Принять только AI-проверку сценариев. Astra explicitly identified as AI agent; seven diagnostic goals approved, no replay execution.'})
cases=read('baseline/retest-cases.json')['cases']
observations={
10172:('All/single/multi run-type navigation preserves selected scope and absolute UTC range; 560 destination/return assertions pass.','reviews/navigation-consumption.json'),
10173:('Actual Set range to run computes persisted bounds with margin, preserves All/multi scope, returns to Overview IN RANGE; 20 assertions pass. Unselected scope has no actionable Set range.','reviews/focused-retests.json'),
10174:('Trust compact verdict and retention evidence preserve INCOMPLETE/UNKNOWN, with 7 identity comparisons available in expanded evidence. First-window and all expanded profiles pass.','operator/operator-receipt.json'),
10175:('Identity value content remains available in full text/Inspect; expanded tables and global read-latency legends retain full store/operation/quantile labels. Known latency samples are visibly rendered.','reference/expanded-settled-1000/observations.json'),
10176:('Overview first action, domain panels and diagnostics are visible in accepted first-window/expanded profiles; AI identifies UNKNOWN fleet status and DQ first action.','operator/operator-receipt.json'),
10177:('Runtime first action and cross-dashboard navigation fit accepted first-window profiles; actual navigation preserves context.','stream-a/accessibility-status.json'),
10178:('Selected run status/dates/coverage/workflow fields agree with persisted report and catalog; timestamps retain sufficient precision, no substitute OK values.','reference/identity-artifact-reference.json'),
10179:('Provider severity/reason panels preserve missing-data UNKNOWN. Full lists remain inspectable; p95 seeded 0.875s renders as 875.000ms, not hidden near the axis.','reference/expanded-settled-1000/observations.json'),
10180:('DQ rows align in source-bound captures; unavailable reasons explicitly UNKNOWN, successful zero reasons OK, query failure separately visible. Range aggregates match known input.','reference/state-conformance-results.json'),
10181:('Incident ranked suspects have unique rank fields, explicit GLOBAL CURRENT scope and UNVERIFIED confidence/UNKNOWN impact. Known input proves rank1/2/3; actual row Inspect selects its domain/object.','reference/conformance-results.json'),
10182:('Stage funnel selected-run counts reconcile with report: extract/bronze/silver1000, gold983 valid and17 excluded; configured percent semantics preserved.','operator/operator-receipt.json'),
10183:('983/1000 and17/1000 display98.3%/1.7%, retaining meaningful precision; no invented additional significant outcomes.','operator/operator-receipt.json'),
10187:('Without run selection identity remains SELECT RUN, not authoritative OK; selected real anchors are compared independently and missing anchors remain UNKNOWN.','reference/matrix-adjudication.json'),
10188:('Actual Incident row Inspect navigates to Provider with explicit GLOBAL object scope, then returns to original selected-run context; AI Q3 measured.','operator/operator-receipt.json'),
10189:('Actual JSON and Markdown artifact links open through the Ops HTTP proxy, contain expected run UUID, and return without context loss; raw report identity reviewed independently.','operator/artifact-identity-review.json'),
10190:('Identity individual panel view at1000/1366 gives value the remaining width; complete Run/Manifest UUIDs are readable. Status/dates match catalog. No selection=>SELECT RUN; zero/absent/error states remain distinct.','integration/identity-panel-retest/observations.json'),
10191:('Recent Runs index membership and newest10 ordering independently reconciled across pipeline/All/multi scopes against persisted report files; workflow display retained.','reference/matrix-adjudication.json'),
10192:('Counts1000/983/17 use neutral count semantics; percent98.3/1.7 and excluded labels carry explained quality meaning. Table semantics and actual processed records reviewed.','operator/operator-receipt.json'),
10193:('At1000/1366 full alert names and FIRING/PENDING are readable; tooltip starts/durations match independent seeded intervals. Axis-edge clipped tick does not remove accessible range endpoint.','reviews/focused-retests.json'),
10194:('Expanded instructions and target links remain available at1000/1366; first screen distinguishes endpoint SCRAPING from telemetry completeness UNVERIFIED and pipeline state.','reference/expanded-settled-1000/observations.json')}
retests=[]
for case in cases:
 ident=case['id'];issue=case['child_issue'];observation,evidence=observations[issue]
 severity=re.search(r'\bP[0-3]\b',' '.join(case['parent_finding_rows'])+' '+case['title']).group()
 acceptance='\n'.join(case['issue_checklist'])
 assert acceptance
 row={'id':ident,'severity':severity,'acceptance_test':acceptance,'expected':1,'comparison':'eq','tolerance':0}
 baseline['findings'].append(row.copy())
 review=dump(f'reviews/findings/{ident}.json',{'id':ident,'candidate_ref':sha,'reviewer':'Astra (AI agent)','original_issue':issue,'original_criteria':acceptance,'observation':observation,'status':'FIXED','method':'Reviewed original criterion against actual source-bound browser/independent-reference evidence; numeric1 means this finite criterion passed, not a fabricated duration or human measurement.','primary_evidence':desc(evidence),'shared_layout_evidence':desc('stream-a/accessibility-status.json'),'wide_narrow_error_evidence':[desc(f'integration/supplement-canonical-clock-{w}/observations.json') for w in (900,1366)],'source_equivalence':desc('reviews/final-source-equivalence.json')})
 retests.append({**row,'actual':1,'disposition':'FIXED','before':desc('baseline/'+case['original_issue']['path']),'after':review,'evidence':review,'reference':desc(evidence)})
artifacts['findings']=dump('gates/findings.json',{**common,'findings':retests})
artifacts['new_regressions']=dump('gates/new_regressions.json',{**common,'reviewer':'Astra (AI agent)','search_evidence':desc('reviews/attempt-dispositions.json'),'findings':[]})
contract={**common,'baseline_ref':baseline['baseline_ref'],'baseline':dump('baseline/approved-baseline.json',baseline),'operator_acceptance_mode':'AI_SCENARIOS','operator_scope_decision':scope,'artifacts':artifacts}
dump('contract.json',contract)
result=evaluate(out/'contract.json');print(json.dumps(result,ensure_ascii=False)[:4000])
dump('reviews/pre-seal-evaluation.json',result)
if '--seal' in sys.argv:
 head=subprocess.check_output(['git','-c','safe.directory='+work.as_posix(),'-C',str(work),'rev-parse','HEAD'],text=True).strip()
 clean=not subprocess.check_output(['git','-c','safe.directory='+work.as_posix(),'-C',str(work),'status','--porcelain','--untracked-files=no'],text=True).strip()
 assert result['release_passed']
 assert write_report(out/'contract.json',out/'release-gate.json',expected_candidate=head,working_tree_clean=clean)
