"""Freeze committed Stream A dashboards for isolated Stream B retesting."""
import hashlib
import json
import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
a=Path('E:/github/BioactivityDataAcquisition-stream-a')
base=Path(__file__).parent
out=base/'integrated-07528418e7a'
candidate='07528418e7abfa5535ed50aee009b73f9fb87899'
out.mkdir(exist_ok=True)
def run(args):return subprocess.check_output(args,text=True,encoding='utf-8',timeout=60).strip()
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+a.as_posix(),'-C',str(a),*args],timeout=60)
assert not git('diff','1895351a8a95f2ca451115be6639b10afba16e03',candidate,'--','src/bioetl','docker-compose.yml','scripts/ops/runtime/docker','.env.example').strip()
names=git('ls-tree','--name-only',candidate,'grafana/dashboards/').decode().splitlines()
models={}
for name in names:
    if not name.endswith('.json'):continue
    raw=git('show',candidate+':'+name)
    path=out/'dashboards'/Path(name).name;path.parent.mkdir(exist_ok=True)
    if path.exists():assert path.read_bytes()==raw
    else:path.write_bytes(raw)
    models[Path(name).stem]={'source_path':name,'sha256':hashlib.sha256(raw).hexdigest()}
assert len(models)==7
provisioning=base/'browser-runtime/provisioning'
b=json.loads(run(['docker','inspect','bioetl-stream-b-grafana']))[0]
plugins=next(m['Source'] for m in b['Mounts'] if m['Destination']=='/var/lib/grafana/plugins')
v=dotenv_values(root/'.env')
os.environ['GF_SECURITY_ADMIN_USER']=v.get('GRAFANA_USERNAME') or v.get('GF_SECURITY_ADMIN_USER') or 'admin'
os.environ['GF_SECURITY_ADMIN_PASSWORD']=v.get('GRAFANA_PASSWORD') or v.get('GF_SECURITY_ADMIN_PASSWORD')
assert os.environ['GF_SECURITY_ADMIN_PASSWORD']
args=['docker','run','-d','--name','bioetl-stream-b-integrated-grafana','--network','bioetl-monitoring','--publish','127.0.0.1:3004:3000','--memory','512m','--cpus','1','--label','io.bioetl.acceptance=stream-b-integrated','--label','org.opencontainers.image.revision='+candidate,'--env','GF_AUTH_ANONYMOUS_ENABLED=true','--env','GF_AUTH_ANONYMOUS_ORG_ROLE=Viewer','--env','GF_SECURITY_ADMIN_USER','--env','GF_SECURITY_ADMIN_PASSWORD']
for source,target in [(out/'dashboards','/var/lib/grafana/dashboards'),(provisioning,'/etc/grafana/provisioning'),(Path(plugins),'/var/lib/grafana/plugins')]:args+=['--mount',f'type=bind,source={source},target={target},readonly']
args.append(b['Image'])
container=run(args)
receipt={'candidate_ref':candidate,'source_files':models,'container_id':container,'image_id':b['Image'],'url':'http://127.0.0.1:3004','backend_url':'http://127.0.0.1:8002','backend_source_diff_from_1895351a8a':'empty','purpose':'Original narrow/variable/error scenario retests on a committed integration candidate; Stream A services and working tree remain untouched.'}
(out/'runtime.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
