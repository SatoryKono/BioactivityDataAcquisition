import hashlib,json,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
b=Path(__file__).parent;r=Path('E:/github/BioactivityDataAcquisition');out=b/'combined-reviewer-bundle'
def dump(p,d):
 p=out/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+r.as_posix(),*args],cwd=r,text=True).strip()
sha=git('rev-parse','origin/main')
surfaces=['src/bioetl','grafana/dashboards','Dockerfile.bioetl','docker-compose.yml','docker-compose.monitoring.yml','scripts/ops/runtime/docker','pyproject.toml','uv.lock']
refs={'integration':'07528418e7abfa5535ed50aee009b73f9fb87899','windows':'cab240755d10137642f9086ea5b2e6f88b4a56d9','image_build':'d30a77dc5d9a81d37f7525728fe46f2a4799074d','stream_a':'68ec26b17b6bec5d88704b547ee195251985c286'}
comparisons=[]
for scope,ref in refs.items():
 paths=['grafana/dashboards'] if scope=='stream_a' else surfaces
 if scope=='image_build':paths=[p for p in paths if p!='grafana/dashboards']
 changes=git('diff','--name-only',ref,sha,'--',*paths).splitlines()
 trees={p:{'capture':git('rev-parse',ref+':'+p),'candidate':git('rev-parse',sha+':'+p)} for p in paths}
 comparisons.append({'scope':scope,'original_ref':ref,'candidate_ref':sha,'paths':paths,'changed_files':changes,'git_object_ids':trees,'status':'PASS' if not changes else 'REVIEW_REQUIRED'})
dump('reviews/final-source-equivalence.json',{'candidate_ref':sha,'at':datetime.now(timezone.utc).isoformat(),'method':'Compare immutable Git blobs/trees, not working-tree EOL bytes or ancestry. Original captures and their source SHA remain unchanged. History rewrite means old captures are not claimed as current-main ancestors.','comparisons':comparisons})
allowed={'.json','.png','.txt','.md','.py','.cjs','.ts','.gz','.log','.zip','.xml','.yml','.bundle'}
def copy(src,dest):
 for p in src.rglob('*'):
  rel=p.relative_to(src)
  if not p.is_file() or p.suffix not in allowed or any(s in ('data','grafana-data','plugins','node_modules') for s in rel.parts):continue
  q=out/dest/rel
  if q.exists() and q.stat().st_size==p.stat().st_size and hashlib.sha256(q.read_bytes()).digest()==hashlib.sha256(p.read_bytes()).digest():continue
  q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for name in ['windows-cab-main-start','windows-cab-main-retest','windows-cab-monitoring-start','windows-cab-full-profile','windows-cab-source-binding']:
 copy(b/name,Path('windows')/name)
copy(b/'reference-fixture',Path('reference'))
copy(b/'integrated-07528418e7a',Path('integration'))
for p in b.glob('*.py'):shutil.copyfile(p,out/'tools'/p.name)
for p in b.glob('*.cjs'):shutil.copyfile(p,out/'tools'/p.name)
for p in b.glob('final-ci-*.json'):shutil.copyfile(p,out/p.name)
for name in ['pr10238-status.json','telemetry-fix-pr.json','cab-architecture-d.log','health-latency-145800.json']:
 p=b/name
 if p.exists():shutil.copyfile(p,out/p.name)
binding=json.loads((b/'windows-cab-source-binding/source-binding.json').read_text())
omitted=['README.md','application/README.md','application/core/.gitkeep','application/services/README.md','composition/README.md','domain/README.md','infrastructure/README.md','interfaces/README.md']
assert binding['source_mismatches']==omitted
assert sum(k.endswith('.py') for k in binding['expected_hashes'])==2469
dump('reviews/windows-source-adjudication.json',{'candidate_ref':sha,'capture_ref':binding['candidate_ref'],'runtime_source_status':'PASS','python_files_checked':2469,'omitted_non_runtime_files':omitted,'reason':'Seven Markdown README files are excluded by existing Docker packaging; empty .gitkeep is not executable content. Raw broad scan remains passed=false; all executable Python hashes match. runtime_build_ref identifies observed build context, not an OCI label claim. Final equivalence is recorded separately.','cold_start_disposition':'Initial health-live/ready requests exceeded unchanged 3-second limits during cold startup. Raw failed start retained; stabilized endpoints measured ~0.005s and canonical bounded start/status retests passed unchanged limits.','raw_evidence':'windows/windows-cab-source-binding/source-binding.json'})
print(json.dumps({'candidate_ref':sha,'comparisons':[{k:v for k,v in c.items() if k in ('scope','status','changed_files')} for c in comparisons]}))
