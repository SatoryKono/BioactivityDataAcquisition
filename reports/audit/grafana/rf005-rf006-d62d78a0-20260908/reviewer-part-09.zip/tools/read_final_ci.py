import json
from datetime import datetime,timezone
from pathlib import Path
import requests
from dotenv import dotenv_values
base=Path(__file__).parent;root=Path('E:/github/BioactivityDataAcquisition')
s=requests.Session();s.headers.update(Authorization='Bearer '+dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'])
api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(p):
 r=s.get(api+p,timeout=30);r.raise_for_status();return r.json()
sha=json.loads((base/'final-candidate-equivalence-preflight.json').read_text())['candidate_ref']
checks=get('/commits/'+sha+'/check-runs?per_page=100')['check_runs'];runs=get('/actions/runs?head_sha='+sha+'&per_page=100')['workflow_runs'];pr=get('/pulls/10231')
out={'captured_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':sha,'pr':pr,'checks':checks,'runs':runs}
p=base/('final-ci-'+sha[:10]+'.json');p.write_text(json.dumps(out,indent=2))
print(json.dumps({'sha':sha,'pr_merged':pr['merged'],'merge_sha':pr['merge_commit_sha'],'checks':[{'name':c['name'],'status':c['status'],'conclusion':c['conclusion']} for c in checks],'runs':[{'id':r['id'],'name':r['name'],'status':r['status'],'conclusion':r['conclusion']} for r in runs]}))
