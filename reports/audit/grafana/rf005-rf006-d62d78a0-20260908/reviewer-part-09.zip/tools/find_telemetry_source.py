import json
from pathlib import Path
import requests
from dotenv import dotenv_values
session=requests.Session()
session.headers['Authorization']='Bearer '+dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
base='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(path):
    r=session.get(base+path,timeout=30)
    r.raise_for_status()
    return r.json()
for sha in ('7a85e1a8cdf8c222a3bd873f8311f56f4f2b350e','e2a83a96f8aa9baf944c34ca735e59d3541f5c4c'):
    runs=get('/actions/runs?head_sha='+sha+'&per_page=50')['workflow_runs']
    print(json.dumps({'sha':sha,'runs':[{'id':r['id'],'name':r['name'],'status':r['status'],'conclusion':r['conclusion']} for r in runs]}),flush=True)
    for run in runs:
        if run['name'] in ('CI','Tests','PR Gate Complete'):
            jobs=get(f"/actions/runs/{run['id']}/jobs?per_page=100")['jobs']
            producers=[j for j in jobs if 'coverage-verify' in j['name'] or 'duration-telemetry' in j['name']]
            Path(__file__).with_name(f"telemetry-source-{run['id']}.json").write_text(json.dumps({'run':run,'producers':producers},indent=2),encoding='utf-8')
            print(json.dumps({'run':run['id'],'producers':[{'id':j['id'],'name':j['name'],'conclusion':j['conclusion']} for j in producers]}),flush=True)
