import hashlib
import json
import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values

root = Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
out = root / 'reports/audit/ai-scope-telemetry-34212268521'
out.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
repo = 'SatoryKono/BioactivityDataAcquisition'
run_id = '34212268521'
def gh(args):
    p = subprocess.run(['gh', *args], env=env, cwd=root, capture_output=True, text=True, encoding='utf-8', timeout=180)
    if p.returncode:
        raise RuntimeError(p.stderr)
    return p.stdout

run = json.loads(gh(['run', 'view', run_id, '--repo', repo, '--json', 'headSha,headBranch,event,url,jobs']))
assert run['headSha'] == '7a85e1a8cdf8c222a3bd873f8311f56f4f2b350e'
producers = [j for j in run['jobs'] if j['name'] in ('coverage-verify', 'duration-telemetry')]
assert len(producers) == 2 and all(j['conclusion'] == 'success' for j in producers)
artifacts = json.loads(gh(['api', f'repos/{repo}/actions/runs/{run_id}/artifacts?per_page=100']))['artifacts']
selected = [a for a in artifacts if a['name'] in ('coverage-report', 'test-duration-telemetry')]
assert len(selected) == 2 and all(not a['expired'] for a in selected)
for artifact in selected:
    print(json.dumps({k: artifact[k] for k in ('id', 'name', 'size_in_bytes')}), flush=True)
    gh(['run', 'download', run_id, '--repo', repo, '--name', artifact['name'], '--dir', str(out / artifact['name'])])
files = [{'path': str(p.relative_to(out)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()]
(out / 'source-receipt.json').write_text(json.dumps({'run': {k: v for k, v in run.items() if k != 'jobs'}, 'successful_producers': producers, 'artifacts': selected, 'files': files}, indent=2), encoding='utf-8')
print(json.dumps({'files': [f['path'] for f in files]}), flush=True)
