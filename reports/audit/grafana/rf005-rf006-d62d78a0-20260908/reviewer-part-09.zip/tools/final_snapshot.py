import hashlib
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

root = Path('E:/github/BioactivityDataAcquisition')
out = Path(__file__).parent
session = requests.Session()
session.headers.update({'Authorization': 'Bearer '+dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'], 'Cache-Control': 'no-cache'})
base = 'https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(path):
    r=session.get(base+path, timeout=30)
    r.raise_for_status()
    return r.json()
issues = [get(f'/issues/{n}') for n in (10167,10185,10171,10186,10165,10170)]
main = get('/commits/main')['sha']
prs = get('/pulls?state=open&head=SatoryKono:codex/stream-a-provenance-layout-accessibility')
containers = subprocess.run(['docker', 'ps', '--format', '{{.Names}} {{.Status}}'], capture_output=True, text=True, check=True, timeout=30).stdout
receipt = {'captured_at': datetime.now(timezone.utc).isoformat(), 'main_sha': main,
           'issues': [{'number': i['number'], 'state': i['state'], 'url': i['html_url']} for i in issues],
           'stream_a_prs': [{'number': p['number'], 'sha': p['head']['sha']} for p in prs], 'containers': containers}
(out/'final-dependency-snapshot.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
filenames = ['closeout-progress.md','plan.md','candidate.json','backlog-retest-register.json','backlog-history.json','isolated-backend.json','backend-regression-proof.json','isolated-report-bind.log','windows-before/docker-runtime-main-preflight.json','docker-contract-tests.log','dashboard-contract-tests.log','final-dependency-snapshot.json','memory-post-task.json']
filenames += [p.name for p in out.glob('backend-*.json') if p.name not in filenames]
manifest = {'scope':'Supplementary continuation evidence, not final release acceptance','files':[{'path':n,'sha256':hashlib.sha256((out/n).read_bytes()).hexdigest()} for n in sorted(filenames)]}
(out/'supplementary-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
archive = out/'stream-b-supplementary-e2a83a96.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for n in sorted(filenames+['supplementary-manifest.json']):
        z.write(out/n,n)
print(json.dumps({'snapshot':receipt,'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
