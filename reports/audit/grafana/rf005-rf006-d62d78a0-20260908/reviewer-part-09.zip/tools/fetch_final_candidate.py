import base64,json,os,subprocess
from pathlib import Path
from dotenv import dotenv_values
root=Path('E:/github/BioactivityDataAcquisition')
env=os.environ.copy();token=dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
env.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=root.as_posix(),GIT_CONFIG_KEY_1='http.https://github.com/.extraheader',GIT_CONFIG_VALUE_1='AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+token).encode()).decode())
p=subprocess.run(['git','fetch','origin','main'],cwd=root,env=env,capture_output=True,text=True,timeout=120);assert p.returncode==0,p.stderr
sha=subprocess.check_output(['git','rev-parse','origin/main'],cwd=root,env=env,text=True).strip()
changes=subprocess.check_output(['git','diff','07528418e7abfa5535ed50aee009b73f9fb87899',sha,'--name-only','--','src/bioetl','grafana/dashboards','docker-compose.yml','scripts/ops/runtime/docker','Dockerfile.bioetl'],cwd=root,env=env,text=True).splitlines()
out={'candidate_ref':sha,'capture_ref':'07528418e7abfa5535ed50aee009b73f9fb87899','runtime_surface_changes':changes}
(Path(__file__).parent/'final-candidate-equivalence-preflight.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
