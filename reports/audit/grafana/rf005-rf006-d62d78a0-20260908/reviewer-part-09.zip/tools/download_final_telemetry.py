import hashlib,io,json,zipfile
from pathlib import Path
import requests
from dotenv import dotenv_values
b=Path(__file__).parent/'main-cab-telemetry';b.mkdir(exist_ok=True)
s=requests.Session();s.headers['Authorization']='Bearer '+dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
runid=34238177700
def get(p):
 r=s.get(api+p,timeout=40);r.raise_for_status();return r
run=get('/actions/runs/'+str(runid)).json();artifacts=get('/actions/runs/'+str(runid)+'/artifacts?per_page=100').json()['artifacts']
(b/'producer.json').write_text(json.dumps({'run':run,'artifacts':artifacts},indent=2))
print(json.dumps({'run_status':run['status'],'conclusion':run['conclusion'],'artifacts':[{'name':a['name'],'id':a['id']} for a in artifacts]}),flush=True)
for a in artifacts:
 if a['name'] not in ('test-duration-telemetry','proof-or-stop-34238177700-1'):continue
 data=get('/actions/artifacts/'+str(a['id'])+'/zip').content
 p=b/(a['name']+'.zip');p.write_bytes(data)
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  for n in z.namelist():
   if n.endswith('/') or Path(n).is_absolute() or '..' in Path(n).parts:continue
   q=b/a['name']/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(n))
 print(json.dumps({'downloaded':a['name'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}),flush=True)
