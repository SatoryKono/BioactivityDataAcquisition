import base64,json,os,subprocess
from pathlib import Path
import requests
from dotenv import dotenv_values
base=Path(__file__).parent;root=Path('E:/github/BioactivityDataAcquisition');repo=root/'.worktrees/operator-acceptance-closeout-20260908';branch='codex/operator-final-main-cab240'
token=dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'];env=os.environ.copy()
env.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix(),GIT_CONFIG_KEY_1='http.https://github.com/.extraheader',GIT_CONFIG_VALUE_1='AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+token).encode()).decode())
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo,env=env,text=True).strip()
p=subprocess.run(['git','push','-u','origin',branch],cwd=repo,env=env,capture_output=True,text=True,timeout=120);assert p.returncode==0,p.stderr
s=requests.Session();s.headers['Authorization']='Bearer '+token;api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
body='После squash PR #10231 поле source_commit в test-telemetry baseline осталось привязано к недостижимому PR-коммиту 9881f030, из-за чего на main упал test_committed_test_telemetry_branch_accurate_source_identity.\n\nПять generated artifacts обновлены каноническим update_test_telemetry_baseline из coverage-report и test-duration-telemetry успешного main Tests run [34238177700](https://github.com/SatoryKono/BioactivityDataAcquisition/actions/runs/34238177700), source cab240755d10137642f9086ea5b2e6f88b4a56d9. Source tree hash сохранён. Coverage 96,71%, порог 85%, freshness 45 дней — без изменений ограничений.\n\nПроверка: 26 тестов telemetry governance, baseline и генератора прошли; git diff --check пройден. Runtime source и mirrors не изменены. Связано с финальной приёмкой #10185 / #10171; этот PR сам по себе не закрывает их.'
r=s.get(api+'/pulls',params={'state':'open','head':'SatoryKono:'+branch},timeout=30);r.raise_for_status();existing=r.json()
if existing:pr=existing[0]
else:
 r=s.post(api+'/pulls',json={'title':'fix(ci): refresh telemetry provenance after Stream A squash','head':branch,'base':'main','body':body},timeout=30);r.raise_for_status();pr=r.json()
(base/'telemetry-fix-pr.json').write_text(json.dumps(pr,indent=2));print(json.dumps({'number':pr['number'],'url':pr['html_url'],'head':pr['head']['sha']}))
