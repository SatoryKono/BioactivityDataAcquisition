import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from dotenv import dotenv_values

env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
repo = 'SatoryKono/BioactivityDataAcquisition'
def gh(*args):
    p = subprocess.run(['gh', *args], env=env, capture_output=True, text=True, encoding='utf-8', timeout=60, check=True)
    return json.loads(p.stdout)
sha = gh('api', f'repos/{repo}/commits/main')['sha']
runs = gh('run', 'list', '--repo', repo, '--commit', sha, '--limit', '100', '--json', 'databaseId,name,status,conclusion,url')
failures = []
for run in runs:
    if run['conclusion'] == 'failure':
        jobs = gh('run', 'view', str(run['databaseId']), '--repo', repo, '--json', 'jobs')['jobs']
        failures.extend({'run_id': run['databaseId'], 'job': j} for j in jobs if j['conclusion'] == 'failure')
result = {'captured_at': datetime.now(timezone.utc).isoformat(), 'sha': sha, 'runs': runs, 'failures': failures}
out = Path(__file__).parent / ('main-readiness-' + datetime.now(timezone.utc).strftime('%H%M%S') + '.json')
out.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
