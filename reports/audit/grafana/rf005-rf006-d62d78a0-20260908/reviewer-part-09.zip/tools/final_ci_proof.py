import hashlib,io,json,zipfile
from pathlib import Path
from datetime import datetime,timezone
import requests
from dotenv import dotenv_values
b=Path(__file__).parent;sha='d62d78a0db36118df302f5f63e6ed992e01154dc'
s=requests.Session();s.headers['Authorization']='Bearer '+dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'];api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(p):
 r=s.get(api+p,timeout=45);r.raise_for_status();return r
checks=[]
for page in range(1,5):
 rows=get('/commits/'+sha+'/check-runs?per_page=100&page='+str(page)).json()['check_runs'];checks+=rows
 if len(rows)<100:break
runs=get('/actions/runs?head_sha='+sha+'&per_page=100').json()['workflow_runs']
d={'at':datetime.now(timezone.utc).isoformat(),'candidate_ref':sha,'checks':checks,'runs':runs};(b/('final-ci-'+sha[:10]+'.json')).write_text(json.dumps(d,indent=2))
print(json.dumps({'checks':len(checks),'unfinished':[c['name'] for c in checks if c['status']!='completed'],'failures':[c['name'] for c in checks if c['conclusion'] in ('failure','cancelled','timed_out')]}),flush=True)
run=next(r for r in runs if r['name']=='Tests');assert run['conclusion']=='success',str((run['status'],run['conclusion']))
artifacts=get('/actions/runs/'+str(run['id'])+'/artifacts?per_page=100').json()['artifacts'];a=next(a for a in artifacts if a['name'].startswith('proof-or-stop-'))
out=b/'main-d62-proof';out.mkdir(exist_ok=True)
data=get('/actions/artifacts/'+str(a['id'])+'/zip').content;(out/(a['name']+'.zip')).write_bytes(data)
with zipfile.ZipFile(io.BytesIO(data)) as z:
 for n in z.namelist():
  if n.endswith('/'):continue
  q=out/'extracted'/n;assert q.resolve().is_relative_to(out.resolve());q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(n))
verification=json.loads(next((out/'extracted').rglob('verification.json')).read_text());assert verification['outcome']=='ADMIT' and not verification['errors'] and not verification['degradations']
receipt={'candidate_ref':sha,'run':run,'artifact':a,'zip_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'verification':verification}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'proof':verification,'zip_sha256':receipt['zip_sha256']}))
