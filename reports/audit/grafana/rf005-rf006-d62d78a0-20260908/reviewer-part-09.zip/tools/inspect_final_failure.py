import json,re
from pathlib import Path
import requests
from dotenv import dotenv_values
b=Path(__file__).parent;s=requests.Session();s.headers['Authorization']='Bearer '+dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
r=s.get('https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition/actions/jobs/102101212737/logs',timeout=40);r.raise_for_status();(b/'cab-architecture-d.log').write_text(r.text,encoding='utf-8')
lines=r.text.splitlines();hits=[i for i,l in enumerate(lines) if re.search(r'FAILED |AssertionError|E   |short test summary',l)]
for i in hits[-15:]:print('\n'.join(lines[max(0,i-1):i+3]))
