const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('C:/Users/Fedor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {captureScrollSurface}=require('E:/github/BioactivityDataAcquisition-stream-a/scripts/ops/observability/grafana/capture_scroll_surface.cjs');
const width=Number(process.argv[2]||900),base=path.join(__dirname,'integrated-07528418e7a'),out=path.join(base,'supplement-'+width);
fs.mkdirSync(out,{recursive:true});
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const records=[];
const walk=ps=>ps.flatMap(p=>[p,...walk(p.panels||[])]);
async function scroll(page,y){return page.evaluate(y=>{
 const cs=[...document.querySelectorAll('*')].filter(e=>e.clientHeight>0&&e.clientHeight<=innerHeight+2&&e.scrollHeight>e.clientHeight+2&&e.querySelectorAll('[data-viz-panel-key]').length>1).sort((a,b)=>b.querySelectorAll('[data-viz-panel-key]').length-a.querySelectorAll('[data-viz-panel-key]').length);
 const el=cs.find(e=>{const old=e.scrollTop;e.scrollTop=1;const ok=e.scrollTop>0;e.scrollTop=old;return ok;});
 if(!el)return null;el.scrollTop=y;return {top:el.scrollTop,height:el.clientHeight,total:el.scrollHeight};
 },y);}
async function measure(page){return page.evaluate(()=>({viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio,scale:visualViewport.scale},page_horizontal_overflow:document.documentElement.scrollWidth>innerWidth+1,body:document.body.innerText}));}
(async()=>{
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 try{
 const context=await browser.newContext({viewport:{width,height:768},deviceScaleFactor:1,timezoneId:'UTC'});
 for(const file of fs.readdirSync(path.join(base,'dashboards'))){
  const d=JSON.parse(fs.readFileSync(path.join(base,'dashboards',file))),page=await context.newPage();
  const row={uid:d.uid,source_sha256:hash(fs.readFileSync(path.join(base,'dashboards',file))),width,started_at:new Date().toISOString()};
  try{
   const params=new URLSearchParams({'var-pipeline':'chembl_assay','var-run_type':'backfill','var-run_id':'b9d2eeff-8e4b-5678-ae32-b288ced27968','var-provider':'chembl','var-workflow':'$__all',from:'2026-09-08T08:30:00.000Z',to:'2026-09-08T09:00:00.000Z',timezone:'utc',theme:'dark'});
   await page.goto('http://127.0.0.1:3004/d/'+d.uid+'/'+d.uid+'?'+params,{waitUntil:'networkidle'});
   await page.getByText('Navigate Dashboards',{exact:true}).waitFor();
   if(width===1366){const open=page.getByRole('button',{name:'Open menu',exact:true});if(await open.isVisible())await open.click();const pin=page.getByRole('button',{name:'Pin menu',exact:true});if(await pin.isVisible())await pin.click();}
   const expected=walk(d.panels).filter(p=>p.type==='row'&&p.collapsed).map(p=>p.title),expanded=[];
   let y=0;
   for(let n=0;n<100;n++){
    const buttons=page.getByRole('button',{name:'Expand row',exact:true});
    for(let k=0;k<await buttons.count();k++){
     const b=buttons.nth(k);if(!await b.isVisible())continue;
     const name=await b.innerText();await b.click();expanded.push(name);k--;await page.waitForTimeout(150);
    }
    const s=await scroll(page,y);if(!s)break;
    await page.waitForTimeout(200);
    if(s.top+s.height>=s.total-2){if(await buttons.count()===0)break;}
    y=s.top+500;
   }
   row.rows={expected,expanded,remaining:await page.getByRole('button',{name:'Expand row',exact:true}).count()};
   await scroll(page,0);
   row.capture=await captureScrollSurface(page,{filePath:path.join(out,d.uid+'-expanded.png'),timeout:30000,pngEvidence:b=>({sha256:hash(b),width:b.readUInt32BE(16),height:b.readUInt32BE(20)}),measure:()=>measure(page)});
   row.observed_panels=[...new Set(row.capture.tiles.flatMap(t=>t.panels.map(p=>p.panel)))];
   await page.route('**/api/ds/query*',r=>r.fulfill({status:503,contentType:'application/json',body:JSON.stringify({message:'Controlled regression query error',error:'acceptance_fault_injection'})}));
   await page.reload({waitUntil:'networkidle'});await page.waitForTimeout(800);
   const status=page.getByRole('button',{name:'Panel status',exact:true});
   row.error_indicator_count=await status.count();
   if(await status.count()){
    await status.first().click();await page.waitForTimeout(250);
    row.error_popover=await measure(page);
    row.error_text_observed=/Controlled regression query error|503|Service Unavailable/.test(row.error_popover.body);
    await page.screenshot({path:path.join(out,d.uid+'-query-error.png')});
    fs.writeFileSync(path.join(out,d.uid+'-query-error.txt'),await page.locator('body').ariaSnapshot());
   }
   row.status='CAPTURED';
  }catch(e){row.status='ERROR';row.error=String(e.stack||e);}
  row.ended_at=new Date().toISOString();records.push(row);
  fs.writeFileSync(path.join(out,'observations.json'),JSON.stringify({candidate_ref:'07528418e7abfa5535ed50aee009b73f9fb87899',records},null,2));
  console.log(JSON.stringify({uid:row.uid,status:row.status,expanded:row.rows?.expanded.length,expected:row.rows?.expected.length,panels:row.observed_panels?.length,error_visible:row.error_text_observed,error:row.error}));
  await page.close();
 }
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
