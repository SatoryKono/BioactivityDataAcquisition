"""Isolated numeric fixture runtime, explicitly approved by the owner."""
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

out=Path(__file__).parent/'reference-fixture'
out.mkdir(exist_ok=True)
(out/'data').mkdir(exist_ok=True)
config=out/'prometheus.yml'
config.write_text('global:\n  scrape_interval: 30s\n  evaluation_interval: 30s\nscrape_configs: []\n',encoding='utf-8')
image=subprocess.check_output(['docker','inspect','--format','{{.Image}}','bioetl-prometheus'],text=True).strip()
args=['docker','run','-d','--name','bioetl-stream-b-reference-prometheus','--network','bioetl-monitoring','--publish','127.0.0.1:9094:9090','--memory','512m','--cpus','1','--label','io.bioetl.acceptance=isolated-reference-fixture','--mount',f'type=bind,source={config},target=/etc/prometheus/prometheus.yml,readonly','--mount',f'type=bind,source={out/"data"},target=/prometheus',image,'--config.file=/etc/prometheus/prometheus.yml','--storage.tsdb.path=/prometheus','--web.enable-remote-write-receiver','--storage.tsdb.retention.time=1d']
r=subprocess.run(args,capture_output=True,text=True,timeout=60,check=True)
receipt={'created_at':datetime.now(timezone.utc).isoformat(),'container_id':r.stdout.strip(),'image':image,'url':'http://127.0.0.1:9094','scope':'Isolated deterministic numeric conformance dataset; not production telemetry. No scrape jobs. Real runtime missing/UNKNOWN evidence remains separate.','owner_approval':'Использовать изолированный эталонный набор и отдельно проверить живые UNKNOWN-состояния'}
(out/'runtime.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=True))
