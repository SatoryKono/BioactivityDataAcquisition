import concurrent.futures
import json
import sys
from pathlib import Path
from datetime import datetime, timezone
import requests
from dotenv import dotenv_values

sys.stdout.reconfigure(encoding='utf-8')
out=Path(__file__).parent
token=dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Cache-Control':'no-cache'}
base='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(path):
    r=requests.get(base+path,headers=headers,timeout=90)
    r.raise_for_status()
    return r.json()
numbers=sorted(set([10163,10164,10165,10166,10167,10170,10171,*range(10172,10195)]))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    issues=list(pool.map(lambda n:get(f'/issues/{n}'),numbers))
main=get('/commits/main')
prs=get('/pulls?state=open&per_page=100')
data={'captured_at':datetime.now(timezone.utc).isoformat(),'main_sha':main['sha'],'issues':issues,'pull_requests':prs}
(out/'live-inventory.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'main_sha':main['sha'],'issues':[{'number':i['number'],'state':i['state'],'closed_at':i['closed_at'],'title':i['title']} for i in issues],'prs':[{'number':p['number'],'title':p['title'],'branch':p['head']['ref'],'sha':p['head']['sha']} for p in prs]},ensure_ascii=False))
