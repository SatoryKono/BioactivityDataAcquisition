"""Package actual AI observations; this is not the combined release gate."""
import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path
from datetime import datetime, timezone
import struct

base=Path(__file__).parent
source=base/'operator-1895351a8a'
repo=Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
sys.path.insert(0,str(repo))
from scripts.ops.observability.grafana.regression_acceptance import _operator, _verify_evidence

bundle=base/'rf004-reviewer-bundle-1895351a8a'
bundle.mkdir(exist_ok=True)
def dump(name,value):
    p=bundle/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    return descriptor(name)
def descriptor(name):
    p=bundle/name
    return {'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def copy_file(p,name):
    dest=bundle/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    return descriptor(name)

for name in ('source-binding.json','source-binding-adjudication.json','answer-keys.json','operator-task-protocol.json','pilot-observations.json'):
    copy_file(source/name,name)
for directory in ('answer-key-raw','controlled-session','controlled-session-v2'):
    for p in sorted((source/directory).iterdir()):
        if p.is_file():copy_file(p,directory+'/'+p.name)
for p in (base/'operator-browser.cjs',base/'operator-browser-before-scroll-repair.cjs',base/'resume_artifact_measurement.py'):
    copy_file(p,'measurement-tools/'+p.name)

protocol=json.loads((source/'operator-task-protocol.json').read_text(encoding='utf-8'))
keys=json.loads((source/'answer-keys.json').read_text(encoding='utf-8'))
records=json.loads((source/'controlled-session-v2/observations.json').read_text(encoding='utf-8'))['records']
assert len(records)==21 and len({r['task_id'] for r in records})==21
assert {r['task_id'] for r in records}=={t['task_id'] for t in protocol['tasks']}
assert all(r['success'] is True for r in records)
assert all(r.get('destination_verified') and r.get('return_verified') for r in records if r['task_id'].endswith(':Q3'))
pngs=list((bundle/'controlled-session-v2').glob('*.png'))
for p in pngs:
    data=p.read_bytes()
    assert data[:8]==b'\x89PNG\r\n\x1a\n',p
    assert struct.unpack('>II',data[16:24])==(1366,768),p

raw_text=json.loads((bundle/'controlled-session-v2/076-artifact.txt').read_text(encoding='utf-8').strip().removeprefix('- text: '))
raw=json.loads(raw_text)
original=Path('E:/github/BioactivityDataAcquisition/reports/run-reports/pipeline/chembl_assay/b9d2eeff-8e4b-5678-ae32-b288ced27968/pipeline-run-report.json')
assert raw==json.loads(original.read_text(encoding='utf-8'))
dump('artifact-identity-review.json',{'status':'PASS','browser_document':descriptor('controlled-session-v2/076-artifact.txt'),'original_file_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'semantic_json_equal':True,'run_id':raw['identity']['run_id'],'gold_in':raw['funnel'][-1]['records_in'],'gold_out':raw['funnel'][-1]['records_out'],'gold_excluded':raw['contract_summary']['gold_excluded_by_contract'],'gold_delta':raw['reconciliation']['gold_delta']})

observations=[]
for row in records:
    task=next(t for t in keys['tasks'] if t['task_id']==row['task_id'])
    captures=[]
    for name in row['evidence']:
        p=bundle/'controlled-session-v2'/name
        capture=json.loads(p.read_text(encoding='utf-8'))
        assert capture['candidate_ref']==keys['candidate_ref']
        assert capture['geometry']=={'width':1366,'height':768,'dpr':1,'scale':1}
        captures.append({'capture':descriptor('controlled-session-v2/'+name),'png':descriptor('controlled-session-v2/'+capture['screenshot']),'dom':descriptor('controlled-session-v2/'+capture['snapshot'])})
    evidence=dump('task-evidence/'+row['task_id'].replace(':','-')+'.json',{'candidate_ref':keys['candidate_ref'],'task_id':row['task_id'],'captures':captures,'reviewer':'Astra AI self-assessment; not an independent human review'})
    answer_key=dump('task-keys/'+row['task_id'].replace(':','-')+'.json',{**task,'candidate_ref':keys['candidate_ref'],'raw_references':[descriptor('answer-key-raw/'+n) for n in task['reference_files']],'rubric_review':'Visible answer preserves state/scope/unknown distinctions. Q3 destination and permitted return were observed. Raw report identity and accounting independently equal the stored report.','human_review':'NOT_MEASURED'})
    observations.append({**row,'participant_id':'Astra','attempt_kind':'first','attempt_kind_definition':'First eligible attempt in the complete, viewport/fixture-validated session. Prior invalid sessions and all repair pauses are retained and disclosed. Prior exposure is not zero.','evidence':evidence,'answer_key_evidence':answer_key})

receipt={'candidate_ref':keys['candidate_ref'],'occurrence_id':'rf004-ai-1895351a8a-20260908','time_range':keys['time_range'],'variable_matrix':[keys['variables']],'viewports':[[1366,768]],'acceptance_mode':'AI_SCENARIOS','page_goals_approved_by':protocol['page_goals_approved_by'],'primary_role':protocol['primary_role'],'human_usability_status':'NOT_MEASURED','observations':observations,'excluded_runs':[{'path':'pilot-observations.json','reason':'20 tasks: requested viewport not applied by CUA; measured DOM 1280x720.'},{'path':'controlled-session/observations.json','reason':'Incomplete 12-task preliminary session; Provider Q3 fixture omitted pipeline_context and is explicitly unsuccessful. Entire preliminary session excluded.'}],'limitations':['One AI participant with extensive prior exposure; no independent reviewer or human usability result.','Elapsed includes model/tool latency, nested-table navigation and repairs; no human timing targets apply.','Run Explorer Q3 elapsed uses the conservative edge of a 0.111-second start interval after a harness crash; the full repair delay remains included.','This candidate-specific operator receipt does not accept RF-005/RF-006 or replace final Stream A measurements.']}
dump('operator-receipt.json',receipt)
_verify_evidence(bundle,'operator',receipt)
result=_operator(receipt,'AI_SCENARIOS')
assert result['status']=='PASS',result
dump('operator-gate.json',{'evaluated_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':keys['candidate_ref'],'scope':'RF-004 operator component only; not combined release acceptance','result':result})
stats=next(s for s in result['statistics'] if s['participant_type']=='AI_AGENT' and s['attempt_kind']=='first' and s['task_id']=='ALL')
dump('scope-decision.json',{'candidate_ref':keys['candidate_ref'],**protocol['scope_decision'],'page_goals_approved_by':protocol['page_goals_approved_by'],'operator':'Astra','participant_type':'AI_AGENT','human_usability_status':'NOT_MEASURED'})
lines=['# RF-004: AI operator evidence on 1895351a8a','','21/21 scenarios completed; one AI participant (Astra), prior exposure disclosed. Human N=0, human usability NOT_MEASURED. This is not the combined RF-005/RF-006 release gate.','','| Metric | N | Median | Max |','| --- | ---: | ---: | ---: |']
for field in ('elapsed_seconds','clicks','interactions','diagnostic_depth','context_loss','back_navigation'):
    s=stats[field];lines.append(f"| {field} | {s['sample_size']} | {s['median']} | {s['max']} |")
lines+=['','Elapsed includes all tool/model and repair overhead. DQ Q2 resumed the same timer after fixing the scroll target. Run Explorer Q3 resumed after a background requestAnimationFrame capture stall; its start has 0.111 s uncertainty and the conservative elapsed bound is reported. These values are descriptive AI execution times, not human comprehension times.','','Previous 20-task CUA pilot and 12-task preliminary controlled run are included, explicitly ineligible. No failed preliminary attempt was relabelled successful. The full corrected session is retained, including its technical pauses.','','All 79 controlled-session-v2 screenshots are 1366×768, and recorded DOM geometry is 1366×768 / DPR 1 / visual viewport scale 1. All seven provisioned dashboard models and all 2469 Python source files were bound to candidate 1895351a8a before measurement. Source-binding adjudication preserves eight omitted non-runtime files.','','The JSON opened through the actual artifact link is semantically identical to the stored report. Unknown/current/window/selected-run distinctions were retained. Replay was not executed.','','Canonical operator verifier: PASS. Other release gates: not evaluated by this bundle. Final integration with Stream A and Windows full-profile acceptance remain required.']
(bundle/'README.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
inventory=[descriptor(p.relative_to(bundle).as_posix()) for p in sorted(bundle.rglob('*')) if p.is_file() and p.name!='manifest.json']
dump('manifest.json',{'candidate_ref':keys['candidate_ref'],'files':inventory})
for item in inventory:assert hashlib.sha256((bundle/item['path']).read_bytes()).hexdigest()==item['sha256']
zip_path=base/'rf004-reviewer-bundle-1895351a8a.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(bundle.rglob('*')):
        if p.is_file():archive.write(p,p.relative_to(bundle).as_posix())
print(json.dumps({'status':result['status'],'stats':stats,'pngs':len(pngs),'bundle':str(zip_path),'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'size_bytes':zip_path.stat().st_size}))
