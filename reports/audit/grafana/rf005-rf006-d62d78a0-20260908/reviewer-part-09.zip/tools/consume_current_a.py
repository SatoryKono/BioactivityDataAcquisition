"""Read-only consumption of complete Stream A capture manifests."""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

a = Path('E:/github/BioactivityDataAcquisition-stream-a')
sys.path.insert(0, str(a))
from scripts.ops.observability.grafana.capture_provenance import verify_capture
from scripts.ops.observability.grafana.capture_acceptance import assess_manifest, matrix_coverage

os.environ['GIT_CONFIG_COUNT'] = '1'
os.environ['GIT_CONFIG_KEY_0'] = 'safe.directory'
os.environ['GIT_CONFIG_VALUE_0'] = a.as_posix()
head = subprocess.check_output(['git', '-C', str(a), 'rev-parse', 'HEAD'], text=True).strip()
capture = a / 'reports/audit/grafana/stream-a-5f37b33ebd-matrix'
profiles = []
manifests = []
for path in sorted(capture.glob('*/render-manifest--full-set--*.json')):
    manifest = json.loads(path.read_text(encoding='utf-8'))
    manifests.append(manifest)
    profiles.append({'profile': path.parent.name, 'provenance': verify_capture(path, repo_root=a), 'assessment': assess_manifest(manifest)})
result = {'captured_at': datetime.now(timezone.utc).isoformat(), 'a_checkout_ref': head, 'scope': 'Read-only preview of currently complete capture profiles, without a supplied cue review. Not final combined acceptance.', 'matrix': matrix_coverage(manifests), 'profiles': profiles}
destination = Path(__file__).parent / ('stream-a-consumption-' + datetime.now(timezone.utc).strftime('%H%M%S') + '.json')
destination.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'path': str(destination), 'a_checkout_ref': head, 'matrix': result['matrix'], 'profiles': [{'profile': r['profile'], 'provenance': r['provenance']['status'], 'layout': r['assessment']['layout_status'], 'accessibility_without_cue_review': r['assessment']['accessibility_status']} for r in profiles]}))
