import json,time
from datetime import datetime,timezone
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests
def check(port):
 start=time.monotonic()
 try:
  r=requests.get(f'http://127.0.0.1:{port}/health/live',timeout=5)
  return {'port':port,'status':r.status_code,'elapsed':time.monotonic()-start,'body':r.json()}
 except requests.RequestException as e:return {'port':port,'error':type(e).__name__,'elapsed':time.monotonic()-start}
result={'at':datetime.now(timezone.utc).isoformat(),'checks':list(ThreadPoolExecutor(2).map(check,[8000,8002]))}
path=Path(__file__).parent/('health-latency-'+datetime.now(timezone.utc).strftime('%H%M%S')+'.json');path.write_text(json.dumps(result,indent=2));print(json.dumps(result))
