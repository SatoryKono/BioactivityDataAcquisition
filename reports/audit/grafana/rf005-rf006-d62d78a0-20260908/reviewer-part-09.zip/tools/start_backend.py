"""Start a supplementary candidate backend without touching shared services."""
import json
import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values

root = Path('E:/github/BioactivityDataAcquisition')
out = Path(__file__).parent
candidate = root / '.worktrees/operator-acceptance-closeout-20260908'
sha = 'e2a83a96f8aa9baf944c34ca735e59d3541f5c4c'
env = os.environ.copy()
values = dotenv_values(root / '.env')
for name in ('NEO4J_USERNAME', 'NEO4J_PASSWORD'):
    if values.get(name):
        env[name] = values[name]

def run(args):
    result = subprocess.run(args, env=env, capture_output=True, text=True, encoding='utf-8', timeout=60)
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout.strip()

actual = run(['git', '-C', str(candidate), 'rev-parse', 'HEAD'])
assert actual == sha
assert not run(['git', '-C', str(candidate), 'status', '--porcelain'])
old = json.loads(run(['docker', 'inspect', 'bioetl']))[0]
old_env = dict(v.split('=', 1) for v in old['Config']['Env'] if '=' in v)
env['BIOETL_RUNTIME_SOURCE_ID'] = old_env['BIOETL_RUNTIME_SOURCE_ID']
env['BIOETL_PROMETHEUS_URL'] = 'http://prometheus:9090'
env['BIOETL_REPORT_ROOT'] = '/app/reports/run-reports'
env['BIOETL_ENFORCE_REPORT_ROOT_MARKER'] = '1'
image = json.loads(run(['docker', 'image', 'inspect', 'bioetl-stream-b:e2a83a96']))[0]
assert image['Config']['Labels']['org.opencontainers.image.revision'] == sha
args = ['docker', 'run', '-d', '--name', 'bioetl-stream-b-backend', '--init', '--network', 'bioetl-monitoring',
        '--publish', '127.0.0.1:8002:8000', '--memory', '768m', '--memory-reservation', '384m', '--cpus', '1', '--pids-limit', '384',
        '--label', 'io.bioetl.acceptance=supplementary-stream-b', '--label', 'org.opencontainers.image.revision='+sha]
for name in ('NEO4J_USERNAME', 'NEO4J_PASSWORD', 'BIOETL_RUNTIME_SOURCE_ID', 'BIOETL_PROMETHEUS_URL', 'BIOETL_REPORT_ROOT', 'BIOETL_ENFORCE_REPORT_ROOT_MARKER'):
    if name in env:
        args += ['--env', name]
for name in ('data', 'reports', 'configs'):
    args += ['--mount', f'type=bind,source={root/name},target=/app/{name},readonly']
logs = out / 'isolated-backend-logs'
logs.mkdir(exist_ok=True)
args += ['--mount', f'type=bind,source={logs},target=/app/logs', '--entrypoint', 'bioetl', image['Id'], 'health', 'server', '--host', '0.0.0.0', '--port', '8000']
container_id = run(args)
receipt = {'source_sha': sha, 'image_id': image['Id'], 'container_id': container_id, 'container_name': 'bioetl-stream-b-backend', 'url': 'http://127.0.0.1:8002', 'data_source_id': env['BIOETL_RUNTIME_SOURCE_ID'], 'scope': 'supplementary backend check; shared runtime unchanged', 'previous_image_id': old['Image']}
(out / 'isolated-backend.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
(out / 'candidate.json').write_text(json.dumps({'source_sha': sha, 'worktree': str(candidate), 'clean': True}, indent=2), encoding='utf-8')
print(json.dumps(receipt))
