import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import requests

out=Path(__file__).parent
candidate=Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
rows=[]
for path in sorted((candidate/'grafana/dashboards').glob('*.json')):
    source=json.loads(path.read_text(encoding='utf-8'))
    response=requests.get('http://127.0.0.1:3003/api/dashboards/uid/'+source['uid'],timeout=15)
    response.raise_for_status()
    runtime=response.json()['dashboard']
    captured=out/'browser-runtime'/f"{source['uid']}-runtime.json"
    captured.write_text(json.dumps(runtime,indent=2),encoding='utf-8')
    for obj in (source,runtime):
        for key in ('id','version'):
            obj.pop(key,None)
    rows.append({'uid':source['uid'],'equal_except_id_version':source==runtime,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'runtime_evidence':str(captured.relative_to(out))})
result={'captured_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':'e2a83a96f8aa9baf944c34ca735e59d3541f5c4c','rows':rows,'passed':all(r['equal_except_id_version'] for r in rows)}
(out/'browser-source-parity.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
