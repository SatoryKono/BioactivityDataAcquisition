"""Preserve canonical Windows status and independent target/source readbacks."""
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
out=Path(__file__).parent/'windows-full-profile-readback'
out.mkdir(exist_ok=True)
env=os.environ.copy()
env.update({k:v for k,v in dotenv_values(root/'.env').items() if v is not None})
env['PYTHONUTF8']='1'
def dump(name,data):
    p=out/name;p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    return {'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
results=[]
for stack in ('main','monitoring'):
    cmd=[sys.executable,'scripts/ops/runtime/docker/runtime_manager.py','status','--stack',stack,'--report-dir',str(out/stack)]
    started=datetime.now(timezone.utc).isoformat()
    p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',timeout=180)
    receipt={'started_at':started,'ended_at':datetime.now(timezone.utc).isoformat(),'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    results.append({'stack':stack,'exit_code':p.returncode,'evidence':dump(stack+'-status.json',receipt)})
    print(json.dumps({'stack':stack,'exit_code':p.returncode}),flush=True)
targets=requests.get('http://127.0.0.1:9090/api/v1/targets',timeout=20).json()
dump('prometheus-targets.json',targets)
active=targets['data']['activeTargets']
assert len(active)==5,len(active)
assert all(t['health']=='up' and not t['lastError'] for t in active),[(t['labels'],t['health']) for t in active]
containers=json.loads(subprocess.check_output(['docker','ps','--format','json'],text=True).strip().replace('\n',',')) if False else []
for name in ('bioetl','bioetl-grafana','bioetl-prometheus'):
    p=subprocess.run(['docker','inspect',name],capture_output=True,text=True,encoding='utf-8')
    if p.returncode: continue
    c=json.loads(p.stdout)[0]
    containers.append({'name':name,'id':c['Id'],'image':c['Image'],'state':c['State'],'restart_count':c['RestartCount'],'mounts':c['Mounts']})
dump('containers.json',{'containers':containers})
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
receipt={'captured_at':datetime.now(timezone.utc).isoformat(),'checkout_ref':sha,'platform':sys.platform,'canonical_status_checks':results,'prometheus_target_count':len(active),'targets_up':sum(t['health']=='up' for t in active),'all_statuses_passed':all(r['exit_code']==0 for r in results),'limitations':['This receipt binds canonical Windows runtime checks to the recorded checkout. Dashboard layout acceptance and final candidate source equivalence are separate receipts.'],'targets':{'path':'prometheus-targets.json','sha256':hashlib.sha256((out/'prometheus-targets.json').read_bytes()).hexdigest()}}
dump('receipt.json',receipt)
print(json.dumps(receipt))
sys.exit(0 if receipt['all_statuses_passed'] else 1)
