import json
import hashlib
from pathlib import Path

source = Path('C:/Users/Fedor/.codex/sessions/2026/09/08/rollout-2026-09-08T08-30-04-01a07f7e-b2e8-74e2-89b5-36b264017f50.jsonl')
marker = 'STREAM_B_PILOT_EXPORT_JSON_V1\n'
found = None
for line in source.open(encoding='utf-8'):
    record = json.loads(line)
    payload = record.get('payload', {})
    if payload.get('type') != 'function_call_output':
        continue
    outputs = payload.get('output', [])
    if isinstance(outputs, str):
        outputs = [{'text': outputs}]
    for block in outputs:
        value = block.get('text', '') if isinstance(block, dict) else ''
        if marker in value:
            raw = value.split(marker, 1)[1]
            found, _ = json.JSONDecoder().raw_decode(raw)
assert found is not None, 'Export not present in current task transcript'
out = Path(__file__).parent / 'operator-1895351a8a' / 'pilot-observations.json'
out.write_text(json.dumps(found, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'path': str(out), 'observations': len(found['observations']), 'status': found['protocol_status'], 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}))
