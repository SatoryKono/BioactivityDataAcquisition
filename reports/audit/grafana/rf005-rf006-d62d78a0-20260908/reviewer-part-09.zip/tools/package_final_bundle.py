import csv,hashlib,io,json,re,shutil,zipfile
from pathlib import Path
from datetime import datetime,timezone
from dotenv import dotenv_values
b=Path(__file__).parent;out=b/'combined-reviewer-bundle';packages=b/'final-packages';packages.mkdir(exist_ok=True)
sha='d62d78a0db36118df302f5f63e6ed992e01154dc'
gate=json.loads((out/'release-gate.json').read_text());assert gate['release_passed'] and gate['candidate_ref']==sha
for p in b.glob('*.py'):shutil.copyfile(p,out/'tools'/p.name)
for p in b.glob('*.cjs'):shutil.copyfile(p,out/'tools'/p.name)
shutil.copyfile('scripts/ops/observability/grafana/regression_acceptance.py',out/'tools/regression_acceptance.py')
findings=json.loads((out/'gates/findings.json').read_text())['findings']
with (out/'finding-dispositions.csv').open('w',encoding='utf-8',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['id','severity','disposition','actual','expected','comparison','tolerance','evidence']);writer.writeheader()
 for row in findings:writer.writerow({k:(row[k]['path'] if k=='evidence' else row[k]) for k in writer.fieldnames})
table='\n'.join('| '+r['id']+' | '+r['severity']+' | FIXED | [review]('+r['after']['path']+') |' for r in findings)
readme=f'''# RF-005 / RF-006 final regression acceptance

Candidate: `{sha}`. Reviewer: **Astra, AI agent**. The canonical [release gate](release-gate.json) is PASS; all 48 baseline findings have proved dispositions. This bundle supports #10185 acceptance followed by #10171 tracker closure. RF-004 #10167 was already accepted under the owner's explicit AI-only scope.

The owner accepted AI verification of 21 diagnostic scenarios and a controlled known-input reference with separate live UNKNOWN checks. **Human usability is NOT_MEASURED (N=0); live telemetry completeness is not claimed; replay was not executed.** These limitations are retained in the gate and raw receipts.

## Review route

1. Read [contract](contract.json), [scope](reviews/profile-scope.json), [owner numeric scope](reviews/owner-data-integrity-scope.json) and [AI scope](reviews/operator-scope-decision.json).
2. Check [final source equivalence](reviews/final-source-equivalence.json). Capture refs remain unchanged: Stream A `68ec26b17b`, integration `07528418e7a`, Windows `cab240755d`. Git objects on applicable runtime surfaces equal final candidate; old rewritten history is not claimed as ancestry.
3. Inspect [findings](gates/findings.json), [original issue snapshots](baseline/retest-cases.json), [attempt dispositions](reviews/attempt-dispositions.json) and the table below. Historical failed/incomplete attempts are evidence of attempts, not passing captures.
4. Inspect [numeric conformance](reference/conformance-results.json), [all variable cases](reference/matrix-adjudication.json), [critical lineage](reference/critical-panel-lineage.json), [live integrity](live-integrity/reference-adjudication.json), [focused original retests](reviews/focused-retests.json).
5. Inspect [Windows full profile](windows/windows-cab-full-profile/receipt.json), [source binding adjudication](reviews/windows-source-adjudication.json), [final CI checks](final-ci-d62d78a0db.json), [downloaded producer receipt](ci/receipt.json), [archived Proof verification](ci/archived-verification.json).

## Results and limits

| Evidence | Result |
| --- | --- |
| Stream A layout / accessibility | 15 profiles, 105 dashboard observations; 8402/8402 required text and 1886/1886 graphics contrast samples; 45 disabled-graphic exemptions retained; zero color-only meanings |
| Live browser regression | 84 observations at900/1366; 560 navigation/context assertions; 14 query-error popovers |
| Original 1000-width supplement | Seven expanded dashboards and seven actual query-error popovers; separate identity panel1000/1366 and six timeline tooltip observations |
| Set range to run | 20 assertions, selected report bounds plus margin, IN RANGE after return |
| Numeric reference | 50/50 primary cases (25 data panels ×15m/6h); all225 variable cases adjudicated:161 numeric/table,56 state-only,8 expected invalid-query responses |
| Zero / absent data | Ten known-zero stats;55 table field configurations keep null/NaN distinct; live UNKNOWN remains explicit |
| Operator integration | 21/21 tasks;N=21 attempts,one AI;elapsed median42.929s/max635.914s;clicks median1/max2;interactions2/6;context loss0;back navigation0/2 |
| Windows | Canonical main and monitoring status exit0;5/5targets UP;2469Python hashes and7dashboard models match |
| CI final main | Tests34242865248 succeeded; Proof ADMIT/errors0/degradations0; architecture succeeded; no failed checks |

Operator elapsed time includes tool waits and recorded interruptions/repair time;635.914s includes concurrent work/compaction, not a human understanding measure. Original RF-004 metrics and its immutable publication remain separate. Live116 NOT_VERIFIABLE cases are not converted into numeric passes by the approved reference fixture. Initial cold Windows readiness failure is retained and resolved by bounded retest with unchanged3s limits. Protected `docker-push` remains approval-waiting; no publication approval or policy bypass was performed.

No dashboard child issue was reimplemented during this final retest. The necessary CI repair is merged PR#10238: canonical telemetry regeneration from main producer34238177700, with26 focused tests passing and unchanged budgets/thresholds. Runtime mirrors were not changed in that repair; exact-final CI provides docs/runtime governance evidence. No additional full local suite was rerun after successful exact-source CI. Root secret `.env` was read only.

## Reproduce offline

Download every `reviewer-part-*.zip` listed in `archive-index.json` alongside this README, verify archive SHA256, and extract all parts into one new directory. Paths are relative and each file occurs once. Run `python verify_bundle.py` from that directory. The verifier checks every manifest byte/hash and the canonical regression contract. `stream-a/` retains its original ZIPs/source bundle and archive round-trip receipts. Large raw responses and browser PNGs are included; tools record their actual runtime prerequisites and are not silently rerun against live services.

`manifest.json` covers all bundle files except itself. The external archive index hashes each independently extractable ZIP and the manifest. The immutable Git commit of the publication binds README, gate, index and archives. The gate was written once with final candidate checked against a clean owned worktree.

## Original finding dispositions

| ID | Severity | Disposition | Evidence |
| --- | --- | --- | --- |
{table}
'''
(out/'README.md').write_text(readme,encoding='utf-8')
verifier='''import hashlib,importlib.util,json\nfrom pathlib import Path\nroot=Path(__file__).resolve().parent\nmanifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))\nfor row in manifest['files']:\n p=(root/row['path']).resolve();assert p.is_relative_to(root),row['path']\n raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']\nspec=importlib.util.spec_from_file_location('regression_acceptance',root/'tools/regression_acceptance.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)\nresult=module.evaluate(root/'contract.json');assert result['release_passed'],result\nassert result==json.loads((root/'release-gate.json').read_text(encoding='utf-8'))\nprint(json.dumps({'files_verified':len(manifest['files']),'candidate_ref':result['candidate_ref'],'release_passed':True}))\n'''
(out/'verify_bundle.py').write_text(verifier,encoding='utf-8')
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='manifest.json' or p.is_file() and p.parent!=out and p.name=='manifest.json')
env=dotenv_values('E:/github/BioactivityDataAcquisition/.env');secrets=[v.encode() for k,v in env.items() if v and len(v)>=12 and re.search(r'TOKEN|PASSWORD|SECRET|API_KEY|PAT_TOKEN',k,re.I)]
def check(raw,label):
 assert not any(v in raw for v in secrets),'Configured credential in '+label
 if raw[:4]==b'PK\x03\x04':
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if not n.endswith('/'):assert not any(v in z.read(n) for v in secrets),'Configured credential in archive '+label+'/'+n
rows=[]
for p in files:
 raw=p.read_bytes();check(raw,p.relative_to(out).as_posix());rows.append({'path':p.relative_to(out).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'candidate_ref':sha,'created_at':datetime.now(timezone.utc).isoformat(),'configured_secret_scan':'PASS; values never printed; nested original archives checked','files':rows}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');files.append(out/'manifest.json')
print(json.dumps({'files':len(files),'bytes':sum(p.stat().st_size for p in files),'secret_scan':'PASS'}),flush=True)
groups=[];group=[];size=0
for p in files:
 n=p.stat().st_size
 if group and size+n>45*1024*1024:groups.append(group);group=[];size=0
 group.append(p);size+=n
if group:groups.append(group)
archives=[];verified=0
for i,group in enumerate(groups,1):
 p=packages/f'reviewer-part-{i:02}.zip';assert not p.exists(),'Archive already exists; no overwrite'
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for q in group:z.write(q,q.relative_to(out).as_posix())
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():assert hashlib.sha256(z.read(n)).digest()==hashlib.sha256((out/n).read_bytes()).digest();verified+=1
 raw=p.read_bytes();archives.append({'file':p.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'files':len(group)});print(json.dumps(archives[-1]),flush=True)
index={'candidate_ref':sha,'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'files_roundtrip_verified':verified,'archives':archives,'extraction':'Extract all independent ZIP parts into the same empty directory, then run python verify_bundle.py.'}
(packages/'archive-index.json').write_text(json.dumps(index,indent=2));print(json.dumps({'roundtrip_verified':verified,'archives':len(archives)}))
