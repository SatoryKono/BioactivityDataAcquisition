const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('C:/Users/Fedor/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const out=path.join(__dirname,'reference-fixture','timeline-tooltips-v3');fs.mkdirSync(out,{recursive:true});
(async()=>{const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});try{for(const width of [1000,1366]){const context=await browser.newContext({viewport:{width,height:768},deviceScaleFactor:1,timezoneId:'UTC'}),page=await context.newPage();const result={width,at:new Date().toISOString(),captures:[]};try{
await page.goto('http://127.0.0.1:3005/d/bioetl-incident-v1/bioetl-incident-v1?var-pipeline=chembl_assay&var-run_type=backfill&var-run_id=b9d2eeff-8e4b-5678-ae32-b288ced27968&var-provider=chembl&from=2026-09-08T08:30:00.000Z&to=2026-09-08T09:00:00.000Z&timezone=utc',{waitUntil:'networkidle'});
await page.getByText('Navigate Dashboards',{exact:true}).waitFor();
await page.mouse.move(width-8,700);
for(let n=0;n<8 && await page.getByRole('button',{name:'Expand row',exact:true}).count()===0;n++){await page.mouse.wheel(0,450);await page.waitForTimeout(300);}
const rows=page.getByRole('button',{name:'Expand row',exact:true}); result.row_texts=await rows.allTextContents();
await rows.filter({hasText:'Review Alert Evidence'}).click();
const panel=page.locator('[data-viz-panel-key="panel-2006"]');await panel.scrollIntoViewIfNeeded();await page.getByRole('button',{name:'Cancel',exact:true}).waitFor({state:'hidden',timeout:20000});
await panel.evaluate(el=>{const r=el.getBoundingClientRect();let parent=el.parentElement;while(parent){if(parent.scrollHeight>parent.clientHeight+5&&parent.clientHeight<=innerHeight){const old=parent.scrollTop;parent.scrollTop+=r.top-320;if(parent.scrollTop!==old)break;}parent=parent.parentElement;}});
const plot=panel.locator('.u-over');result.plot_count=await plot.count();const box=await plot.first().boundingBox();result.plot=box;result.panel=await panel.boundingBox();
for(const [name,x,y] of [['resolved',0.2,0.16],['firing',0.7,0.5],['pending',0.2,0.84]]){await page.mouse.move(box.x+box.width*x,box.y+box.height*y);await page.waitForTimeout(200);const prefix=width+'-'+name;await page.screenshot({path:path.join(out,prefix+'.png')});const text=await page.locator('body').ariaSnapshot();fs.writeFileSync(path.join(out,prefix+'.txt'),text);result.captures.push({name,url:page.url(),png:prefix+'.png',dom:prefix+'.txt',text:await page.locator('body').innerText()});}
result.status='OBSERVED';}catch(e){result.status='ERROR';result.error=String(e.stack||e);}fs.writeFileSync(path.join(out,width+'.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({width,status:result.status,plot:result.plot,error:result.error}));await context.close();}}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
