"""Publish the explicitly scoped RF-004 evidence to a new review-only branch."""
import base64
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
base=Path(__file__).parent
bundle=base/'rf004-reviewer-bundle-1895351a8a'
archive=base/'rf004-reviewer-bundle-1895351a8a-sealed.zip'
candidate='1895351a8a95f2ca451115be6639b10afba16e03'
branch='codex/rf004-evidence-1895351a8a'
prefix='reports/audit/grafana/rf004-ai-1895351a8a-20260908/'
env=dotenv_values(root/'.env')
# Fail before publishing if an actual configured credential occurs in any file.
secret_values=[v.encode() for k,v in env.items() if v and len(v)>=12 and re.search(r'TOKEN|PASSWORD|SECRET|API_KEY|PAT_TOKEN',k,re.I)]
files=[p for p in bundle.rglob('*') if p.is_file()]
assert not any(value in p.read_bytes() for p in files for value in secret_values), 'Configured credential found in evidence; publication stopped'
s=requests.Session()
s.headers.update({'Authorization':'Bearer '+env['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'],'Accept':'application/vnd.github+json'})
api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def call(method,path,**kwargs):
    r=s.request(method,api+path,timeout=90,**kwargs)
    r.raise_for_status()
    return r.json()
exists=s.get(api+'/git/ref/heads/'+branch,timeout=30)
assert exists.status_code==404, 'Evidence branch already exists; immutable publication will not overwrite it'
tree=call('GET','/git/commits/'+candidate)['tree']['sha']
entries=[]
for name,path in [('reviewer-bundle.zip',archive)]+[(name,bundle/name) for name in ('README.md','operator-observations.csv','operator-metrics.json','operator-gate.json','post-session-parity.json','layout-observation-report.md')]:
    data=path.read_bytes()
    blob=call('POST','/git/blobs',json={'encoding':'base64','content':base64.b64encode(data).decode('ascii')})['sha']
    assert blob==hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    entries.append({'path':prefix+name,'mode':'100644','type':'blob','sha':blob})
new_tree=call('POST','/git/trees',json={'base_tree':tree,'tree':entries})['sha']
commit=call('POST','/git/commits',json={'message':'docs(grafana): preserve RF-004 AI operator evidence on 1895351a8a','tree':new_tree,'parents':[candidate]})['sha']
call('POST','/git/refs',json={'ref':'refs/heads/'+branch,'sha':commit})
verified=call('GET','/git/ref/heads/'+branch)
assert verified['object']['sha']==commit
receipt={'published_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':candidate,'evidence_commit':commit,'branch':branch,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'readme_url':f'https://github.com/SatoryKono/BioactivityDataAcquisition/blob/{commit}/{prefix}README.md','download_url':f'https://github.com/SatoryKono/BioactivityDataAcquisition/raw/{commit}/{prefix}reviewer-bundle.zip','scope':'Immutable review-only evidence branch; no merge, release, or issue state transition performed.'}
(base/'rf004-publication.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
