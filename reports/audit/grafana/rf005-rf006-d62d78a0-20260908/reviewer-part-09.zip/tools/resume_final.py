import base64,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
import requests
from dotenv import dotenv_values
b=Path(__file__).parent;root=Path('E:/github/BioactivityDataAcquisition')
s=(b/'timeline-tooltip-retest.cjs').read_text()
s=s.replace("'timeline-tooltips'","'timeline-tooltips-v2'").replace(".filter({has:page.getByRole('heading',{name:'Review Alert Evidence',exact:true})})",".filter({hasText:'Review Alert Evidence'})")
(b/'timeline-tooltip-retest-v2.cjs').write_text(s)
token=dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN'];env=os.environ.copy()
env.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=root.as_posix(),GIT_CONFIG_KEY_1='http.https://github.com/.extraheader',GIT_CONFIG_VALUE_1='AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+token).encode()).decode())
r=subprocess.run(['git','fetch','origin','main'],cwd=root,env=env,capture_output=True,text=True,timeout=120);assert r.returncode==0,r.stderr
sha=subprocess.check_output(['git','rev-parse','origin/main'],cwd=root,env=env,text=True).strip()
ss=requests.Session();ss.headers['Authorization']='Bearer '+token
api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(p):
 r=ss.get(api+p,timeout=30);r.raise_for_status();return r.json()
checks=[];page=1
while True:
 d=get('/commits/'+sha+'/check-runs?per_page=100&page='+str(page))['check_runs'];checks+=d
 if len(d)<100:break
 page+=1
runs=get('/actions/runs?head_sha='+sha+'&per_page=100')['workflow_runs']
result={'at':datetime.now(timezone.utc).isoformat(),'candidate_ref':sha,'checks':checks,'runs':runs}
(b/('final-ci-'+sha[:10]+'.json')).write_text(json.dumps(result,indent=2))
print(json.dumps({'sha':sha,'checks':len(checks),'unfinished':[c['name'] for c in checks if c['status']!='completed'],'failures':[c['name'] for c in checks if c['conclusion'] in ('failure','cancelled','timed_out')],'runs':[{k:r[k] for k in ('id','name','status','conclusion')} for r in runs]}))
