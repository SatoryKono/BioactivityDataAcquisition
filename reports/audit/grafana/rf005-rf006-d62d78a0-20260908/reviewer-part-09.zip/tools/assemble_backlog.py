"""Bind historical findings to current Git ancestry without inventing retests."""
import json
from datetime import datetime, timezone
from pathlib import Path

out = Path(__file__).parent
old = Path('E:/github/wt-operator-regression-20260908/reports/audit/grafana/20260908-stream-b-reviewer-be23e624/backlog-retest-register.json')
history = json.loads((out / 'backlog-history.json').read_text(encoding='utf-8'))
previous = json.loads(old.read_text(encoding='utf-8'))
children = {r['number']: r for r in history['children']}
rows = []
for original in previous['findings']:
    row = dict(original)
    child = children[row['child_issue']]
    eligible = [p for p in child['merged_prs'] if p['ancestor_of_candidate'] and p['merged_at'] <= child['closed_at']]
    eligible.sort(key=lambda p: p['merged_at'])
    closest = eligible[-1] if eligible else None
    row.update({
        'child_state': child['state'].upper(),
        'child_closed_at': child['closed_at'],
        'merge_sha': closest['merge_sha'] if closest else None,
        'merge_reference': closest['url'] if closest else None,
        'merge_selection_basis': 'Latest referenced ancestor PR merged before issue closure; historical association, not independent runtime proof.',
        'referenced_ancestor_prs': [p for p in child['merged_prs'] if p['ancestor_of_candidate']],
        'retest_status': 'CANNOT_VERIFY',
        'reason': 'Historical implementation included in candidate. Final shared Stream A+B runtime and original per-finding browser retests remain pending.',
        'history_evidence': 'backlog-history.json',
    })
    rows.append(row)
result = {'source_ref': history['candidate_ref'], 'captured_at': datetime.now(timezone.utc).isoformat(),
          'historical_register': str(old), 'findings': rows,
          'summary': {'findings': len(rows), 'closed_children': len(children), 'merge_sha_bound': sum(bool(r['merge_sha']) for r in rows), 'current_runtime_retests_passed': 0}}
(out / 'backlog-retest-register.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result['summary']))
