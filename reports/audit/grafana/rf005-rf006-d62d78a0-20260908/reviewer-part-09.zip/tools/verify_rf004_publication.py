import hashlib
import io
import json
import sys
import zipfile
from datetime import datetime, timezone
from dataclasses import asdict
from pathlib import Path
import requests
from dotenv import dotenv_values

base=Path(__file__).parent
root=Path('E:/github/BioactivityDataAcquisition')
repo=root/'.worktrees/operator-acceptance-closeout-20260908'
sys.path.insert(0,str(repo/'src'))
from memory.proof import verify_bundle, load_policy, load_schema
pub=json.loads((base/'rf004-publication.json').read_text(encoding='utf-8'))
s=requests.Session()
s.headers['Authorization']='Bearer '+dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
api='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(path):
    r=s.get(api+path,timeout=60);r.raise_for_status();return r.json()
run=get('/actions/runs/34218177374')
assert run['head_sha']==pub['candidate_ref'] and run['conclusion']=='success'
artifacts=get('/actions/runs/34218177374/artifacts?per_page=100')['artifacts']
proofs=[a for a in artifacts if a['name'].startswith('proof-or-stop-')]
checks=[]
for artifact in proofs:
    r=s.get(api+'/actions/artifacts/'+str(artifact['id'])+'/zip',timeout=90);r.raise_for_status()
    destination=base/'main-1895351a8a-proof'/artifact['name'];destination.mkdir(parents=True,exist_ok=True)
    archive=zipfile.ZipFile(io.BytesIO(r.content))
    for entry in archive.infolist():
        assert (destination/entry.filename).resolve().is_relative_to(destination.resolve())
    archive.extractall(destination)
    for path in destination.rglob('bundle.json'):
        bundle=json.loads(path.read_text(encoding='utf-8'))
        assert bundle['source']['head_sha']==pub['candidate_ref']
        result=asdict(verify_bundle(bundle=bundle,repo_root=repo,policy=load_policy(repo/'configs/quality/proof_or_stop_policy.yaml'),schema=load_schema(repo/'configs/quality/proof_or_stop_bundle.schema.json'),check_current_source=False))
        checks.append({'path':str(path),'artifact_id':artifact['id'],'result':result})
response=requests.get(pub['download_url'],timeout=90)
response.raise_for_status()
assert hashlib.sha256(response.content).hexdigest()==pub['archive_sha256']
result={'checked_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':pub['candidate_ref'],'public_download_sha256_verified':True,'source_ci_run':run['html_url'],'source_ci_proof':checks,'scope':'Source CI is independently attested. AI runtime measurements are separately self-assessed and are not represented as CI-generated.'}
(base/'rf004-publication-verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
