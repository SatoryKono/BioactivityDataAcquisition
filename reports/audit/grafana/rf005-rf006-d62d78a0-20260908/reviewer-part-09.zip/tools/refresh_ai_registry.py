import sys
from pathlib import Path
root=Path('E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
sys.path[:0] = [str(root), str(root / 'src')]
from scripts.engineering.qa.technical_debt_audit_registry import (
    load_technical_debt_audit_registry,
    compute_evidence_surface_sha256,
    build_current_audit_semantic_summary,
    render_current_audit_semantic_summary,
    SEMANTIC_SUMMARY_START,
    SEMANTIC_SUMMARY_END,
)
current_id, records = load_technical_debt_audit_registry(root)
current = next(record for record in records if record.audit_id == current_id)
digest = compute_evidence_surface_sha256(root, current.evidence_paths)
registry = root / 'configs/quality/technical_debt_audit_registry.yaml'
text = registry.read_text(encoding='utf-8')
assert text.count(current.evidence_surface_sha256) == 1
registry.write_text(text.replace(current.evidence_surface_sha256, digest), encoding='utf-8', newline='\n')
report = root / current.report_path
text = report.read_text(encoding='utf-8').replace(current.evidence_surface_sha256, digest)
current_id, records = load_technical_debt_audit_registry(root)
current = next(record for record in records if record.audit_id == current_id)
start = text.index(SEMANTIC_SUMMARY_START)
end = text.index(SEMANTIC_SUMMARY_END, start) + len(SEMANTIC_SUMMARY_END)
text = text[:start] + render_current_audit_semantic_summary(build_current_audit_semantic_summary(root, current)) + text[end:]
report.write_text(text, encoding='utf-8', newline='\n')
print('Current evidence hash and semantic summary refreshed with canonical functions.', flush=True)
