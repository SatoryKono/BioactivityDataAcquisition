import json
import os
import subprocess
from dotenv import dotenv_values

env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
repo = 'SatoryKono/BioactivityDataAcquisition'
def gh(args):
    p = subprocess.run(['gh', *args], env=env, text=True, capture_output=True, encoding='utf-8', timeout=60)
    if p.returncode:
        raise RuntimeError(p.stderr)
    return p.stdout
head = json.loads(gh(['pr', 'view', '10232', '--repo', repo, '--json', 'headRefOid']))['headRefOid']
assert head == '3ae5907f634e9f44dffc0b3ea2b9653d4b49f260'
for run_id, expected in [('34215095659', 'eeb6e865c97c79041f742d9add752685e9316213')]:
    run = json.loads(gh(['run', 'view', run_id, '--repo', repo, '--json', 'headSha,headBranch,status']))
    assert run['headSha'] == expected and expected != head
    assert run['headBranch'] == 'codex/operator-acceptance-closeout-10167-10185-10171'
    if run['status'] != 'completed':
        print(gh(['run', 'cancel', run_id, '--repo', repo]), flush=True)
    else:
        print(f'{run_id} already completed', flush=True)
