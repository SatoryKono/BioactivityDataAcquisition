import json
import os
import subprocess
from pathlib import Path
from dotenv import dotenv_values

root=Path('E:/github/BioactivityDataAcquisition')
out=Path(__file__).parent
worktree=root/'.worktrees/operator-acceptance-closeout-20260908'
branch='codex/operator-acceptance-closeout-10167-10185-10171'
env=os.environ.copy()
env['GH_TOKEN']=dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
def run(args):
    r=subprocess.run(args,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',timeout=180)
    if r.returncode:
        raise RuntimeError(r.stderr)
    return r.stdout.strip()
assert not worktree.exists(), 'candidate worktree already exists'
run(['git','-c','credential.helper=','-c','credential.helper=!gh auth git-credential','fetch','origin','main'])
sha=run(['git','rev-parse','origin/main'])
assert sha=='e2a83a96f8aa9baf944c34ca735e59d3541f5c4c', 'main advanced; re-evaluate source'
print(run(['git','worktree','add','-b',branch,str(worktree),sha]),flush=True)
(out/'candidate.json').write_text(json.dumps({'worktree':str(worktree),'branch':branch,'source_sha':sha},indent=2),encoding='utf-8')
print(json.dumps({'worktree':str(worktree),'branch':branch,'source_sha':sha}),flush=True)
