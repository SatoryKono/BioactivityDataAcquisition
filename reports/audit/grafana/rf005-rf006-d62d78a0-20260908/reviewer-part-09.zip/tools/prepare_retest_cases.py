"""Prepare source-linked cases without assigning a measured disposition."""
import hashlib
import json
import re
from pathlib import Path

out = Path(__file__).parent / 'retest-preparation'
out.mkdir(exist_ok=True)
sources = out / 'original-issues'
sources.mkdir(exist_ok=True)
history_path = Path('E:/github/wt-operator-regression-20260908/reports/audit/grafana/20260908-stream-b-reviewer-be23e624/issue-snapshots.json')
snapshots = json.loads(history_path.read_text(encoding='utf-8'))
parent_source = sources / '10171.json'
if not parent_source.exists():
    parent_source.write_text(json.dumps(snapshots['10171'], ensure_ascii=False, indent=2), encoding='utf-8')
parent_descriptor = {'path': parent_source.relative_to(out).as_posix(), 'sha256': hashlib.sha256(parent_source.read_bytes()).hexdigest()}
register = json.loads((out.parent / 'backlog-retest-register.json').read_text(encoding='utf-8'))
cases = []
for finding in register['findings']:
    issue = snapshots[str(finding['child_issue'])]
    source = sources / f"{issue['number']}.json"
    if not source.exists():
        source.write_text(json.dumps(issue, ensure_ascii=False, indent=2), encoding='utf-8')
    body_lines = issue['body'].splitlines()
    matched = [i for i, line in enumerate(body_lines) if re.search(r'\b' + finding['id'] + r'\b', line)]
    excerpts = []
    for i in matched:
        excerpts.append('\n'.join(body_lines[max(0, i - 1):min(len(body_lines), i + 7)]))
    checklist = [line for line in body_lines if re.match(r'\s*- \[[ xX]\]', line)]
    parent_rows = [line for line in snapshots['10171']['body'].splitlines() if re.search(r'\b' + finding['id'] + r'\b', line)]
    cases.append({
        'id': finding['id'], 'child_issue': issue['number'], 'title': issue['title'],
        'original_acceptance_source': issue['url'],
        'original_issue': {'path': source.relative_to(out).as_posix(), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()},
        'finding_excerpts': excerpts, 'issue_checklist': checklist,
        'parent_register': parent_descriptor, 'parent_finding_rows': parent_rows,
        'historical_state': finding['child_state'], 'merge_sha': finding['merge_sha'],
        'candidate_ref': None, 'retest_status': 'NOT_RUN', 'observation': None, 'evidence': None,
    })
assert len(cases) == 48 and len({case['id'] for case in cases}) == 48
windows_source = sources / '10184.json'
if not windows_source.exists():
    windows_source.write_text(json.dumps(snapshots['10184'], ensure_ascii=False, indent=2), encoding='utf-8')
windows = {'child_issue': 10184, 'original_issue': {'path': windows_source.relative_to(out).as_posix(), 'sha256': hashlib.sha256(windows_source.read_bytes()).hexdigest()}, 'status': 'NOT_RUN_ON_FINAL_CANDIDATE', 'scope': 'Separate Windows full-profile gate, not a 49th original visual finding'}
result = {'status': 'PREPARATION_ONLY', 'source_snapshot_sha256': hashlib.sha256(history_path.read_bytes()).hexdigest(), 'candidate_ref': None, 'case_count': len(cases), 'cases': cases, 'windows_full_profile': windows, 'limitations': ['Original issue snapshots and checklists are historical acceptance sources, not current measurements.', 'Final baseline numeric inventories and candidate-bound receipts must be populated from actual evidence, not from CLOSED history.']}
(out / 'retest-cases.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
rows = ['# Original finding retest cases', '', 'Preparation only. Every case remains NOT_RUN until a final candidate is measured.', '', '| Finding | Child issue | Original requirement | Status |', '| --- | --- | --- | --- |']
rows.extend(f"| {case['id']} | [#{case['child_issue']}]({case['original_acceptance_source']}) | {case['title'].replace('|', '/')} | NOT_RUN |" for case in cases)
(out / 'retest-cases.md').write_text('\n'.join(rows) + '\n', encoding='utf-8')
print(json.dumps({'case_count': len(cases), 'original_issue_count_including_parent_and_windows': len(list(sources.glob('*.json'))), 'cases_without_any_id_reference': [case['id'] for case in cases if not case['finding_excerpts'] and not case['parent_finding_rows']], 'path': str(out / 'retest-cases.json')}))
