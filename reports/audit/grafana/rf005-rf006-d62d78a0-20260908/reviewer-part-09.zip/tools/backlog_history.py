import concurrent.futures
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

sys.stdout.reconfigure(encoding='utf-8')
root=Path('E:/github/BioactivityDataAcquisition')
out=Path(__file__).parent
inventory=json.loads((out/'live-inventory.json').read_text(encoding='utf-8'))
token=dotenv_values(root/'.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Cache-Control':'no-cache'}
base='https://api.github.com/repos/SatoryKono/BioactivityDataAcquisition'
def get(path):
    r=requests.get(base+path,headers=headers,timeout=90)
    r.raise_for_status()
    return r.json()
children=[i for i in inventory['issues'] if i['number'] in {*range(10172,10185),*range(10187,10195)}]
def history(item):
    number=item['number']
    timeline=get(f'/issues/{number}/timeline?per_page=100')
    comments=get(f'/issues/{number}/comments?per_page=100')
    prs=set()
    for event in timeline:
        source=event.get('source',{}).get('issue',{})
        if source.get('pull_request'):
            prs.add(source['number'])
    body=item['body']+'\n'+'\n'.join(c['body'] for c in comments)
    prs.update(int(n) for n in re.findall(r'(?:/pull/|PR\s*#)(\d+)',body))
    return {'number':number,'state':item['state'],'closed_at':item['closed_at'],'timeline':timeline,'comments':comments,'referenced_prs':sorted(prs)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    history_rows=list(pool.map(history,children))
    pr_numbers=sorted({p for row in history_rows for p in row['referenced_prs']})
    prs=list(pool.map(lambda n:get(f'/pulls/{n}'),pr_numbers))
merged={}
for p in prs:
    sha=p.get('merge_commit_sha')
    if not p.get('merged') or not sha:
        continue
    check=subprocess.run(['git','merge-base','--is-ancestor',sha,inventory['main_sha']],cwd=root,capture_output=True)
    merged[p['number']]={'pr':p['number'],'merge_sha':sha,'merged_at':p['merged_at'],'ancestor_of_candidate':check.returncode==0,'url':p['html_url']}
for row in history_rows:
    row['merged_prs']=[merged[n] for n in row['referenced_prs'] if n in merged]
result={'captured_at':datetime.now(timezone.utc).isoformat(),'candidate_ref':inventory['main_sha'],'children':history_rows,'pull_requests':prs}
(out/'backlog-history.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'children':[{'number':r['number'],'state':r['state'],'merged_prs':r['merged_prs']} for r in history_rows]},ensure_ascii=False),flush=True)
