import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import requests
from dotenv import dotenv_values

out = Path(__file__).parent
values = dotenv_values('E:/github/BioactivityDataAcquisition/.env')
env = os.environ.copy()
env['GH_TOKEN'] = values['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
result = subprocess.run(['gh','pr','view','10232','--repo','SatoryKono/BioactivityDataAcquisition','--json','headRefOid,statusCheckRollup'],env=env,capture_output=True,text=True,encoding='utf-8',check=True)
pr = json.loads(result.stdout)
external = [c for c in pr['statusCheckRollup'] if 'sonar' in str(c).lower()]
session = requests.Session()
session.headers['Cache-Control'] = 'no-cache'
token = values.get('SONAR_TOKEN') or values.get('SONARQUBE_TOKEN')
if token:
    session.auth = (token, '')
project = 'SatoryKono_BioactivityDataAcquisition'
endpoints = {
    'pull_requests': ('project_pull_requests/list', {'project':project}),
    'compute_engine': ('ce/component', {'component':project,'pullRequest':'10232'}),
    'quality_gate': ('qualitygates/project_status', {'projectKey':project,'pullRequest':'10232'}),
    'issues': ('issues/search', {'componentKeys':project,'pullRequest':'10232','resolved':'false','ps':500}),
}
data = {'captured_at':datetime.now(timezone.utc).isoformat(),'head_sha':pr['headRefOid'],'github_checks':external}
for name, (endpoint, params) in endpoints.items():
    response = session.get('https://sonarcloud.io/api/'+endpoint,params=params,timeout=60)
    data[name] = response.json() if response.ok else {'http':response.status_code}
    data[name+'_http'] = {k:response.headers.get(k) for k in ('Date','Age','Cache-Control')}
(out/pr['headRefOid']).mkdir(exist_ok=True)
(out/pr['headRefOid']/'sonar-status.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps({'head_sha':pr['headRefOid'],'checks':external,'pull_request':[p for p in data['pull_requests'].get('pullRequests',[]) if p.get('key')=='10232'],'compute_engine':data['compute_engine'],'gate':data['quality_gate'].get('projectStatus',{}).get('status'),'issues':data['issues'].get('total')}),flush=True)
