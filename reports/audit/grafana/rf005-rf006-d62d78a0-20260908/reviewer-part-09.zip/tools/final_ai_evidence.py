import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from dotenv import dotenv_values

repo = 'SatoryKono/BioactivityDataAcquisition'
env = os.environ.copy()
env['GH_TOKEN'] = dotenv_values('E:/github/BioactivityDataAcquisition/.env')['GITHUB_CDX_PERSONAL_ACCESS_TOKEN']
out = Path(__file__).parent
expected = sys.argv[1]
proof_only = '--proof-only' in sys.argv
with_sonar = '--with-sonar' in sys.argv
def gh(args):
    p = subprocess.run(['gh', *args], env=env, capture_output=True, text=True, encoding='utf-8', timeout=180)
    if p.returncode:
        raise RuntimeError(p.stderr)
    return p.stdout

pr = json.loads(gh(['pr', 'view', '10232', '--repo', repo, '--json', 'number,url,headRefOid,baseRefOid,state,isDraft,mergeable,statusCheckRollup']))
assert pr['headRefOid'] == expected
runs = json.loads(gh(['run', 'list', '--repo', repo, '--commit', expected, '--limit', '100', '--json', 'databaseId,name,status,conclusion,headSha,url']))
if not proof_only:
    assert len(runs) >= 4 and all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in runs), runs
gate = next(r for r in runs if r['name'] == 'PR Gate Complete')
jobs = json.loads(gh(['run', 'view', str(gate['databaseId']), '--repo', repo, '--json', 'jobs']))['jobs']
if not proof_only:
    assert all(j['status'] == 'completed' and j['conclusion'] in ('success', 'skipped') for j in jobs)
artifacts = json.loads(gh(['api', f"repos/{repo}/actions/runs/{gate['databaseId']}/artifacts?per_page=100"]))['artifacts']
proof = [a for a in artifacts if a['name'].startswith('proof-or-stop-')]
for item in proof:
    destination = out / expected / item['name']
    if not destination.exists():
        gh(['run', 'download', str(gate['databaseId']), '--repo', repo, '--name', item['name'], '--dir', str(destination)])
proof_results = []
for path in (out / expected).rglob('verification.json'):
    value = json.loads(path.read_text(encoding='utf-8'))
    proof_results.append({'path': str(path), 'verification': value})
result = {'captured_at': datetime.now(timezone.utc).isoformat(), 'pr': pr, 'runs': runs, 'jobs': jobs, 'proof_artifacts': proof, 'proof_verification': proof_results}
if with_sonar:
    subprocess.run([sys.executable, str(out/'sonar_status.py')], check=True)
    sonar = json.loads((out/expected/'sonar-status.json').read_text(encoding='utf-8'))
    sonar_pr = next(p for p in sonar['pull_requests']['pullRequests'] if p['key'] == '10232')
    assert sonar_pr['commit']['sha'] == expected, sonar_pr
    assert sonar['quality_gate']['projectStatus']['status'] == 'OK', sonar
    assert sonar['issues']['total'] == 0, sonar['issues']
    result['sonar'] = sonar
if proof_only:
    (out / 'proof-evidence.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'ci_still_running': True, 'proof_verification': proof_results}), flush=True)
    raise SystemExit(0)
(out / 'final-ci-evidence.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
(out / expected / 'final-ci-evidence.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
proof_text = ', '.join(str(p['verification'].get('outcome')) for p in proof_results) or 'artifact unavailable'

print(json.dumps({'head':expected,'workflow_count':len(runs),'proof_outcomes':[p['verification'].get('outcome') for p in proof_results],'sonar_verified':with_sonar}),flush=True)
