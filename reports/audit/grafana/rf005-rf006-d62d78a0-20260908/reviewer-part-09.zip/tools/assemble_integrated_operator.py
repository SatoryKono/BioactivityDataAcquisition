"""Seal measured integration attempts without relabelling historical RF004 evidence."""
import hashlib
import json
import shutil
import struct
import sys
from pathlib import Path

base = Path(__file__).parent
source = base / 'operator-07528418e7a'
bundle = base / 'operator-integration-reviewer-bundle'
bundle.mkdir(exist_ok=True)
sys.path.insert(0, 'E:/github/BioactivityDataAcquisition/.worktrees/operator-acceptance-closeout-20260908')
from scripts.ops.observability.grafana.regression_acceptance import _operator, _verify_evidence

def descriptor(name):
    return {'path': name, 'sha256': hashlib.sha256((bundle / name).read_bytes()).hexdigest()}

def dump(name, value):
    p = bundle / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    return descriptor(name)

for p in source.rglob('*'):
    if p.is_file():
        dest = bundle / p.relative_to(source)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)
for name in ('operator-integrated.cjs', 'operator-integrated-before-scroll-repair.cjs'):
    shutil.copyfile(base / name, bundle / name)
protocol = json.loads((source / 'operator-task-protocol.json').read_text(encoding='utf-8'))
keys = json.loads((source / 'answer-keys.json').read_text(encoding='utf-8'))
rows = json.loads((source / 'controlled-session/observations.json').read_text(encoding='utf-8'))['records']
assert len(rows) == 21 and len({r['task_id'] for r in rows}) == 21
after = json.loads((source / 'after-binding/source-binding.json').read_text(encoding='utf-8'))
assert all(p.endswith('README.md') or p.endswith('.gitkeep') for p in after['source_mismatches'])
assert len(after['source_mismatches']) == 8
python_files = [p for p in after['expected_hashes'] if p.endswith('.py')]
assert all(after['expected_hashes'][p] == after['deployed_hashes'][p] for p in python_files)
assert all(r['runtime_equal_except_id_version'] for r in after['dashboards'])
dump('after-binding/adjudication.json', {'status':'PASS', 'python_files_equal':len(python_files), 'dashboard_models_equal':7, 'omitted_non_runtime_files':after['source_mismatches'], 'raw':descriptor('after-binding/source-binding.json')})
observations = []
for row in rows:
    task = next(t for t in keys['tasks'] if t['task_id'] == row['task_id'])
    captures = []
    for name in row['evidence']:
        c = json.loads((source / 'controlled-session' / name).read_text(encoding='utf-8'))
        assert c['geometry'] == {'width':1366,'height':768,'dpr':1,'scale':1}
        png = (source / 'controlled-session' / c['screenshot']).read_bytes()
        assert struct.unpack('>II', png[16:24]) == (1366,768)
        captures.append({k:descriptor('controlled-session/'+n) for k,n in [('capture',name),('png',c['screenshot']),('dom',c['snapshot'])]})
    ev = dump('tasks/'+row['task_id'].replace(':','-')+'.json', {'candidate_ref':keys['candidate_ref'],'task_id':row['task_id'],'captures':captures})
    key = dump('keys/'+row['task_id'].replace(':','-')+'.json', {**task,'references':[descriptor('answer-key-raw/'+n) for n in task['reference_files']]})
    observations.append({**row,'participant_id':'Astra','attempt_kind':'first','attempt_kind_definition':'First measured integration attempt per task; prior RF004 and source exposure explicitly retained. Harness restoration continues the same timer.','reviewer':'Astra AI self-assessment','evidence':ev,'answer_key_evidence':key})
receipt = {'candidate_ref':keys['candidate_ref'],'occurrence_id':'stream-b-integration-07528418e7a-20260908','time_range':keys['time_range'],'variable_matrix':[keys['variables']],'viewports':[[1366,768]],'acceptance_mode':'AI_SCENARIOS','page_goals_approved_by':protocol['page_goals_approved_by'],'primary_role':protocol['primary_role'],'human_usability_status':'NOT_MEASURED','observations':observations,'limitations':['AI participant N=1; human N=0; extensive prior exposure.','Elapsed includes concurrent acceptance work, model/tool overhead and full scroll harness restoration delay; human first-correct latency is null.','Raw measurements remain bound to 07528418e7a; applicability to later commits requires explicit source equivalence.']}
dump('operator-receipt.json',receipt)
_verify_evidence(bundle,'operator',receipt)
gate = _operator(receipt,'AI_SCENARIOS')
assert gate['status'] == 'PASS',gate
dump('operator-gate.json',gate)
artifact = json.loads(json.loads((source/'controlled-session/061-artifact.txt').read_text(encoding='utf-8').strip().removeprefix('- text: ')))
original = Path('E:/github/BioactivityDataAcquisition/reports/run-reports/pipeline/chembl_assay/b9d2eeff-8e4b-5678-ae32-b288ced27968/pipeline-run-report.json')
assert artifact == json.loads(original.read_text(encoding='utf-8'))
dump('artifact-identity-review.json',{'status':'PASS','semantic_json_equal':True,'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'browser_json':descriptor('controlled-session/061-artifact.txt'),'browser_markdown':descriptor('controlled-session/063-artifact.txt'),'selected_run':artifact['identity']['run_id']})
dump('manifest.json',{'files':[descriptor(p.relative_to(bundle).as_posix()) for p in sorted(bundle.rglob('*')) if p.is_file() and p.name!='manifest.json']})
stats = next(s for s in gate['statistics'] if s['participant_type']=='AI_AGENT' and s['attempt_kind']=='first' and s['task_id']=='ALL')
print(json.dumps({'status':gate['status'],'statistics':stats,'python_parity':len(python_files),'dashboard_parity':7}))
