import json
from pathlib import Path
from datetime import datetime

root=Path(__file__).parent/'operator-1895351a8a'/'controlled-session-v2'
start=json.loads((root/'068-start-bioetl-run-explorer-v1-Q3.json').read_text(encoding='utf-8'))
ready=json.loads((root/'067-ready-bioetl-run-explorer-v1.json').read_text(encoding='utf-8'))
prior=json.loads((root/'observations.json').read_text(encoding='utf-8'))['records'][-1]
task={k:prior[k] for k in ('candidate_ref','participant','participant_type','prior_exposure','attempt','first_correct_seconds')}
task.update(task_id='bioetl-run-explorer-v1:Q3',started_at=ready['captured_at'],clicks=3,interactions=6,context_loss=0,back_navigation=0,diagnostic_depth=1,evidence=[p.name for p in sorted(root.glob('0[67]*.json')) if 68<=int(p.name[:3])<=74],path=['Read current dashboard','Expand Selected Run Details','Inspect Run Identity','scroll 1600','scroll 1800','scroll 550','pipeline_run_report_json (popup captured by harness, screenshot evaluation stalled)'],measurement_state='PAUSED_HARNESS_REPAIR',success=False,answer='Pending final artifact verification',resume_view_panel=3013,timer_start_interval=[ready['captured_at'],start['captured_at']],elapsed_seconds_is_conservative_estimate=True,timing_disposition='The popup action reached screenshot preparation but stalled in an unbounded requestAnimationFrame evaluation for the background document. Browser was stopped. The original timer start is bracketed by the ready/start captures; use the earlier bound conservatively (uncertainty 0.111 s), retain all repair latency. Not human first-correct time.')
(root/'artifact-resume-state.json').write_text(json.dumps(task,ensure_ascii=False,indent=2),encoding='utf-8')
print(task['task_id'],task['timer_start_interval'])
