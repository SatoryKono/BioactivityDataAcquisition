import pathlib,subprocess,os,json,datetime,hashlib
work=pathlib.Path('/work/repo');work.mkdir(parents=True,exist_ok=True);out=pathlib.Path('/outputs');rows=[]
subprocess.run(['/bin/tar','-xf','/inputs/plugins-source.tar','-C',str(work)],check=True)
for plugin in ('bioetl-scenes-app','bioetl-selectorshell-panel'):
 cwd=work/'grafana/plugins'/plugin
 (cwd/'webpack.config.ts').write_bytes((pathlib.Path('/inputs')/(plugin+'-webpack.config.ts')).read_bytes())
 for name,args in [('ci',['npm','ci','--ignore-scripts','--no-fund','--no-audit']),('typecheck',['npm','run','typecheck']),('lint',['npm','run','lint']),('tests',['npm','run','test:ci']),('build',['npm','run','build']),('audit',['npm','audit','--json'])]:
  label=plugin+'-linux-v3-'+name;start=datetime.datetime.now(datetime.UTC);print('START',label,flush=True)
  with (out/(label+'.log')).open('w') as f:r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ, **({'NODE_ENV':'test'} if name=='tests' else {})})
  rows.append(dict(name=label,started_at=start.isoformat(),finished_at=datetime.datetime.now(datetime.UTC).isoformat(),exit_code=r.returncode,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()));(out/'linux-plugin-v3-stages.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
 m=json.loads((work/'grafana/tooling/router-v7-bridge/host-image.json').read_text())
 for name in ('module.js','plugin.json'):
  p=f'grafana/plugins/{plugin}/dist/{name}';print('BUNDLE_HASH',p,hashlib.sha256((work/p).read_bytes()).hexdigest(),flush=True)
 subprocess.run(['/bin/tar','-cf',f'/outputs/{plugin}-linux-dist.tar','-C',str(cwd),'dist'],check=True)
print('LINUX_PLUGIN_GATES_PASS',flush=True)
