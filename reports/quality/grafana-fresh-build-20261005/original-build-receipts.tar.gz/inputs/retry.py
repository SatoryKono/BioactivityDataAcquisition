import pathlib,json,datetime,subprocess,os,hashlib,shutil
out=pathlib.Path('/outputs'); work=pathlib.Path('/work/grafana'); rows=[]
config=work/'scripts/webpack/webpack.router-security.mjs'
assert 'config.parallelism = 2;' in config.read_text()
config.write_text(config.read_text().replace('config.parallelism = 2;', 'config.parallelism = 1;'))
build=work/'public/build'
assert build.resolve()==pathlib.Path('/work/grafana/public/build')
if build.exists(): shutil.rmtree(build)
def stage(name,args):
 start=datetime.datetime.now(datetime.UTC)
 print('START',name,start.isoformat(),flush=True)
 with (out/(name+'.log')).open('w') as f: r=subprocess.run(args,cwd=work,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,argv=args,started_at=start.isoformat(),finished_at=datetime.datetime.now(datetime.UTC).isoformat(),exit_code=r.returncode,log_sha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()))
 (out/'retry-stages.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',name,r.returncode,flush=True)
 if r.returncode: raise SystemExit(r.returncode)
(out/'retry-environment.json').write_text(json.dumps(dict(node_options=os.environ['NODE_OPTIONS'],gOMAXPROCS=os.environ['GOMAXPROCS'],config_sha256=hashlib.sha256(config.read_bytes()).hexdigest(),prior_attempt='stages.json',source_commit='454cdc4f803b8894840657f137674237e7c2b047'),indent=2)+'\n')
stage('webpack-retry',['/usr/local/bin/node','node_modules/webpack-cli/bin/cli.js','--config','scripts/webpack/webpack.router-security.mjs'])
stage('frontend-export',['/usr/bin/tar','-cf','/outputs/host-build.tar','-C',str(work/'public'),'build'])
files={f.relative_to(build).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(build.rglob('*')) if f.is_file()}
assert files
(out/'frontend-files.json').write_text(json.dumps(files,indent=2)+'\n')
print('BUILD_PASS',len(files),flush=True)
