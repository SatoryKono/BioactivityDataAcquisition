# Pipeline run report: composite_molecule

- **run_id:** `b85d1e89-1c30-59ad-b5cc-7e8ef6bc8ac8`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `2ef2e9b4-ff08-5662-a2be-35f20dd7688d`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T14:59:26.642705+00:00
- **completed_at:** 2026-10-05T15:00:57.140176+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_molecule failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2998.538975100033s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_molecule', 'run_id': 'adc858d8-fb4a-5bbd-8be0-55ad5d884d28', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-54c7c9d5-20261005-wave13\\composite-composite_molecule\\reports\\pipeline\\chembl_molecule\\adc858d8-fb4a-5bbd-8be0-55ad5d884d28\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_molecule/adc858d8-fb4a-5bbd-8be0-55ad5d884d28/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_molecule/reports/pipeline/composite_molecule/b85d1e89-1c30-59ad-b5cc-7e8ef6bc8ac8/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_molecule/reports/pipeline/composite_molecule/b85d1e89-1c30-59ad-b5cc-7e8ef6bc8ac8/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
