# Pipeline run report: composite_activity

- **run_id:** `4f0b91b9-9f71-5041-90b8-916ab50bdb6c`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `38e3c703-8461-526b-930e-44a5a12180f8`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T14:57:57.194127+00:00
- **completed_at:** 2026-10-05T14:58:33.011518+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_activity failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2995.5947989000124s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_activity', 'run_id': '4bab34a9-d7c9-5a04-823e-252e5dc1939d', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-54c7c9d5-20261005-wave13\\composite-composite_activity\\reports\\pipeline\\chembl_activity\\4bab34a9-d7c9-5a04-823e-252e5dc1939d\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_activity/4bab34a9-d7c9-5a04-823e-252e5dc1939d/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_activity/reports/pipeline/composite_activity/4f0b91b9-9f71-5041-90b8-916ab50bdb6c/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_activity/reports/pipeline/composite_activity/4f0b91b9-9f71-5041-90b8-916ab50bdb6c/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
