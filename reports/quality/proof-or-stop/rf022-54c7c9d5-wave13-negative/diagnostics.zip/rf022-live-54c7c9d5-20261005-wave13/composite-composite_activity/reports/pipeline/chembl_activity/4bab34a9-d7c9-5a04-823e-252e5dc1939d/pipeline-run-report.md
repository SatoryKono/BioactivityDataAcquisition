# Pipeline run report: chembl_activity

- **run_id:** `4bab34a9-d7c9-5a04-823e-252e5dc1939d`
- **status:** failed
- **run_type:** incremental
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `7d4c6455-a880-5649-a903-14b4ef519d7f`
- **provider/entity:** chembl / activity
- **started_at:** 2026-10-05T14:57:57.245080+00:00
- **completed_at:** 2026-10-05T14:58:32.946695+00:00
- **duration_seconds:** 35.701615

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 0 | 0 | 0 | OK | partial | — |
| bronze | 0 | 0 | 0 | OK | partial | — |
| silver | 0 | 0 | 0 | OK | partial | — |
| gold | 0 | 0 | 0 | OK | partial | — |

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `ServiceUnavailableError`
- **error_message:** `Circuit breaker open for chembl. Retry after 2995.5947989000124s`
- **failed_stage:** `None`
- **exit_hint:** `Investigate ServiceUnavailableError; check quarantine and gold contract exclusions.`

## IO

- **pipeline_name:** `chembl_activity`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `35.701615`
- **records_per_second:** `None`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_activity/reports/pipeline/chembl_activity/4bab34a9-d7c9-5a04-823e-252e5dc1939d/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_activity/reports/pipeline/chembl_activity/4bab34a9-d7c9-5a04-823e-252e5dc1939d/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
