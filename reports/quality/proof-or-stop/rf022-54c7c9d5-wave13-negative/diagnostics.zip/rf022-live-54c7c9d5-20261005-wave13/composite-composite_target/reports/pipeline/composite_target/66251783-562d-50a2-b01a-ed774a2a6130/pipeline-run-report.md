# Pipeline run report: composite_target

- **run_id:** `66251783-562d-50a2-b01a-ed774a2a6130`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `2c8fefbf-7e1b-5072-a670-cd57b95cfa62`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T15:01:06.235998+00:00
- **completed_at:** 2026-10-05T15:01:39.889858+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_target failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2995.720449300017s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_target', 'run_id': '840e0dce-9ad8-5ec2-b3cd-4f6ee1033279', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-54c7c9d5-20261005-wave13\\composite-composite_target\\reports\\pipeline\\chembl_target\\840e0dce-9ad8-5ec2-b3cd-4f6ee1033279\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_target/840e0dce-9ad8-5ec2-b3cd-4f6ee1033279/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_target/reports/pipeline/composite_target/66251783-562d-50a2-b01a-ed774a2a6130/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_target/reports/pipeline/composite_target/66251783-562d-50a2-b01a-ed774a2a6130/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
