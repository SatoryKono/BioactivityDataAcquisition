# Pipeline run report: chembl_target

- **run_id:** `840e0dce-9ad8-5ec2-b3cd-4f6ee1033279`
- **status:** failed
- **run_type:** incremental
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `2785bbad-fb60-520e-9b6f-8388d709cf58`
- **provider/entity:** chembl / target
- **started_at:** 2026-10-05T15:01:06.284480+00:00
- **completed_at:** 2026-10-05T15:01:39.836136+00:00
- **duration_seconds:** 33.551656

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 0 | 0 | 0 | OK | partial | — |
| bronze | 0 | 0 | 0 | OK | partial | — |
| silver | 0 | 0 | 0 | OK | partial | — |
| gold | 0 | 0 | 0 | OK | partial | — |

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `ServiceUnavailableError`
- **error_message:** `Circuit breaker open for chembl. Retry after 2995.720449300017s`
- **failed_stage:** `None`
- **exit_hint:** `Investigate ServiceUnavailableError; check quarantine and gold contract exclusions.`

## IO

- **pipeline_name:** `chembl_target`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `33.551656`
- **records_per_second:** `None`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_target/reports/pipeline/chembl_target/840e0dce-9ad8-5ec2-b3cd-4f6ee1033279/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_target/reports/pipeline/chembl_target/840e0dce-9ad8-5ec2-b3cd-4f6ee1033279/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
