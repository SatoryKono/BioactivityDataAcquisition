# Pipeline run report: composite_assay

- **run_id:** `0df8bc76-0aae-5982-bd50-da4f77fd8f68`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `39bd5f89-aa91-5aa1-8cc7-379539ff8581`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T14:58:44.063826+00:00
- **completed_at:** 2026-10-05T14:59:17.704056+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_assay failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2995.8918620999902s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_assay', 'run_id': '64e3060b-93ba-5d47-bba7-3aad3fb81d4d', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-54c7c9d5-20261005-wave13\\composite-composite_assay\\reports\\pipeline\\chembl_assay\\64e3060b-93ba-5d47-bba7-3aad3fb81d4d\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_assay/64e3060b-93ba-5d47-bba7-3aad3fb81d4d/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_assay/reports/pipeline/composite_assay/0df8bc76-0aae-5982-bd50-da4f77fd8f68/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-54c7c9d5-20261005-wave13/composite-composite_assay/reports/pipeline/composite_assay/0df8bc76-0aae-5982-bd50-da4f77fd8f68/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
