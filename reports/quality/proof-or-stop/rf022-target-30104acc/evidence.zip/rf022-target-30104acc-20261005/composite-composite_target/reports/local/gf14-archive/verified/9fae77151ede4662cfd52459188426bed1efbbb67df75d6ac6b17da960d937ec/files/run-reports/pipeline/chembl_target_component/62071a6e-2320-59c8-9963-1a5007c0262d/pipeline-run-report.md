# Pipeline run report: chembl_target_component

- **run_id:** `62071a6e-2320-59c8-9963-1a5007c0262d`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `117d9ddf-1613-509d-9eac-e55146d6caf9`
- **provider/entity:** chembl / target_component
- **started_at:** 2026-10-05T08:42:30.875458+00:00
- **completed_at:** 2026-10-05T08:42:58.392409+00:00
- **duration_seconds:** 27.516951

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 10 | 0 | OK | full | — |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **pipeline_name:** `chembl_target_component`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `component_id`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `8dfd3fc055af3c67`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `27.516951`
- **records_per_second:** `0.3634`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/chembl_target_component/62071a6e-2320-59c8-9963-1a5007c0262d/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/chembl_target_component/62071a6e-2320-59c8-9963-1a5007c0262d/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
