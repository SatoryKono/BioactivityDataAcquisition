# Pipeline run report: uniprot_protein

- **run_id:** `d1f97b77-7db0-516b-9de5-7a54226ab968`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `7e0fd151-208a-5015-9dc0-abe01b613474`
- **provider/entity:** uniprot / protein
- **started_at:** 2026-10-05T08:43:42.292601+00:00
- **completed_at:** 2026-10-05T08:43:47.536009+00:00
- **duration_seconds:** 5.243408

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `uniprot_protein`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `accession`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `a3c6138e0294f915`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `5.243408`
- **records_per_second:** `1.9072`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/uniprot_protein/d1f97b77-7db0-516b-9de5-7a54226ab968/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/uniprot_protein/d1f97b77-7db0-516b-9de5-7a54226ab968/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
