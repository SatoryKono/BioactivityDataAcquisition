# Pipeline run report: uniprot_idmapping

- **run_id:** `9d6e3b71-5576-5572-b580-47d3312e58fe`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `bac51158-8290-5f72-aec8-27c69fced7f8`
- **provider/entity:** uniprot / idmapping
- **started_at:** 2026-10-05T08:43:30.352154+00:00
- **completed_at:** 2026-10-05T08:43:39.559360+00:00
- **duration_seconds:** 9.207206

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `uniprot_idmapping`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `target_id`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `e79be54bb6fa21e9`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `9.207206`
- **records_per_second:** `1.0861`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/uniprot_idmapping/9d6e3b71-5576-5572-b580-47d3312e58fe/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/uniprot_idmapping/9d6e3b71-5576-5572-b580-47d3312e58fe/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
