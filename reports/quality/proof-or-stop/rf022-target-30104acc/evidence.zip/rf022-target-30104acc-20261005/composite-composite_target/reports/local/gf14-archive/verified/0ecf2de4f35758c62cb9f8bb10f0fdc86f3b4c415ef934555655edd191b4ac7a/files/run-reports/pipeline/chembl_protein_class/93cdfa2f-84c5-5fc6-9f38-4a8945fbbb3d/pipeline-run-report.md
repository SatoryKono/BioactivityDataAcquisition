# Pipeline run report: chembl_protein_class

- **run_id:** `93cdfa2f-84c5-5fc6-9f38-4a8945fbbb3d`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `06480678-f5c4-5afa-99ab-3f5fd251f708`
- **provider/entity:** chembl / protein_class
- **started_at:** 2026-10-05T08:42:59.167216+00:00
- **completed_at:** 2026-10-05T08:43:26.444357+00:00
- **duration_seconds:** 27.277141

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 9 | 9 | 0 | OK | full | — |
| bronze | 9 | 9 | 0 | OK | full | — |
| silver | 9 | 9 | 0 | OK | full | — |
| gold | 9 | 9 | 0 | OK | full | — |

## Layers

- bronze: **9**
- silver valid: **9** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **9** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **pipeline_name:** `chembl_protein_class`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `protein_class_id`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `9`
- **filter_id_hash:** `8971ab3455edbd48`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `27.277141`
- **records_per_second:** `0.3299`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/chembl_protein_class/93cdfa2f-84c5-5fc6-9f38-4a8945fbbb3d/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/chembl_protein_class/93cdfa2f-84c5-5fc6-9f38-4a8945fbbb3d/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
