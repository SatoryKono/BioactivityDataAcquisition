# Pipeline run report: composite_target

- **run_id:** `51d931dc-5918-59b7-8eef-bc1c6c4a8c34`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `48a19057-f11e-5b94-9f84-f9c4f0cdcb5d`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T08:42:09.452474+00:00
- **completed_at:** 2026-10-05T08:43:54.212882+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_target', 'run_id': '14a4ef7b-e6f8-5d47-9744-57af24509ca5', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-target-30104acc-20261005\\composite-composite_target\\reports\\pipeline\\chembl_target\\14a4ef7b-e6f8-5d47-9744-57af24509ca5\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_component', 'run_id': '62071a6e-2320-59c8-9963-1a5007c0262d', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-target-30104acc-20261005\\composite-composite_target\\reports\\pipeline\\chembl_target_component\\62071a6e-2320-59c8-9963-1a5007c0262d\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_protein_class', 'run_id': '93cdfa2f-84c5-5fc6-9f38-4a8945fbbb3d', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-target-30104acc-20261005\\composite-composite_target\\reports\\pipeline\\chembl_protein_class\\93cdfa2f-84c5-5fc6-9f38-4a8945fbbb3d\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_protein_classification', 'run_id': 'dc88875b-572a-541a-a8ae-5793e0a168a3', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-target-30104acc-20261005\\composite-composite_target\\reports\\pipeline\\chembl_target_protein_classification\\dc88875b-572a-541a-a8ae-5793e0a168a3\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_idmapping', 'run_id': '9d6e3b71-5576-5572-b580-47d3312e58fe', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-target-30104acc-20261005\\composite-composite_target\\reports\\pipeline\\uniprot_idmapping\\9d6e3b71-5576-5572-b580-47d3312e58fe\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_protein', 'run_id': 'd1f97b77-7db0-516b-9de5-7a54226ab968', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-target-30104acc-20261005\\composite-composite_target\\reports\\pipeline\\uniprot_protein\\d1f97b77-7db0-516b-9de5-7a54226ab968\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_target/14a4ef7b-e6f8-5d47-9744-57af24509ca5/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_component/62071a6e-2320-59c8-9963-1a5007c0262d/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_protein_class/93cdfa2f-84c5-5fc6-9f38-4a8945fbbb3d/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_protein_classification/dc88875b-572a-541a-a8ae-5793e0a168a3/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_idmapping/9d6e3b71-5576-5572-b580-47d3312e58fe/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_protein/d1f97b77-7db0-516b-9de5-7a54226ab968/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-b455507d7b591ca042442eca4ce2a699ec795207750f1bec4609826bcca32816.arrow`
- `composite_replay_object`: `replay/inputs/0001-38b6c1dab7ff2e2695b66942b5ed7080b1d577cf30d64c93e76dcfdf4bac4163.arrow`
- `composite_replay_object`: `replay/inputs/0002-70847aa96dee78706a7ddc6c1e51c90298598ac3a86f0f615fa09981aac6a17f.arrow`
- `composite_replay_object`: `replay/inputs/0003-57f7ff50d05f06a18cf4076bcee6272c1e1f4b657d8db84f9d776fa8ffdb6e0c.arrow`
- `composite_replay_object`: `replay/inputs/0004-8043cc4e63842d6861b0585d37074e86962ae94c8697c6d502e36c59428daa76.arrow`
- `composite_replay_object`: `replay/inputs/0005-8d6a260dd2e2daddb4a2a20a7e9b002f8c36d8cd94215da6b907a785c02c2738.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/target-mapping.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/313f5c3a164135e0fec15437a7dfb9107554b52b1ed8b4f9394b33df369699b6.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/991b79a0699c1664defb3de7bafee2c5f8fece08ae180f51d57d4da117e28d18.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0aa1d6805cb585f4cdc86fc9891737957f17d1eb95343e7ce739ce9f34f2e285.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0e9a2bb2a44b2785a84c1431372f8d8102ae53e2f88c1d7fca41c262dcb08588.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55238c84ae3c9c779a9df5f79c92203ce81128971ee9b59dc668d4a9214c14fe.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55daedfd49ca78f657f9ef5f55af44363858d5b9daabcc5620e2961826d1f412.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/8524f7f8f209842424852ba1ab18e389e351630fb1094cd2fb97b1cd35e2ca4b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a14ed324cbbdbf211d8cfc8ccd374db9574800cbf45bd8acafc1473e06db0013.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c5db01bf64b1ab88b56f7793f691cd6de99aa44c1a6258962f2457b4b2c0bae5.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/d7544b853d754d4fa8998e0353b71c67a45f989c5b8360e8acc08ee5b489cac9.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/e814804a67b58c0f956c72b0bfd1b7ba17456095c54d97b74af7683e0f4bdac6.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/506c6231c8aabe3247839bf18f3d34d1ecd1007baba5c75c6051f5bcb1b38f95.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/c8328375aeac2298a20968c2d3878f7cff1bf10bc778ee33a1e36c35eb7b9ddf.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/part-00001-35226660-6118-4068-8d9d-5e5c8f729995-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/part-00001-28f80440-f5e6-4a56-b85f-f58c486f48d9-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/composite_target/51d931dc-5918-59b7-8eef-bc1c6c4a8c34/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-target-30104acc-20261005/composite-composite_target/reports/pipeline/composite_target/51d931dc-5918-59b7-8eef-bc1c6c4a8c34/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
