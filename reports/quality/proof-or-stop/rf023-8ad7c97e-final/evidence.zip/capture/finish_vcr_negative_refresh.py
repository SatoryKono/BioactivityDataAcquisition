"""Adopt independently captured negative cases after all recordings finish."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

import yaml
from dotenv import dotenv_values

from scripts.ops.migrations.active.backfill_vcr_metadata_sidecars import _build_sidecar_payload

root = Path.cwd()
scratch = root / 'reports/quality/rf022-preparation'
capture = scratch / 'vcr-semantic-direct-negative-oct06'
deadline = time.monotonic() + 600
while True:
    summary = json.loads((capture / 'summary.json').read_text())
    if len(summary['rows']) == 11:
        break
    assert time.monotonic() < deadline, 'Recording did not finish; no adoption'
    time.sleep(15)
rows = [r for r in summary['rows'] if r['status'] == 'CAPTURED_PENDING_OWNER_REPLAY']
assert len(rows) == 10
rejected = [r for r in summary['rows'] if r['status'] != 'CAPTURED_PENDING_OWNER_REPLAY']
assert len(rejected) == 1 and rejected[0]['error'] == 'status_changed:429->200'
times = [datetime.fromisoformat(r['interactions'][0]['requested_at']) for r in rows]
assert all((b - a).total_seconds() >= 99.95 for a, b in zip(times, times[1:]))
values = dotenv_values('E:/github/BioactivityDataAcquisition/.env')
secrets = [v.encode() for k, v in values.items() if v and len(v) >= 12 and any(w in k.upper() for w in ('TOKEN', 'SECRET', 'PASSWORD', 'API_KEY', 'PAT'))]
for row in rows:
    relative = Path(row['path']).relative_to('tests/fixtures/vcr')
    data = (capture / 'vcr' / relative).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    assert not any(secret in data for secret in secrets)
    assert row['interactions'][0]['status_code'] == 429
    target = root / row['path']
    target.write_bytes(data)
    metadata = target.with_name(target.stem + '_meta.yaml')
    metadata.write_text(yaml.safe_dump(_build_sidecar_payload(root / 'tests/fixtures/vcr', target, recorded_at='2026-10-06'), sort_keys=False), encoding='utf-8', newline='\n')

# The independent capture which returned 200 belongs to the existing positive
# scenario, not the rejected negative-429 scenario. Match its exact public input.
from urllib.parse import urlsplit, parse_qsl
from vcr.persisters.filesystem import FilesystemPersister as P
from vcr.serializers import yamlserializer as Y
def key(request):
    url = urlsplit(request.uri)
    return request.method, url.scheme, url.netloc, url.path, sorted(parse_qsl(url.query)), request.body or None
positive = []
for candidate in sorted((capture / 'captures').glob('*.yaml')):
    requests, responses = P.load_cassette(str(candidate), Y)
    if len(responses) == 1 and responses[0]['status']['code'] == 200:
        positive.append((candidate, requests, responses))
assert len(positive) == 1
candidate, requests, responses = positive[0]
target = root / 'tests/fixtures/vcr/semanticscholar/rf013_semanticscholar_health_case_12.yaml'
old_requests, old_responses = P.load_cassette(str(target), Y)
assert len(old_requests) == 1 and old_responses[0]['status']['code'] == 200
assert key(old_requests[0]) == key(requests[0])
data = candidate.read_bytes()
assert not any(secret in data for secret in secrets)
target.write_bytes(data)
target.with_name(target.stem + '_meta.yaml').write_text(yaml.safe_dump(_build_sidecar_payload(root / 'tests/fixtures/vcr', target, recorded_at='2026-10-06'), sort_keys=False), encoding='utf-8', newline='\n')
(scratch / 'vcr-semantic-positive-health-rebind-oct06.json').write_text(json.dumps({'capture': candidate.relative_to(root).as_posix(), 'target': target.relative_to(root).as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'matching': 'exact method/URI query/body, original status 200 retained', 'negative_case_13': 'unchanged, not accepted'}, indent=2), encoding='utf-8')

digests = []
fresh = 0
for metadata in (root / 'tests/fixtures/vcr').rglob('*_meta.yaml'):
    payload = yaml.safe_load(metadata.read_text())
    digest = hashlib.sha256((root / payload['cassette_rel_path']).read_bytes()).hexdigest()
    assert digest == payload['cassette_sha256']
    digests.append(digest)
    fresh += str(payload['recorded_at']) == '2026-10-06'
assert len(digests) == 175 and fresh == 112
assert max(Counter(digests).values()) == 1
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONPATH=os.pathsep.join((str(root / 'src'), str(root))), BIOETL_CONFIGS_ROOT=str(root / 'configs'), BIOETL_AI_MEMORY_MODE='off', VCR_RECORD_MODE='none', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', POLARS_MAX_THREADS='2')
commands = [
    [sys.executable, '-m', 'scripts.engineering.qa', 'report-vcr-metadata', '--update'],
    [sys.executable, '-m', 'scripts.engineering.qa', 'report-vcr-metadata', '--check'],
    [sys.executable, '-m', 'ruff', 'check', 'scripts/engineering/qa/report_vcr_metadata_catalog.py'],
    [sys.executable, '-m', 'pytest', '-o', 'addopts=', 'tests/unit/scripts/test_report_vcr_metadata_catalog.py', 'tests/integration/chembl/test_target_extraction_params.py', 'tests/integration/adapters/test_semanticscholar_vcr_rebalance.py', 'tests/architecture/test_vcr_metadata_catalog_drift.py', 'tests/architecture/test_vcr_provider_budget.py', 'tests/architecture/test_vcr_provider_balance.py', 'tests/architecture/test_vcr_metadata_inventory.py', 'tests/architecture/test_vcr_cassette_stem_uniqueness.py', 'tests/architecture/test_vcr_cassette_size_budget.py', 'tests/architecture/test_integration_vcr_policy.py', '-q', '--junitxml=reports/quality/rf022-preparation/vcr-final-additional-oct06.xml'],
]
with (scratch / 'vcr-final-additional-oct06.log').open('w', encoding='utf-8') as log:
    for command in commands:
        log.write('COMMAND ' + json.dumps(command) + '\n'); log.flush()
        subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
(scratch / 'vcr-final-additional-oct06.json').write_text(json.dumps({'fresh': fresh, 'stale': 175-fresh, 'sidecar_digests': '175/175 PASS', 'duplicate_groups': 0, 'negative_429_health_accepted': False, 'minimum_observed_interval_seconds': min((b-a).total_seconds() for a,b in zip(times,times[1:])), 'commands': commands, 'status': 'PASS'}, indent=2), encoding='utf-8')
print('Final additional owner checks PASS; fresh=112, stale=63', flush=True)
