"""Capture remaining existing public read requests without changing inputs or status scenarios."""
from __future__ import annotations
import json,os,time,hashlib,subprocess
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit,parse_qsl
import httpx,vcr
from dotenv import dotenv_values
from vcr.persisters.filesystem import FilesystemPersister as P
from vcr.serializers import yamlserializer as Y
root=Path.cwd();base=root/'reports/quality/rf022-preparation';out=base/'vcr-existing-inputs-oct06';out.mkdir(exist_ok=False);(out/'captures').mkdir()
allowed={'api.crossref.org','api.openalex.org','pubchem.ncbi.nlm.nih.gov','eutils.ncbi.nlm.nih.gov','rest.uniprot.org'}
values=dotenv_values('E:/github/BioactivityDataAcquisition/.env');secrets=[v.encode() for k,v in values.items() if v and len(v)>=12 and any(w in k.upper() for w in ('TOKEN','SECRET','PASSWORD','API_KEY','PAT'))]
cache={};rows=[];last=0.0
def key(r):
 u=urlsplit(r.uri);body=r.body
 if isinstance(body,str):body=body.encode()
 return r.method,u.scheme,u.netloc,u.path,tuple(sorted(parse_qsl(u.query))),body
with httpx.Client(timeout=5.0,follow_redirects=False) as client:
 for rel in json.loads((base/'vcr-remaining-oct06.json').read_text()):
  provider=rel.split('/')[3]
  if provider in ('chembl','multi_provider','semanticscholar'):continue
  req,res=P.load_cassette(str(root/rel),Y);row={'path':rel,'status':'FAIL','interactions':[],'started_at':datetime.now(timezone.utc).isoformat()};rows.append(row);matches=[]
  try:
   for request,response in zip(req,res):
    k=key(request);u=urlsplit(request.uri)
    assert u.scheme=='https' and u.hostname in allowed and request.method in ('GET','POST'),'unapproved_request'
    assert not any(name.lower() in ('api_key','apikey','token','key','access_token') for name,_ in parse_qsl(u.query)),'credential_parameter_requires_owner_recording'
    if k not in cache:
     capture=out/'captures'/f'{len(cache):03d}.yaml';entry={'capture':capture.relative_to(root).as_posix()};cache[k]=entry
     try:
      delay=max(0.0,1.0-(time.monotonic()-last))
      if delay:time.sleep(delay)
      headers={name:value for name,value in dict(request.headers).items() if name.lower() in ('accept','content-type')}
      last=time.monotonic();entry['requested_at']=datetime.now(timezone.utc).isoformat()
      with vcr.VCR(record_mode='all',decode_compressed_response=True).use_cassette(str(capture)):
       result=client.request(request.method,request.uri,content=request.body,headers=headers)
      fresh_req,fresh_res=P.load_cassette(str(capture),Y)
      assert len(fresh_req)==1 and key(fresh_req[0])==k,'request_changed'
      assert not any(secret in capture.read_bytes() for secret in secrets),'secret_scan_failed'
      entry.update(request=fresh_req[0],response=fresh_res[0],status_code=result.status_code,sha256=hashlib.sha256(capture.read_bytes()).hexdigest())
     except Exception as exc:entry['error']=type(exc).__name__+':'+str(exc)
    entry=cache[k]
    assert 'error' not in entry,entry.get('error')
    assert entry['status_code']==response['status']['code'],f"status_changed:{response['status']['code']}->{entry['status_code']}"
    matches.append(entry);row['interactions'].append({n:v for n,v in entry.items() if n not in ('request','response')})
   assert matches,'empty_cassette'
   dest=out/'vcr'/Path(rel).relative_to('tests/fixtures/vcr');dest.parent.mkdir(parents=True,exist_ok=True)
   P.save_cassette(str(dest),{'requests':[m['request'] for m in matches],'responses':[m['response'] for m in matches]},Y)
   dest.write_text(dest.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
   row.update(status='CAPTURED_PENDING_OWNER_REPLAY',sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
  except Exception as exc:row['error']=str(exc)
  row['finished_at']=datetime.now(timezone.utc).isoformat()
  (out/'summary.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'transport_timeout_seconds':5,'minimum_request_interval_seconds':1,'automatic_retries':0,'rows':rows},indent=2),encoding='utf-8')
  print(rel,row['status'],row.get('error',''),flush=True)
