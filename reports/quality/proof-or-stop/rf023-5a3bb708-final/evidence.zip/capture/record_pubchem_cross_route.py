"""Capture actual provider responses for existing parametrized health tests."""
from __future__ import annotations
import os,sys,subprocess,json,shutil,hashlib,time
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit,parse_qsl
from dotenv import dotenv_values
from vcr.persisters.filesystem import FilesystemPersister as P
from vcr.serializers import yamlserializer as Y
root=Path.cwd();out=root/'reports/quality/rf022-preparation/vcr-pubchem-cross-route-oct06';out.mkdir(exist_ok=False)
values=dotenv_values('E:/github/BioactivityDataAcquisition/.env');env=os.environ.copy();env.update({k:v for k,v in values.items() if v is not None})
env.update(PYTHONPATH=os.pathsep.join((str(root/'src'),str(root),str(root/'reports/quality/rf022-preparation'))),BIOETL_CONFIGS_ROOT=str(root/'configs'),BIOETL_AI_MEMORY_MODE='off',BIOETL_GREEN_ACCEPTANCE='0',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',POLARS_MAX_THREADS='2')
secrets=[v.encode() for k,v in values.items() if v and len(v)>=12 and any(w in k.upper() for w in ('TOKEN','SECRET','PASSWORD','API_KEY','PAT'))]
def uri(x):
 u=urlsplit(x);return u.scheme,u.netloc,u.path,sorted(parse_qsl(u.query)),u.fragment
summaries=[]
for provider in ('pubchem',):
 case=out/provider;case.mkdir();originals=case/'originals';originals.mkdir();destdir=case/'vcr'/provider;destdir.mkdir(parents=True)
 files=[root/'tests/fixtures/vcr/pubchem/pubchem_cross_route_contracts.yaml']
 for p in files: shutil.copy2(p,originals/p.name);shutil.copy2(p,destdir/p.name)
 env.update(RF023_PROVIDER=provider,RF023_VCR_PILOT_ROOT=str(case/'vcr'),VCR_RECORD_MODE='all')
 node='tests/integration/adapters/test_pubchem.py'
 nodes=[node+'::'+cls for cls in ('TestPubChemFetchDelegation','TestPubChemStructuralFields','TestPubChemErrorPaths')]
 base=[sys.executable,'-m','pytest','-o','addopts=','-p','pytest_asyncio.plugin','-p','pytest_timeout','-p','no:cacheprovider','-p','rf023_vcr_rebalance_location','-q','--capture=tee-sys']
 receipt={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'provider':provider,'started_at':datetime.now(timezone.utc).isoformat(),'files':[]}
 with (case/'all.log').open('w',encoding='utf-8') as f:r=subprocess.run([*base,*nodes,'--junitxml='+str(case/'all.xml')],env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt['record_exit_code']=r.returncode
 fresh_nodes=[]
 for p in files:
  item={'path':p.relative_to(root).as_posix(),'status':'FAIL'};receipt['files'].append(item);dest=destdir/p.name
  try:
   a,b=P.load_cassette(str(originals/p.name),Y);c,d=P.load_cassette(str(dest),Y)
   assert len(c)>len(a),'no_fresh_response'
   for x,y,rx,ry in zip(a,c,b,d):
    assert x.method==y.method and x.body==y.body and dict(x.headers)==dict(y.headers) and uri(x.uri)==uri(y.uri) and rx==ry,'old_prefix_mismatch'
   assert all(response['status']['code']==200 for response in d[len(a):]),'non_200_response'
   raw=case/'raw';raw.mkdir(exist_ok=True);shutil.copy2(dest,raw/p.name)
   P.save_cassette(str(dest),{'requests':c[len(a):],'responses':d[len(a):]},Y)
   dest.write_text(dest.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
   assert not any(secret in dest.read_bytes() for secret in secrets),'secret_scan_failed'
   item.update(status='CAPTURED',fresh_interactions=len(c)-len(a),sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
   fresh_nodes.extend(nodes)
  except Exception as exc:item['error']=str(exc)
 if fresh_nodes and r.returncode==0:
  env['VCR_RECORD_MODE']='none'
  with (case/'none.log').open('w',encoding='utf-8') as f:q=subprocess.run([*base,*fresh_nodes,'--junitxml='+str(case/'none.xml')],env=env,stdout=f,stderr=subprocess.STDOUT)
  receipt['replay_exit_code']=q.returncode
  if q.returncode==0:
   for item in receipt['files']:
    if item['status']=='CAPTURED':item['status']='PASS'
 receipt['finished_at']=datetime.now(timezone.utc).isoformat();receipt['tracked_tree_clean']=not bool(subprocess.check_output(['git','status','--porcelain'],text=True).strip())
 (case/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');summaries.append(receipt)
 (out/'summary.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
 print(provider,sum(x['status']=='PASS' for x in receipt['files']),'/15',flush=True)
