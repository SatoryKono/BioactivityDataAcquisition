"""Reuse real captured responses only for identical existing request/status inputs."""
from __future__ import annotations
import json,hashlib
from pathlib import Path
from urllib.parse import urlsplit,parse_qsl
from vcr.persisters.filesystem import FilesystemPersister as P
from vcr.serializers import yamlserializer as Y
root=Path.cwd();base=root/'reports/quality/rf022-preparation';out=base/'vcr-exact-input-candidates-oct06';out.mkdir(exist_ok=False)
pool={};sources=[]
def key(request,status):
 u=urlsplit(request.uri);body=request.body
 if isinstance(body,str):body=body.encode()
 return request.method,u.scheme,u.netloc,u.path,tuple(sorted(parse_qsl(u.query))),body,status
def add(path,label):
 req,res=P.load_cassette(str(path),Y)
 for i,(r,s) in enumerate(zip(req,res)):
  pool.setdefault(key(r,s['status']['code']),(r,s,{'file':path.relative_to(root).as_posix(),'interaction':i,'capture_kind':label,'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
 sources.append(path.relative_to(root).as_posix())
add(base/'vcr-uniprot-pilot-oct06/vcr/uniprot/test_uniprot_protein_full_cycle.yaml','fresh_only_record_and_none_pass')
for dirname in ('vcr-e2e-batch-oct06','vcr-uniprot-integration-oct06'):
 for row in json.loads((base/dirname/'summary.json').read_text()):
  if row['status']!='PASS':continue
  node=row['node'];provider='uniprot' if 'uniprot' in node else node.split('test_')[1].split('_')[0]
  name=node.split('::')[-1] if '/e2e/' in node else '.'.join(node.split('::')[1:])
  add(base/dirname/name/'vcr'/provider/(name+'.yaml'),'fresh_only_record_and_none_pass')
for row in json.loads((base/'vcr-rebalance-oct06/summary.json').read_text()):
 for item in row['files']:
  if item['status']=='PASS':add(base/'vcr-rebalance-oct06'/row['provider']/'vcr'/row['provider']/Path(item['path']).name,'fresh_only_record_and_none_pass')
# Keep the observed 429 as negative-test data, never as provider health acceptance.
negative=base/'vcr-semanticscholar-probe-oct06/semanticscholar'
a,b=P.load_cassette(str(negative/'originals/rf013_semanticscholar_health_case_01.yaml'),Y)
c,d=P.load_cassette(str(negative/'vcr/semanticscholar/rf013_semanticscholar_health_case_01.yaml'),Y)
assert len(a)==1 and len(c)==2 and b==d[:1] and d[-1]['status']['code']==429
fresh=out/'actual-semantic-scholar-429.yaml';P.save_cassette(str(fresh),{'requests':c[1:],'responses':d[1:]},Y)
add(fresh,'actual_429_negative_capture_pending_none_replay')
rows=[]
for source in sorted((root/'tests/fixtures/vcr').rglob('*.yaml')):
 if source.stem.endswith('_meta'):continue
 req,res=P.load_cassette(str(source),Y)
 keys=[key(r,s['status']['code']) for r,s in zip(req,res)]
 if not keys or any(k not in pool for k in keys):continue
 destination=out/'vcr'/source.relative_to(root/'tests/fixtures/vcr');destination.parent.mkdir(parents=True,exist_ok=True)
 matched=[pool[k] for k in keys]
 P.save_cassette(str(destination),{'requests':[x[0] for x in matched],'responses':[x[1] for x in matched]},Y)
 destination.write_text(destination.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
 rows.append({'path':source.relative_to(root).as_posix(),'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'interactions':[x[2] for x in matched],'original_status_codes':[x['status']['code'] for x in res],'status':'PENDING_OWNER_REPLAY'})
manifest={'source_commit':'3fb1ba278ec8aaa3e01d646933e783ca45b0e58e','scope':'Exact method/URL/query/body/status matching; reused actual responses with per-interaction provenance; no provider health acceptance inferred','sources':sources,'candidates':rows}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
from collections import Counter
print('candidates',len(rows),dict(Counter(x['path'].split('/')[3] for x in rows)))
