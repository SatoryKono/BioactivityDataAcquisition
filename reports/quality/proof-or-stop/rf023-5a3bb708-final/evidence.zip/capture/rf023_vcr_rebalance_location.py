"""Redirect only VCR fixture storage for the selected provider recording."""
from __future__ import annotations
import os
from pathlib import Path
import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef, request):
    outcome = yield
    if fixturedef.argname == 'vcr_config':
        config = outcome.get_result()
        assert isinstance(config, dict)
        config['cassette_library_dir'] = str(Path(os.environ['RF023_VCR_PILOT_ROOT']) / os.environ['RF023_PROVIDER'])
