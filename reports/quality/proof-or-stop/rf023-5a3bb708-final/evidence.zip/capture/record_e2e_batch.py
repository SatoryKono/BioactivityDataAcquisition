"""Isolated live E2E captures, fresh-only extraction, and mandatory NONE replay."""
from __future__ import annotations
import os, sys, subprocess, json, shutil, time, hashlib
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlsplit, parse_qsl
from dotenv import dotenv_values
from vcr.persisters.filesystem import FilesystemPersister as P
from vcr.serializers import yamlserializer as Y

root=Path.cwd()
out=root/'reports/quality/rf022-preparation/vcr-e2e-batch-oct06'
out.mkdir(exist_ok=False)
values=dotenv_values('E:/github/BioactivityDataAcquisition/.env')
env=os.environ.copy();env.update({k:v for k,v in values.items() if v is not None})
env.update(PYTHONPATH=os.pathsep.join((str(root/'src'),str(root),str(root/'reports/quality/rf022-preparation'))),BIOETL_CONFIGS_ROOT=str(root/'configs'),BIOETL_AI_MEMORY_MODE='off',BIOETL_GREEN_ACCEPTANCE='0',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',POLARS_MAX_THREADS='2')
secrets=[v.encode() for k,v in values.items() if v and len(v)>=12 and any(w in k.upper() for w in ('TOKEN','SECRET','PASSWORD','API_KEY','PAT'))]
cases=[('uniprot','protein','metadata_fields'),('crossref','publication','full_cycle'),('crossref','publication','metadata_fields'),('openalex','publication','full_cycle'),('openalex','publication','metadata_fields'),('pubmed','publication','full_cycle'),('pubchem','compound','full_cycle')]
rows=[]
def canonical_uri(value):
 u=urlsplit(value);return u.scheme,u.netloc,u.path,sorted(parse_qsl(u.query)),u.fragment
for provider,entity,suffix in cases:
 name=f'test_{provider}_{entity}_{suffix}'
 node=f'tests/e2e/test_{provider}_{entity}_e2e.py::{name}'
 source=root/f'tests/fixtures/vcr/{provider}/{name}.yaml'
 case=out/name;case.mkdir();dest=case/f'vcr/{provider}/{source.name}';dest.parent.mkdir(parents=True)
 row={'node':node,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':'running','started_at':datetime.now(timezone.utc).isoformat()};rows.append(row)
 try:
  shutil.copy2(source,dest);shutil.copy2(source,case/'original.yaml')
  env.update(RF023_VCR_NODE=node,RF023_VCR_PILOT_ROOT=str(case/'vcr'))
  for mode in ('all','none'):
   env['VCR_RECORD_MODE']=mode
   command=[sys.executable,'-m','pytest','-o','addopts=','-p','pytest_asyncio.plugin','-p','pytest_timeout','-p','no:cacheprovider','-p','rf023_vcr_batch_location',node,'-q','--capture=tee-sys','--junitxml='+str(case/f'{mode}.xml')]
   start=time.monotonic()
   with (case/f'{mode}.log').open('w',encoding='utf-8') as f:
    result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
   row[mode]={'command':command,'exit_code':result.returncode,'duration_seconds':round(time.monotonic()-start,3)}
   if result.returncode: raise RuntimeError(f'{mode}_failed')
   if mode=='all':
    a,b=P.load_cassette(str(case/'original.yaml'),Y);c,d=P.load_cassette(str(dest),Y)
    assert len(c)>len(a),'no_new_interactions'
    for x,y,rx,ry in zip(a,c,b,d):
     assert x.method==y.method and x.body==y.body and dict(x.headers)==dict(y.headers) and canonical_uri(x.uri)==canonical_uri(y.uri) and rx==ry,'old_prefix_mismatch'
    shutil.copy2(dest,case/'recorded-with-history.yaml')
    P.save_cassette(str(dest),{'requests':c[len(a):],'responses':d[len(a):]},Y)
    dest.write_text(dest.read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
    assert not any(secret in dest.read_bytes() for secret in secrets),'secret_scan_failed'
    row.update(old_interactions=len(a),fresh_interactions=len(c)-len(a),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),secrets_scan='PASS')
  row['status']='PASS'
 except Exception as exc:
  row['status']='FAIL';row['error']=str(exc)
 row['finished_at']=datetime.now(timezone.utc).isoformat()
 row['tracked_tree_clean']=not bool(subprocess.check_output(['git','status','--porcelain'],text=True).strip())
 (case/'receipt.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
 (out/'summary.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
 print(name,row['status'],row.get('error',''),flush=True)
