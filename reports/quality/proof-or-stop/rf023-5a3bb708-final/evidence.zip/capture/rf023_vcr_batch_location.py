"""Redirect only the selected pilot cassette directory to an isolated capture."""
from __future__ import annotations
import os
from pathlib import Path
import pytest
@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    assert item.nodeid==os.environ['RF023_VCR_NODE']
    fixture=item.session._fixturemanager.getfixturedefs('vcr_cassette_dir',item)[-1]
    namespace=fixture.func.__globals__
    original=namespace['build_cassette_dir']
    def isolated(*,fixtures_root,provider_dir):
        return original(fixtures_root=Path(os.environ['RF023_VCR_PILOT_ROOT']),provider_dir=provider_dir)
    namespace['build_cassette_dir']=isolated
