# Pipeline run report: chembl_target

- **run_id:** `285e7642-ac89-538b-8400-660d9162031b`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `fdf606c7-ed0d-5a6b-916e-3473acb36988`
- **provider/entity:** chembl / target
- **started_at:** 2026-10-05T09:35:59.360042+00:00
- **completed_at:** 2026-10-05T09:36:36.319398+00:00
- **duration_seconds:** 36.959356

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 8 | 2 | OK | full | column_filter_mismatch:organism_class=2 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **8** (excluded=2, quarantined=0, skipped=0, dedup=0)

## Top reasons

- `column_filter_mismatch:organism_class` (excluded_by_contract): 2

## IO

- **pipeline_name:** `chembl_target`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Contract summary

- **gold_excluded_by_contract:** `2`
- **reasons:**
  - `{'reason_code': 'column_filter_mismatch:organism_class', 'outcome': 'excluded_by_contract', 'reason_family': 'system', 'count': 2}`
- **rejection_details:**
  - `{'reason_code': 'column_filter_mismatch', 'rule_type': 'column_filters', 'field': 'organism_class', 'operator': 'not_in', 'count': 2}`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `36.959356`
- **records_per_second:** `0.2706`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/chembl_target/285e7642-ac89-538b-8400-660d9162031b/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/chembl_target/285e7642-ac89-538b-8400-660d9162031b/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
