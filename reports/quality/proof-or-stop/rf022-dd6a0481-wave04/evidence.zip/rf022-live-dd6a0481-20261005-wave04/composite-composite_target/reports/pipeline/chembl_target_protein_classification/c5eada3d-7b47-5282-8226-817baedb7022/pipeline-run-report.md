# Pipeline run report: chembl_target_protein_classification

- **run_id:** `c5eada3d-7b47-5282-8226-817baedb7022`
- **status:** failed
- **run_type:** incremental
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `e0d91f97-fe23-58a3-b5fb-0cc50264ecf2`
- **provider/entity:** chembl / target_protein_classification
- **started_at:** 2026-10-05T09:37:08.942294+00:00
- **completed_at:** 2026-10-05T09:37:09.309864+00:00
- **duration_seconds:** 0.36757

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 0 | 0 | 0 | OK | partial | — |
| bronze | 0 | 0 | 0 | OK | partial | — |
| silver | 0 | 0 | 0 | OK | partial | — |
| gold | 0 | 0 | 0 | OK | partial | — |

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `InvalidStateError`
- **error_message:** `blocked_dependency: missing Gold snapshot(s): chembl.target_component, chembl.protein_class. Materialize and validate the upstream tables before retrying; an absent table is not a validated empty result.`
- **failed_stage:** `None`
- **exit_hint:** `Investigate InvalidStateError; check quarantine and gold contract exclusions.`

## IO

- **pipeline_name:** `chembl_target_protein_classification`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `target_id`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `e79be54bb6fa21e9`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `0.36757`
- **records_per_second:** `None`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/chembl_target_protein_classification/c5eada3d-7b47-5282-8226-817baedb7022/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/chembl_target_protein_classification/c5eada3d-7b47-5282-8226-817baedb7022/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
