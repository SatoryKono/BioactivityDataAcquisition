# Pipeline run report: uniprot_idmapping

- **run_id:** `518b79d7-2843-5283-86bb-53cef15b709b`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `4ca80d8c-f33e-5d1e-aa01-338b8b19a05e`
- **provider/entity:** uniprot / idmapping
- **started_at:** 2026-10-05T09:37:09.334889+00:00
- **completed_at:** 2026-10-05T09:37:14.866253+00:00
- **duration_seconds:** 5.531364

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `uniprot_idmapping`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `target_id`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `e79be54bb6fa21e9`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `5.531364`
- **records_per_second:** `1.8079`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/uniprot_idmapping/518b79d7-2843-5283-86bb-53cef15b709b/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/uniprot_idmapping/518b79d7-2843-5283-86bb-53cef15b709b/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
