# Pipeline run report: composite_target

- **run_id:** `bd6eb35f-6b08-5592-99c5-053765072cdd`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `81afa275-5175-54dd-90da-697759f9dbdf`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:35:59.303716+00:00
- **completed_at:** 2026-10-05T09:37:23.149276+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_target', 'run_id': '285e7642-ac89-538b-8400-660d9162031b', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_target\\reports\\pipeline\\chembl_target\\285e7642-ac89-538b-8400-660d9162031b\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_component', 'run_id': 'cdc14e7b-e8ec-5fdf-8b6e-22845159c400', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_target\\reports\\pipeline\\chembl_target_component\\cdc14e7b-e8ec-5fdf-8b6e-22845159c400\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_protein_classification', 'run_id': 'c5eada3d-7b47-5282-8226-817baedb7022', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_target\\reports\\pipeline\\chembl_target_protein_classification\\c5eada3d-7b47-5282-8226-817baedb7022\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_idmapping', 'run_id': '518b79d7-2843-5283-86bb-53cef15b709b', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_target\\reports\\pipeline\\uniprot_idmapping\\518b79d7-2843-5283-86bb-53cef15b709b\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_protein', 'run_id': '8a91a013-0cae-500a-b2d7-7aac3383e83c', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_target\\reports\\pipeline\\uniprot_protein\\8a91a013-0cae-500a-b2d7-7aac3383e83c\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_target/285e7642-ac89-538b-8400-660d9162031b/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_component/cdc14e7b-e8ec-5fdf-8b6e-22845159c400/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_protein_classification/c5eada3d-7b47-5282-8226-817baedb7022/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_idmapping/518b79d7-2843-5283-86bb-53cef15b709b/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_protein/8a91a013-0cae-500a-b2d7-7aac3383e83c/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-38b6c1dab7ff2e2695b66942b5ed7080b1d577cf30d64c93e76dcfdf4bac4163.arrow`
- `composite_replay_object`: `replay/inputs/0001-10def16670adcf5712bcb4382ae0db83bfb482b6e5fe26d8fda184b2a9bee9d5.arrow`
- `composite_replay_object`: `replay/inputs/0002-8d6a260dd2e2daddb4a2a20a7e9b002f8c36d8cd94215da6b907a785c02c2738.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/target-mapping.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/2b02298ee26a168fe66045e92d03e9487571604f8105914c79f472e541581394.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/32ec2038e368c2a71660ed10d3fbd9b563c4e4f1949adc8c071346e9b1fed0d0.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0aa1d6805cb585f4cdc86fc9891737957f17d1eb95343e7ce739ce9f34f2e285.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0e9a2bb2a44b2785a84c1431372f8d8102ae53e2f88c1d7fca41c262dcb08588.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55238c84ae3c9c779a9df5f79c92203ce81128971ee9b59dc668d4a9214c14fe.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55daedfd49ca78f657f9ef5f55af44363858d5b9daabcc5620e2961826d1f412.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/8524f7f8f209842424852ba1ab18e389e351630fb1094cd2fb97b1cd35e2ca4b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a14ed324cbbdbf211d8cfc8ccd374db9574800cbf45bd8acafc1473e06db0013.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c5db01bf64b1ab88b56f7793f691cd6de99aa44c1a6258962f2457b4b2c0bae5.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/d2662c4a96045e78c2bd1097000f9346ff45c5e2d893bd1091d21c9b92b6f7d6.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/663d23529bc9b301634f6d5b591ca372d9e6dfab32a0e11aaecc8e4e8d20fd90.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/89c98468b4954f81c1508ae0929a49dccc7624d3159593c50724373e0280075f.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/a595f4e276f8e468e20b6a9e03e0ed47972442b312c7e04c6c95336b8f395aec.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/part-00001-5d34eddc-b6eb-48c0-a9f8-38e7c00bacc4-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/part-00001-d4d7fa81-9b7c-4435-85a6-f77d6d6acb31-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/composite_target/bd6eb35f-6b08-5592-99c5-053765072cdd/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/composite_target/bd6eb35f-6b08-5592-99c5-053765072cdd/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
