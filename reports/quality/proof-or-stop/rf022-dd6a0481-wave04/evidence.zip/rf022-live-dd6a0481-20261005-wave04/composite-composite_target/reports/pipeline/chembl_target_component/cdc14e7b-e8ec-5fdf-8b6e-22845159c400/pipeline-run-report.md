# Pipeline run report: chembl_target_component

- **run_id:** `cdc14e7b-e8ec-5fdf-8b6e-22845159c400`
- **status:** failed
- **run_type:** incremental
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `ed60c564-7dc4-57d0-8faa-57bc5015f7ad`
- **provider/entity:** chembl / target_component
- **started_at:** 2026-10-05T09:36:37.102868+00:00
- **completed_at:** 2026-10-05T09:37:08.916775+00:00
- **duration_seconds:** 31.813907

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 0 | 0 | 0 | OK | partial | — |
| bronze | 0 | 0 | 0 | OK | partial | — |
| silver | 0 | 0 | 0 | OK | partial | — |
| gold | 0 | 0 | 0 | OK | partial | — |

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `ServiceUnavailableError`
- **error_message:** `Circuit breaker open for chembl. Retry after 2999.999096499989s`
- **failed_stage:** `None`
- **exit_hint:** `Investigate ServiceUnavailableError; check quarantine and gold contract exclusions.`

## IO

- **pipeline_name:** `chembl_target_component`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `component_id`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `8dfd3fc055af3c67`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `31.813907`
- **records_per_second:** `None`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/chembl_target_component/cdc14e7b-e8ec-5fdf-8b6e-22845159c400/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_target/reports/pipeline/chembl_target_component/cdc14e7b-e8ec-5fdf-8b6e-22845159c400/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
