# Pipeline run report: composite_assay

- **run_id:** `45b023f0-b08d-5763-b4da-b086a89b2f9c`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `88d9fc88-222f-591c-b81d-989b00811bfc`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:34:19.356491+00:00
- **completed_at:** 2026-10-05T09:34:54.736514+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_assay failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2999.998991600005s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_assay', 'run_id': 'dc633ee2-20b8-5d52-b120-b2fb64fbccfd', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_assay\\reports\\pipeline\\chembl_assay\\dc633ee2-20b8-5d52-b120-b2fb64fbccfd\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_assay/dc633ee2-20b8-5d52-b120-b2fb64fbccfd/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_assay/reports/pipeline/composite_assay/45b023f0-b08d-5763-b4da-b086a89b2f9c/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_assay/reports/pipeline/composite_assay/45b023f0-b08d-5763-b4da-b086a89b2f9c/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
