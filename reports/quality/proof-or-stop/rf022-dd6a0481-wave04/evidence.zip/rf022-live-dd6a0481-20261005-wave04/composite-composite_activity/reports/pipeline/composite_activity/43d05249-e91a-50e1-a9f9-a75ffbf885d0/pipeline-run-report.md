# Pipeline run report: composite_activity

- **run_id:** `43d05249-e91a-50e1-a9f9-a75ffbf885d0`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `7821785b-6e2a-5b08-9d4e-1d1a69998442`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:33:33.822262+00:00
- **completed_at:** 2026-10-05T09:34:09.563168+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_activity failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2999.999083600007s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_activity', 'run_id': 'b4a81dec-9f90-5964-a215-31e063f0f532', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_activity\\reports\\pipeline\\chembl_activity\\b4a81dec-9f90-5964-a215-31e063f0f532\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_activity/b4a81dec-9f90-5964-a215-31e063f0f532/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_activity/reports/pipeline/composite_activity/43d05249-e91a-50e1-a9f9-a75ffbf885d0/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_activity/reports/pipeline/composite_activity/43d05249-e91a-50e1-a9f9-a75ffbf885d0/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
