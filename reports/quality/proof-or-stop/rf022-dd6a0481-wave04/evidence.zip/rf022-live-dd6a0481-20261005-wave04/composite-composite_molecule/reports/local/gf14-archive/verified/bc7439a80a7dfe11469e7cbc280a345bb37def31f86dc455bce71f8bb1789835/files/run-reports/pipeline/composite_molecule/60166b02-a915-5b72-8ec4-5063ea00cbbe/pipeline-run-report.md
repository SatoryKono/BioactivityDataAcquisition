# Pipeline run report: composite_molecule

- **run_id:** `60166b02-a915-5b72-8ec4-5063ea00cbbe`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `06d6aeed-4bd7-55cf-8ddb-a4f110f9c6e0`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:35:04.029436+00:00
- **completed_at:** 2026-10-05T09:35:38.878079+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **12** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **12** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_molecule', 'run_id': '77a0d383-2226-51f1-9cc1-d2a06e12ba54', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_molecule\\reports\\pipeline\\chembl_molecule\\77a0d383-2226-51f1-9cc1-d2a06e12ba54\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'pubchem_compound', 'run_id': 'b7b06fbc-dfb8-592b-82d8-8f476e1dfb82', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-dd6a0481-20261005-wave04\\composite-composite_molecule\\reports\\pipeline\\pubchem_compound\\b7b06fbc-dfb8-592b-82d8-8f476e1dfb82\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_molecule/77a0d383-2226-51f1-9cc1-d2a06e12ba54/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/pubchem_compound/b7b06fbc-dfb8-592b-82d8-8f476e1dfb82/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-0184e29fd6ea3d54624da49560788597dc2f21827663675bdbbf7e367c448be1.arrow`
- `composite_replay_object`: `replay/inputs/0001-12f94ae30e2f2c9a5ae0fbc7d6108fbfbd4f49f67e44b01b998d2b318687160a.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/a8eb7e6c564945cd867613fe34086f8ec9a766012311ef741b8c311090ce0f9b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/c7a278cdb4bdb6486fdb018c0aa52f6954890e4b6e34a83b7328d9dfeb8f6c7b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/aaa6606425194032495c37d6e6c9ba7670133732517874539f87e1877a8df771.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/b2ce014772ff2275f7d4d191f1f393f549d41ac877709a63af46f79db22db865.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/b6d756354431f53b489c736c85d04a0bd73d004c92f55c2d3aa07eb5ab75e1eb.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c2aa541cd70eadc8264029ba6e1209529a71fa4dc9403bec6f138dc6e5a9f070.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/8160c945b80ed56702ab7631b236e3d16e3599b184a0d004bd806a5b64b71f10.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/2b999ca2105a182c332a1604d5dc814c182e1a51c0553913e7bda6c87a76da1a.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/fa4bbcd8c009759b59c5ddd2f558a208a2a71756d47b95d5c4533fb9662370e1.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/composite_molecule_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/part-00001-a98ed4b6-590b-4d66-8d5c-800482e3e1e4-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/composite_molecule_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/part-00001-29e4b775-1cab-484f-9663-a8b8584b4a5b-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_molecule/reports/pipeline/composite_molecule/60166b02-a915-5b72-8ec4-5063ea00cbbe/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_molecule/reports/pipeline/composite_molecule/60166b02-a915-5b72-8ec4-5063ea00cbbe/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
