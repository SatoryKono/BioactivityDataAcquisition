# Pipeline run report: chembl_molecule

- **run_id:** `77a0d383-2226-51f1-9cc1-d2a06e12ba54`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `f99a9311-5b9b-5db7-b806-5abb52734219`
- **provider/entity:** chembl / molecule
- **started_at:** 2026-10-05T09:35:04.086355+00:00
- **completed_at:** 2026-10-05T09:35:23.207418+00:00
- **duration_seconds:** 19.121063

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `chembl_molecule`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `19.121063`
- **records_per_second:** `0.523`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_molecule/reports/pipeline/chembl_molecule/77a0d383-2226-51f1-9cc1-d2a06e12ba54/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_molecule/reports/pipeline/chembl_molecule/77a0d383-2226-51f1-9cc1-d2a06e12ba54/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
