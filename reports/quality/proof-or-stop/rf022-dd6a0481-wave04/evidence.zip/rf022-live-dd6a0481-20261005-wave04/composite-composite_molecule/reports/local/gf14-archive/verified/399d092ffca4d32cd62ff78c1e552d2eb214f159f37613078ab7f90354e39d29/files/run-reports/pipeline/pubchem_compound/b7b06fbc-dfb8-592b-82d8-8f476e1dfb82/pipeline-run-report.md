# Pipeline run report: pubchem_compound

- **run_id:** `b7b06fbc-dfb8-592b-82d8-8f476e1dfb82`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `664d1322-6bef-5c8b-837a-79f6ccac5318`
- **provider/entity:** pubchem / compound
- **started_at:** 2026-10-05T09:35:23.996114+00:00
- **completed_at:** 2026-10-05T09:35:35.850917+00:00
- **duration_seconds:** 11.854803

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `pubchem_compound`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `inchi_key`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `62a43497f6761ad1`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `11.854803`
- **records_per_second:** `0.8435`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_molecule/reports/pipeline/pubchem_compound/b7b06fbc-dfb8-592b-82d8-8f476e1dfb82/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-dd6a0481-20261005-wave04/composite-composite_molecule/reports/pipeline/pubchem_compound/b7b06fbc-dfb8-592b-82d8-8f476e1dfb82/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
