"""Replay with fail-closed Python network and child-process audit guards."""
from __future__ import annotations

import json
from pathlib import Path
import runpy
import socket
import sys

receipt = Path(sys.argv[1]).resolve()
arguments = sys.argv[2:]
attempts = []
probe = True

def guard(event, args):
    if event == 'socket.connect':
        frame = sys._getframe(1)
        while frame is not None:
            if frame.f_code.co_name == '_fallback_socketpair' and Path(frame.f_code.co_filename).name == 'socket.py':
                return  # Windows asyncio's private local wake-up pair, not an API connection.
            frame = frame.f_back
    if event in {'socket.connect', 'socket.getaddrinfo', 'socket.gethostbyname', 'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.spawn'}:
        if not probe:
            attempts.append(event)
        raise PermissionError('offline acceptance denies network and child process operations')

sys.addaudithook(guard)
try:
    socket.getaddrinfo('offline.invalid', 443)
except PermissionError:
    denied = True
else:
    raise AssertionError('network guard not active')
probe = False
code = 1
try:
    sys.argv = ['bioetl', *arguments]
    runpy.run_module('bioetl', run_name='__main__')
    code = 0
except SystemExit as exc:
    code = exc.code or 0
finally:
    receipt.write_text(json.dumps({'guard':'python_audit_network_and_subprocess', 'self_probe_denied':denied, 'runtime_attempts':attempts,'exit_code':code},indent=2))
sys.exit(code if not attempts else 2)
