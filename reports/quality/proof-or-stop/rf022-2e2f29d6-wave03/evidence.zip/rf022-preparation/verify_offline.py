"""Run one isolated physical replay and retain guarded execution evidence."""
from __future__ import annotations
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[3]
case = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
name = case.name.removeprefix('composite-')
report = next((case/'reports/pipeline'/name).glob('*/pipeline-run-report.json'))
artifact = next(a for a in json.loads(report.read_text())['artifacts'] if a['kind']=='composite_exact_replay')
command = [sys.executable, str(root/'reports/quality/rf022-preparation/offline_guard.py'), str(out/'guard.json'), 'replay-composite','--envelope',str(report.parent/artifact['ref']),'--sha256',artifact['sha256'],'--output',str(out/'replayed')]
with (out/'replay.log').open('w') as log:
    result = subprocess.run(command, cwd=case, stdout=log, stderr=subprocess.STDOUT)
(out/'execution.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command':command,'exit_code':result.returncode},indent=2))
sys.exit(result.returncode)
