"""Read-only real production HTTP acceptance of one isolated live case."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import httpx

case = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
root = Path(__file__).resolve().parents[3]
os.environ.update(BIOETL_DATA_DIR=str(case / 'data'), BIOETL_REPORT_ROOT=str(case / 'reports'), BIOETL_CONFIGS_ROOT=str(case / 'configs'), BIOETL_METRICS_ENABLED='false', BIOETL_OBSERVABILITY__METRICS_SERVER_ENABLED='false')
from bioetl.application.services.run_reports.source_identity import compute_runtime_source_id
from bioetl.application.services.run_reports.paths import write_report_root_source_identity, report_root_marker_path, REPORT_ROOT_MARKER_VALUE
identity = compute_runtime_source_id(runtime_root=root, mounts={'data':case/'data','reports':case/'reports','configs':case/'configs'})
os.environ['BIOETL_RUNTIME_SOURCE_ID'] = identity
write_report_root_source_identity(report_root=case/'reports', source_id=identity)
marker = report_root_marker_path(report_root=case/'reports')
if not marker.exists():
    marker.write_text(REPORT_ROOT_MARKER_VALUE)
from bioetl.interfaces.cli.commands.domains.health import server_integration_deps as cli

def hashes():
    return {str(p.relative_to(case)): hashlib.sha256(p.read_bytes()).hexdigest()
            for base in (case / 'reports', case / 'data/output/control')
            for p in base.rglob('*') if p.is_file()}

async def main():
    before = hashes()
    deps = cli.get_health_server_dependencies(data_root=case / 'data')
    server = cli.build_health_server(host='127.0.0.1', port=0, deps=deps, quarantine_service=None)
    await server.start()
    try:
        port = server._server.sockets[0].getsockname()[1]
        url = f'http://127.0.0.1:{port}'
        async with httpx.AsyncClient(base_url=url, trust_env=False, timeout=30) as client:
            response = await client.get('/ops/observability/pipeline-run-reports', params={'limit':1000})
            response.raise_for_status()
            catalog = response.json()
            expected = {(p.parent.parent.name, p.parent.name) for p in (case/'reports/pipeline').glob('*/*/pipeline-run-report.json')}
            assert expected and expected == {(r['pipeline'],r['run_id']) for r in catalog['items']}
            (out/'catalog.json').write_text(json.dumps(catalog, indent=2))
            for run in catalog['items']:
                response = await client.get('/ops/observability/selected-run-status', params={k:run[k] for k in ('pipeline','run_id','run_type')})
                response.raise_for_status()
                (out/f"{run['pipeline']}-{run['run_id']}.json").write_text(json.dumps(response.json(), indent=2))
        env = {**os.environ, 'BIOETL_REPLAY_ACCEPTANCE_CATALOG':str(out/'catalog.json'), 'BIOETL_REPLAY_ACCEPTANCE_URL':url, 'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
        command = [sys.executable,'-m','pytest','-o','addopts=','-p','pytest_asyncio.plugin','-p','pytest_timeout','-p','no:cacheprovider','tests/integration/test_deployed_replay_readiness.py','-q',f'--junitxml={out / "junit.xml"}']
        with (out/'pytest.log').open('w') as log:
            process = await asyncio.create_subprocess_exec(*command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
            code = await process.wait()
        unchanged = before == hashes()
        (out/'receipt.json').write_text(json.dumps({'command':command,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'exit_code':code,'evidence_unchanged':unchanged,'evidence_hashes':before},indent=2))
        return code if unchanged else 2
    finally:
        await server.stop()
        await cli.close_health_server_resources(deps=deps,quarantine_service=None)

sys.exit(asyncio.run(main()))
