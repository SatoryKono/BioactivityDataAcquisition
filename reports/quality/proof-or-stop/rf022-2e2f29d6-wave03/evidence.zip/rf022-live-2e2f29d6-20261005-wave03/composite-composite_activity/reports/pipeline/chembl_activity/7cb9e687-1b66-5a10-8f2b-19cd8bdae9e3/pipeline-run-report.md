# Pipeline run report: chembl_activity

- **run_id:** `7cb9e687-1b66-5a10-8f2b-19cd8bdae9e3`
- **status:** failed
- **run_type:** incremental
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `cd19a7ae-6603-54d9-82a3-22d565b5da84`
- **provider/entity:** chembl / activity
- **started_at:** 2026-10-05T09:24:59.007752+00:00
- **completed_at:** 2026-10-05T09:25:37.255978+00:00
- **duration_seconds:** 38.248226

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 0 | 0 | 0 | OK | partial | — |
| bronze | 0 | 0 | 0 | OK | partial | — |
| silver | 0 | 0 | 0 | OK | partial | — |
| gold | 0 | 0 | 0 | OK | partial | — |

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `ServiceUnavailableError`
- **error_message:** `Circuit breaker open for chembl. Retry after 2999.9983708999935s`
- **failed_stage:** `None`
- **exit_hint:** `Investigate ServiceUnavailableError; check quarantine and gold contract exclusions.`

## IO

- **pipeline_name:** `chembl_activity`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `38.248226`
- **records_per_second:** `None`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_activity/reports/pipeline/chembl_activity/7cb9e687-1b66-5a10-8f2b-19cd8bdae9e3/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_activity/reports/pipeline/chembl_activity/7cb9e687-1b66-5a10-8f2b-19cd8bdae9e3/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
