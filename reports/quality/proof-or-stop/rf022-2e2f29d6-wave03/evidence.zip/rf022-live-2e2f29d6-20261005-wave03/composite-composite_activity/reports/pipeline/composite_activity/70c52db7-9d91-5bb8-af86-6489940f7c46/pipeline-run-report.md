# Pipeline run report: composite_activity

- **run_id:** `70c52db7-9d91-5bb8-af86-6489940f7c46`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `24f2d8f8-429f-5087-bfd2-8c8442fc17d6`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:24:58.966996+00:00
- **completed_at:** 2026-10-05T09:25:37.310259+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_activity failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2999.9983708999935s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_activity', 'run_id': '7cb9e687-1b66-5a10-8f2b-19cd8bdae9e3', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_activity\\reports\\pipeline\\chembl_activity\\7cb9e687-1b66-5a10-8f2b-19cd8bdae9e3\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_activity/7cb9e687-1b66-5a10-8f2b-19cd8bdae9e3/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_activity/reports/pipeline/composite_activity/70c52db7-9d91-5bb8-af86-6489940f7c46/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_activity/reports/pipeline/composite_activity/70c52db7-9d91-5bb8-af86-6489940f7c46/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
