# Pipeline run report: composite_assay

- **run_id:** `a7d45c49-5871-54ad-b14b-037a33f714e2`
- **status:** failed
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `084166d2-35a7-5f9b-a8c3-8c277550fc8d`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:25:47.531237+00:00
- **completed_at:** 2026-10-05T09:26:25.564887+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RuntimeError`
- **error_message:** `Composite child chembl_assay failed: ServiceUnavailableError: Circuit breaker open for chembl. Retry after 2999.999193299969s`

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_assay', 'run_id': 'b9cf5e67-791c-5bd8-9376-83d3fedbc3a3', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_assay\\reports\\pipeline\\chembl_assay\\b9cf5e67-791c-5bd8-9376-83d3fedbc3a3\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_assay/b9cf5e67-791c-5bd8-9376-83d3fedbc3a3/pipeline-run-report.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_assay/reports/pipeline/composite_assay/a7d45c49-5871-54ad-b14b-037a33f714e2/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_assay/reports/pipeline/composite_assay/a7d45c49-5871-54ad-b14b-037a33f714e2/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
