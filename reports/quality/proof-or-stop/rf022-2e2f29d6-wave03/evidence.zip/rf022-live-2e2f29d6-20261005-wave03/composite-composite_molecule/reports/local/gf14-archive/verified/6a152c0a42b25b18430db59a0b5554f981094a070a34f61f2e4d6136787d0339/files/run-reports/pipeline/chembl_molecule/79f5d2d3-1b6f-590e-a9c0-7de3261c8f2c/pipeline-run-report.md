# Pipeline run report: chembl_molecule

- **run_id:** `79f5d2d3-1b6f-590e-a9c0-7de3261c8f2c`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `35b7a1aa-9f19-5e86-82a6-40efa04ca290`
- **provider/entity:** chembl / molecule
- **started_at:** 2026-10-05T09:26:32.296849+00:00
- **completed_at:** 2026-10-05T09:27:08.349416+00:00
- **duration_seconds:** 36.052567

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `chembl_molecule`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `36.052567`
- **records_per_second:** `0.2774`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_molecule/reports/pipeline/chembl_molecule/79f5d2d3-1b6f-590e-a9c0-7de3261c8f2c/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_molecule/reports/pipeline/chembl_molecule/79f5d2d3-1b6f-590e-a9c0-7de3261c8f2c/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
