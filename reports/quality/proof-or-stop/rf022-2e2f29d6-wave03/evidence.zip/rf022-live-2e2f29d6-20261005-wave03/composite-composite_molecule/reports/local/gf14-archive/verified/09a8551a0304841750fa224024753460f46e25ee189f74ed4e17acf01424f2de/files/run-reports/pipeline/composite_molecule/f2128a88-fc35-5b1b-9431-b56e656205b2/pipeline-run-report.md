# Pipeline run report: composite_molecule

- **run_id:** `f2128a88-fc35-5b1b-9431-b56e656205b2`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `85d4e572-4c8d-5b22-9c2e-fe0768101ed8`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:26:32.251827+00:00
- **completed_at:** 2026-10-05T09:27:21.875165+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **11** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **11** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_molecule', 'run_id': '79f5d2d3-1b6f-590e-a9c0-7de3261c8f2c', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_molecule\\reports\\pipeline\\chembl_molecule\\79f5d2d3-1b6f-590e-a9c0-7de3261c8f2c\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'pubchem_compound', 'run_id': '79bb307c-7204-540e-9e6b-012296101598', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_molecule\\reports\\pipeline\\pubchem_compound\\79bb307c-7204-540e-9e6b-012296101598\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_molecule/79f5d2d3-1b6f-590e-a9c0-7de3261c8f2c/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/pubchem_compound/79bb307c-7204-540e-9e6b-012296101598/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-0184e29fd6ea3d54624da49560788597dc2f21827663675bdbbf7e367c448be1.arrow`
- `composite_replay_object`: `replay/inputs/0001-0eeacbbd86e42f1406ab4da6637f037c054ecc9e6f5abaf56b12f30d0ecc0e95.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/60ab43725e5ad50403fbc926db04feb5b92735766552e278e42bd33abdb0c8e8.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/724eb196e83a5edaf75e3528113f8597532d85589c8d40727cde7c26f3b5b674.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/8f40df84aa8dbfa7136ae500e91ecd55defa74de1f2f331e35a6b6f01a934a5d.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/aaa6606425194032495c37d6e6c9ba7670133732517874539f87e1877a8df771.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/b6d756354431f53b489c736c85d04a0bd73d004c92f55c2d3aa07eb5ab75e1eb.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c2aa541cd70eadc8264029ba6e1209529a71fa4dc9403bec6f138dc6e5a9f070.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/8de60e8a95708bc8a038dc5a0d6c675fc22eaee451e4b58bf675bbf062cdc9b0.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/5734d45dee9fabe2272510ec4d5389df036f7d2de3ce79df0c4df4f509848157.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/8d19368a4da65a7b5e460fde46a3d2d2a0221c68ced3c1809650c65f14155bb0.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/composite_molecule_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/part-00001-88543904-fa71-4811-80cb-9ce9f9256859-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/composite_molecule_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/part-00001-a52867a2-4644-465a-8bdd-dfa2ebe22bae-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_molecule/reports/pipeline/composite_molecule/f2128a88-fc35-5b1b-9431-b56e656205b2/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_molecule/reports/pipeline/composite_molecule/f2128a88-fc35-5b1b-9431-b56e656205b2/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
