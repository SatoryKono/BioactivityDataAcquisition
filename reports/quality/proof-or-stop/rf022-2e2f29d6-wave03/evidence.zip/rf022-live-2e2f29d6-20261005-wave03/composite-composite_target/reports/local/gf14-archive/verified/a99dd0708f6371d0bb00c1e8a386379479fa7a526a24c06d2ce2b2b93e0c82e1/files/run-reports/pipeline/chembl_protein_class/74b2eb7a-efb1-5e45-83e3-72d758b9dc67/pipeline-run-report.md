# Pipeline run report: chembl_protein_class

- **run_id:** `74b2eb7a-efb1-5e45-83e3-72d758b9dc67`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `70f94ef9-17c8-5b7c-b6ea-b79324983db6`
- **provider/entity:** chembl / protein_class
- **started_at:** 2026-10-05T09:28:30.147154+00:00
- **completed_at:** 2026-10-05T09:28:47.222716+00:00
- **duration_seconds:** 17.075562

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 9 | 9 | 0 | OK | full | — |
| bronze | 9 | 9 | 0 | OK | full | — |
| silver | 9 | 9 | 0 | OK | full | — |
| gold | 9 | 9 | 0 | OK | full | — |

## Layers

- bronze: **9**
- silver valid: **9** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **9** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **pipeline_name:** `chembl_protein_class`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `protein_class_id`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `9`
- **filter_id_hash:** `8971ab3455edbd48`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `17.075562`
- **records_per_second:** `0.5271`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/chembl_protein_class/74b2eb7a-efb1-5e45-83e3-72d758b9dc67/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/chembl_protein_class/74b2eb7a-efb1-5e45-83e3-72d758b9dc67/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
