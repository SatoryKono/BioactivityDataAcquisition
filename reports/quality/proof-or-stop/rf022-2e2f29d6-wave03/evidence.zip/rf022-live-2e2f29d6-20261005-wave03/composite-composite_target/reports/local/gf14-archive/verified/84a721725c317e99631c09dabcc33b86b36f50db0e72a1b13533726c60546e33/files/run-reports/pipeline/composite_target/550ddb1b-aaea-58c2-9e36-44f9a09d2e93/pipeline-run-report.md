# Pipeline run report: composite_target

- **run_id:** `550ddb1b-aaea-58c2-9e36-44f9a09d2e93`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `42f81747-a83f-5a61-bd5b-1013b3d2230a`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T09:27:40.607107+00:00
- **completed_at:** 2026-10-05T09:29:07.117703+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_target', 'run_id': 'b63fecd8-993e-5270-a4ef-ef74963e37fb', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_target\\reports\\pipeline\\chembl_target\\b63fecd8-993e-5270-a4ef-ef74963e37fb\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_component', 'run_id': '789bc16f-bce7-527f-9500-2e141b6819e3', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_target\\reports\\pipeline\\chembl_target_component\\789bc16f-bce7-527f-9500-2e141b6819e3\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_protein_class', 'run_id': '74b2eb7a-efb1-5e45-83e3-72d758b9dc67', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_target\\reports\\pipeline\\chembl_protein_class\\74b2eb7a-efb1-5e45-83e3-72d758b9dc67\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_protein_classification', 'run_id': '1c8afb84-c1dd-559a-8c08-7320960be2bc', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_target\\reports\\pipeline\\chembl_target_protein_classification\\1c8afb84-c1dd-559a-8c08-7320960be2bc\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_idmapping', 'run_id': '65d5cead-c8a9-51b2-87e7-164d3ef8762f', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_target\\reports\\pipeline\\uniprot_idmapping\\65d5cead-c8a9-51b2-87e7-164d3ef8762f\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_protein', 'run_id': 'ad33831e-4f84-5093-88f0-d45a615191ed', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-2e2f29d6-20261005-wave03\\composite-composite_target\\reports\\pipeline\\uniprot_protein\\ad33831e-4f84-5093-88f0-d45a615191ed\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_target/b63fecd8-993e-5270-a4ef-ef74963e37fb/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_component/789bc16f-bce7-527f-9500-2e141b6819e3/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_protein_class/74b2eb7a-efb1-5e45-83e3-72d758b9dc67/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_protein_classification/1c8afb84-c1dd-559a-8c08-7320960be2bc/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_idmapping/65d5cead-c8a9-51b2-87e7-164d3ef8762f/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_protein/ad33831e-4f84-5093-88f0-d45a615191ed/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-b455507d7b591ca042442eca4ce2a699ec795207750f1bec4609826bcca32816.arrow`
- `composite_replay_object`: `replay/inputs/0001-38b6c1dab7ff2e2695b66942b5ed7080b1d577cf30d64c93e76dcfdf4bac4163.arrow`
- `composite_replay_object`: `replay/inputs/0002-70847aa96dee78706a7ddc6c1e51c90298598ac3a86f0f615fa09981aac6a17f.arrow`
- `composite_replay_object`: `replay/inputs/0003-57f7ff50d05f06a18cf4076bcee6272c1e1f4b657d8db84f9d776fa8ffdb6e0c.arrow`
- `composite_replay_object`: `replay/inputs/0004-d578a351a4c4857eb21fe45409d4a43fe8555d45e5122e2109e5349d5b23b7ca.arrow`
- `composite_replay_object`: `replay/inputs/0005-8d6a260dd2e2daddb4a2a20a7e9b002f8c36d8cd94215da6b907a785c02c2738.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/target-mapping.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/2f3965095d83e5846008a1c98d7e75a0032f7da6b78433e7859788dc18cf4e4f.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/9522557d8acc1a2e728ccb03059980b00c7a52e4b74a817e11c2e307d6ad5055.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0aa1d6805cb585f4cdc86fc9891737957f17d1eb95343e7ce739ce9f34f2e285.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0e9a2bb2a44b2785a84c1431372f8d8102ae53e2f88c1d7fca41c262dcb08588.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55238c84ae3c9c779a9df5f79c92203ce81128971ee9b59dc668d4a9214c14fe.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55daedfd49ca78f657f9ef5f55af44363858d5b9daabcc5620e2961826d1f412.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/8524f7f8f209842424852ba1ab18e389e351630fb1094cd2fb97b1cd35e2ca4b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a14ed324cbbdbf211d8cfc8ccd374db9574800cbf45bd8acafc1473e06db0013.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/af278af9929f7c414595449773dc6134253f900dc781983e240db54094855e1a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c5db01bf64b1ab88b56f7793f691cd6de99aa44c1a6258962f2457b4b2c0bae5.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/bea570cb613ec608bb3b78c27fb12eb219d1b02cbb417d917342f9e4789bf2f0.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/13d8db27b6cfbdfbd2849786a8f2e9718000a966a19675bc99998bba0554f0cc.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/7967d60b6390a171d72b63b114090b7a341ce33fc2aa54561bff8c336a209132.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/part-00001-28856017-5afb-4cd1-96c5-c4fd52f1a9e7-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/part-00001-7da8583d-e42b-4c66-b2f2-6048d1955bf8-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/composite_target/550ddb1b-aaea-58c2-9e36-44f9a09d2e93/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/composite_target/550ddb1b-aaea-58c2-9e36-44f9a09d2e93/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
