# Pipeline run report: chembl_target

- **run_id:** `b63fecd8-993e-5270-a4ef-ef74963e37fb`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `26bb9565-c265-5e5b-97c5-39d9248526a3`
- **provider/entity:** chembl / target
- **started_at:** 2026-10-05T09:27:40.656769+00:00
- **completed_at:** 2026-10-05T09:28:01.576807+00:00
- **duration_seconds:** 20.920038

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 8 | 2 | OK | full | column_filter_mismatch:organism_class=2 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **8** (excluded=2, quarantined=0, skipped=0, dedup=0)

## Top reasons

- `column_filter_mismatch:organism_class` (excluded_by_contract): 2

## IO

- **pipeline_name:** `chembl_target`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Contract summary

- **gold_excluded_by_contract:** `2`
- **reasons:**
  - `{'reason_code': 'column_filter_mismatch:organism_class', 'outcome': 'excluded_by_contract', 'reason_family': 'system', 'count': 2}`
- **rejection_details:**
  - `{'reason_code': 'column_filter_mismatch', 'rule_type': 'column_filters', 'field': 'organism_class', 'operator': 'not_in', 'count': 2}`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `20.920038`
- **records_per_second:** `0.478`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/chembl_target/b63fecd8-993e-5270-a4ef-ef74963e37fb/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/chembl_target/b63fecd8-993e-5270-a4ef-ef74963e37fb/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
