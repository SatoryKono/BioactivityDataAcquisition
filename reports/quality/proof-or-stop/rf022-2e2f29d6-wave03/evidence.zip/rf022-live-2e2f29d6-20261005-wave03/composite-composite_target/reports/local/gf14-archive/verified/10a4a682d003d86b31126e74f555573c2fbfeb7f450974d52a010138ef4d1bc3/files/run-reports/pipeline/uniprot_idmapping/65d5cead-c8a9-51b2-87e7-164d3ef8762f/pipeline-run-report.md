# Pipeline run report: uniprot_idmapping

- **run_id:** `65d5cead-c8a9-51b2-87e7-164d3ef8762f`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `5b78ddef-1706-5b8c-bdf6-c34396270eee`
- **provider/entity:** uniprot / idmapping
- **started_at:** 2026-10-05T09:28:50.493317+00:00
- **completed_at:** 2026-10-05T09:28:59.062832+00:00
- **duration_seconds:** 8.569515

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `uniprot_idmapping`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `target_id`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `e79be54bb6fa21e9`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `8.569515`
- **records_per_second:** `1.1669`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/uniprot_idmapping/65d5cead-c8a9-51b2-87e7-164d3ef8762f/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-2e2f29d6-20261005-wave03/composite-composite_target/reports/pipeline/uniprot_idmapping/65d5cead-c8a9-51b2-87e7-164d3ef8762f/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
