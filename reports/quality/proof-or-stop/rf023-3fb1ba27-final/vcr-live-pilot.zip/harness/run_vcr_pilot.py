"""Run one isolated live cassette capture or deterministic replay."""
from __future__ import annotations
from pathlib import Path
import os,subprocess,sys,json,shutil,time,hashlib
from datetime import datetime,timezone
from dotenv import dotenv_values
root=Path.cwd();mode=sys.argv[1];assert mode in ('record','replay');out=root/sys.argv[2];assert out.resolve().is_relative_to(root/'reports/quality/rf022-preparation')
source=root/'tests/fixtures/vcr/chembl/test_chembl_assay_full_cycle.yaml';dest=out/'vcr/chembl'/source.name
if mode=='record':
 out.mkdir(exist_ok=False);dest.parent.mkdir(parents=True);shutil.copy2(source,dest);shutil.copy2(source,out/'original.yaml')
else:assert dest.exists()
e=os.environ.copy();e.update({k:v for k,v in dotenv_values('E:/github/BioactivityDataAcquisition/.env').items() if v is not None});e.update(PYTHONPATH=os.pathsep.join((str(root/'src'),str(root),str(root/'reports/quality/rf022-preparation'))),BIOETL_CONFIGS_ROOT=str(root/'configs'),BIOETL_AI_MEMORY_MODE='off',BIOETL_GREEN_ACCEPTANCE='0',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',POLARS_MAX_THREADS='2',VCR_RECORD_MODE='all' if mode=='record' else 'none',RF023_VCR_PILOT_ROOT=str(out/'vcr'))
command=[sys.executable,'-m','pytest','-o','addopts=','-p','pytest_asyncio.plugin','-p','pytest_timeout','-p','no:cacheprovider','-p','rf023_vcr_location','tests/e2e/test_chembl_assay_e2e.py::test_chembl_assay_full_cycle','-q','--capture=tee-sys','--junitxml='+str(out/(mode+'.xml'))]
record={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_at':datetime.now(timezone.utc).isoformat(),'command':command,'record_mode':e['VCR_RECORD_MODE'],'cassette_directory_override_only':True,'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'status':'running'};receipt=out/(mode+'-execution.json');receipt.write_text(json.dumps(record,indent=2),encoding='utf-8');start=time.monotonic()
with (out/(mode+'.log')).open('w',encoding='utf-8') as f:r=subprocess.run(command,env=e,stdout=f,stderr=subprocess.STDOUT)
record.update(exit_code=r.returncode,duration_seconds=round(time.monotonic()-start,3),finished_at=datetime.now(timezone.utc).isoformat(),status='finished',tracked_tree_clean=not bool(subprocess.check_output(['git','status','--porcelain'],text=True).strip()));receipt.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
