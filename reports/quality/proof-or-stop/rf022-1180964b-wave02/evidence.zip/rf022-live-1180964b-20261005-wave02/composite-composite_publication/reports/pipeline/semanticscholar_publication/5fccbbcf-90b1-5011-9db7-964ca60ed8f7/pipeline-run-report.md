# Pipeline run report: semanticscholar_publication

- **run_id:** `5fccbbcf-90b1-5011-9db7-964ca60ed8f7`
- **status:** failed
- **run_type:** incremental
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `40dbd7e3-43e2-5239-9017-45201c77af93`
- **provider/entity:** semanticscholar / publication
- **started_at:** 2026-10-05T08:29:25.936034+00:00
- **completed_at:** 2026-10-05T08:32:47.857926+00:00
- **duration_seconds:** 201.921892

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 0 | 0 | 0 | OK | partial | — |
| bronze | 0 | 0 | 0 | OK | partial | — |
| silver | 0 | 0 | 0 | OK | partial | — |
| gold | 0 | 0 | 0 | OK | partial | — |

## Layers

- bronze: **0**
- silver valid: **0** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## Failure

- **error_type:** `RetryExhaustedError`
- **error_message:** `Exhausted 2 retry attempts for https://api.semanticscholar.org/graph/v1/paper/batch?fields=paperId,externalIds,title,abstract,year,publicationDate,venue,authors,authors.externalIds,authors.hIndex,authors.authorId,citationCount,referenceCount,isOpenAccess,openAccessPdf,tldr,fieldsOfStudy,publicationTypes,journal: Client error '429 ' for url 'https://api.semanticscholar.org/graph/v1/paper/batch?fields=paperId,externalIds,title,abstract,year,publicationDate,venue,authors,authors.externalIds,authors.hIndex,authors.authorId,citationCount,referenceCount,isOpenAccess,openAccessPdf,tldr,fieldsOfStudy,publicationTypes,journal'
For more information check: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/429`
- **failed_stage:** `None`
- **exit_hint:** `Investigate RetryExhaustedError; check quarantine and gold contract exclusions.`

## IO

- **pipeline_name:** `semanticscholar_publication`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `doi`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `66dd8026799bf02e`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `201.921892`
- **records_per_second:** `None`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/semanticscholar_publication/5fccbbcf-90b1-5011-9db7-964ca60ed8f7/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/semanticscholar_publication/5fccbbcf-90b1-5011-9db7-964ca60ed8f7/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
