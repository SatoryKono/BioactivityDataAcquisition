# Pipeline run report: composite_publication

- **run_id:** `ff91dd13-813d-53c3-a075-75cabef665fc`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `a83b6216-5535-58c6-b357-fa879c27b04f`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T08:29:05.003837+00:00
- **completed_at:** 2026-10-05T08:32:50.113683+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_publication', 'run_id': '2f8c022a-883f-5b13-931d-d5be54b07d13', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_publication\\reports\\pipeline\\chembl_publication\\2f8c022a-883f-5b13-931d-d5be54b07d13\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'pubmed_publication', 'run_id': 'efcd01a3-a10a-51a0-8bab-debd34d89846', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_publication\\reports\\pipeline\\pubmed_publication\\efcd01a3-a10a-51a0-8bab-debd34d89846\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'openalex_publication', 'run_id': '16a201ee-78fe-514e-86e1-507a2a0c05bf', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_publication\\reports\\pipeline\\openalex_publication\\16a201ee-78fe-514e-86e1-507a2a0c05bf\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'crossref_publication', 'run_id': '42cdc7e0-37c1-55bf-81a8-188e977fbe22', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_publication\\reports\\pipeline\\crossref_publication\\42cdc7e0-37c1-55bf-81a8-188e977fbe22\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'semanticscholar_publication', 'run_id': '5fccbbcf-90b1-5011-9db7-964ca60ed8f7', 'status': 'failed', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_publication\\reports\\pipeline\\semanticscholar_publication\\5fccbbcf-90b1-5011-9db7-964ca60ed8f7\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_publication/2f8c022a-883f-5b13-931d-d5be54b07d13/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/pubmed_publication/efcd01a3-a10a-51a0-8bab-debd34d89846/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/openalex_publication/16a201ee-78fe-514e-86e1-507a2a0c05bf/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/crossref_publication/42cdc7e0-37c1-55bf-81a8-188e977fbe22/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/semanticscholar_publication/5fccbbcf-90b1-5011-9db7-964ca60ed8f7/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-5016525a7f292648404334672fe0a3802c00af66bef750b1e3b443769c3034ba.arrow`
- `composite_replay_object`: `replay/inputs/0001-26cdf50d31e2fa0f515dc8f847db4f9864f344b7415f2e6f1a7cfa77aefc096c.arrow`
- `composite_replay_object`: `replay/inputs/0002-ffe0c7be2410ec4457822465ec3c8a9e23f8c4df2079553cd82af6f7d8696e5d.arrow`
- `composite_replay_object`: `replay/inputs/0003-ea254684429c75f5b447e655c9c09871c7346b68931ab3b34fc48bd876fc9d94.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/21473a6fda6112d67f8e0b6e883c20aa54c2912de2f9004dcf91ac96fb4a5847.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/a9d68a994a4a4844fb04aafea4c0e7de0dbeb369e3dfe9f21d44d9c6fba3a7e1.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/22ab503aa1ef79ee3440eaa81ba68e53fc73b461c5b4b3d59b7e3fcc8da02d5c.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/33258e286fe961de5b416452defbed4d5323db441a457562711cb7104972fa61.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/3f52cbb021cbf7926156a951b544e05c4e87fc7448ead16b2e97bc33cc7861d2.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/6e3b4a1781b95994ce88653f723f572fdbebb26ac6ee0858e0f964fd0ac9bcdd.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/7f8844a6a14a8eedd36c24f9b06d0d96e0d41cf474333fc9c10b094420284301.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/b7e169384a8885f0c669164700bcd2b759d248ed465f2f49634d5cb0f3517865.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/d681c6f3c2c9f8f0838f9f67b9ab776ad8c1066967e224bca7501f817f8fd10b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/9a2e1fa0682178bf78780f1df8040d726ed0b5a0ac0520fbc8ac60e56f0f38d4.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/9fc3257b5919c8c430b9092766eae41dbdb2f384222235435f2531cbf39da1c1.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/f379736dd6bb78ee497e32ca0003bb1c9a426c15f74e3aea84a37210ca97ca60.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/publication/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/publication/composite_publication_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/publication/part-00001-7d596ee3-5f43-46b4-8753-c72c1edc1e71-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/publication/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/publication/composite_publication_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/publication/part-00001-e412619f-f265-4e30-85e9-86d7cebd73b0-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/composite_publication/ff91dd13-813d-53c3-a075-75cabef665fc/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/composite_publication/ff91dd13-813d-53c3-a075-75cabef665fc/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
