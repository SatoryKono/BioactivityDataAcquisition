# Pipeline run report: crossref_publication

- **run_id:** `42cdc7e0-37c1-55bf-81a8-188e977fbe22`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `eb1fdb61-bb3e-5b41-8da3-80eb03a8fd1b`
- **provider/entity:** crossref / publication
- **started_at:** 2026-10-05T08:29:23.681054+00:00
- **completed_at:** 2026-10-05T08:29:32.747708+00:00
- **duration_seconds:** 9.066654

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `crossref_publication`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `doi`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `66dd8026799bf02e`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `9.066654`
- **records_per_second:** `1.1029`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/crossref_publication/42cdc7e0-37c1-55bf-81a8-188e977fbe22/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/crossref_publication/42cdc7e0-37c1-55bf-81a8-188e977fbe22/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
