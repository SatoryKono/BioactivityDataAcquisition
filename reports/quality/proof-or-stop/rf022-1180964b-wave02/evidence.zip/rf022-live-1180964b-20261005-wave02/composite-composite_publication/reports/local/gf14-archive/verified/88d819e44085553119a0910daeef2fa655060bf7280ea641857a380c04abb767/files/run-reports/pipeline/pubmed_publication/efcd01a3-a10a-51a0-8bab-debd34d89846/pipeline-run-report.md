# Pipeline run report: pubmed_publication

- **run_id:** `efcd01a3-a10a-51a0-8bab-debd34d89846`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `c6ce8354-0cb7-52bb-ae88-e90c79d39f09`
- **provider/entity:** pubmed / publication
- **started_at:** 2026-10-05T08:29:25.187395+00:00
- **completed_at:** 2026-10-05T08:29:30.488897+00:00
- **duration_seconds:** 5.301502

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `pubmed_publication`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `pmid`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `5528b944482d72f3`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `5.301502`
- **records_per_second:** `1.8863`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/pubmed_publication/efcd01a3-a10a-51a0-8bab-debd34d89846/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_publication/reports/pipeline/pubmed_publication/efcd01a3-a10a-51a0-8bab-debd34d89846/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
