# Pipeline run report: composite_activity

- **run_id:** `833c7f17-29fb-5683-ab99-6c99a38bd0ea`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `49a4dcbf-0b2e-509e-b3ca-251a8130b42d`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T08:24:59.084726+00:00
- **completed_at:** 2026-10-05T08:25:40.177128+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **9** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **9** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_activity', 'run_id': '016426ea-76f0-511b-af99-ad8bf85399d7', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_activity\\reports\\pipeline\\chembl_activity\\016426ea-76f0-511b-af99-ad8bf85399d7\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_compound_record', 'run_id': 'f652f438-bdf6-55fc-a9a8-3e29ac69b159', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_activity\\reports\\pipeline\\chembl_compound_record\\f652f438-bdf6-55fc-a9a8-3e29ac69b159\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_activity/016426ea-76f0-511b-af99-ad8bf85399d7/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_compound_record/f652f438-bdf6-55fc-a9a8-3e29ac69b159/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-198d14d0e97f3510620ff10ecc035bfb591c8a9d1740b63f2f0c802cea858d0d.arrow`
- `composite_replay_object`: `replay/inputs/0001-d764a622e5d0bf35d755b3801cf7a685fe3cfd9485cbc455476abefa80931f06.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/aa24157f8364ba5a7ad0350bdb70edefabb96c444267fddfc821ef2ec4647c02.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/b9962b8ddb3a34fa11e050bfdd0149c490335bac4a7e1ef62b8c325908c949e1.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/16c4acdbbc07c9ef77ba351f8602c9c875fd0ccff3c957c1f11c9311d4c5b1f8.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/397bd26760388fd70a0271c07bca46f12b1a03d4d69c778f1ef0182a523ee38d.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/6a995326908f156d4152cd4cc921084e9e869a3dca4f7e6fea5ac031fae89cb5.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/8f34399080563b1fdb7c1ab63291fe54e27e5b1f06b56b3e7ac48077455a759e.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/91f99e2fd35bee7c00827e72757d7db552ba9b86aa44e5754454d2f1d65d7e5a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/34d006f839aad3daec31d4252111e0546bd5b2881aa6dfc77fe8629320f02eb7.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/540601c6ecc1d019ed750f23bc4505b1294dbf924d1eaebb0089f7c019218452.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/activity/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/activity/composite_activity_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/activity/part-00001-ded472a8-7c42-4f92-8db5-01fd09118e75-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/activity/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/activity/composite_activity_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/activity/part-00001-fb8ffb27-716f-4cb2-92b3-e59a660f6ff0-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_activity/reports/pipeline/composite_activity/833c7f17-29fb-5683-ab99-6c99a38bd0ea/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_activity/reports/pipeline/composite_activity/833c7f17-29fb-5683-ab99-6c99a38bd0ea/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
