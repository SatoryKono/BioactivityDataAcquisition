# Pipeline run report: chembl_compound_record

- **run_id:** `f652f438-bdf6-55fc-a9a8-3e29ac69b159`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `962a77fd-1e8f-5564-8c75-41439199d789`
- **provider/entity:** chembl / compound_record
- **started_at:** 2026-10-05T08:25:18.415861+00:00
- **completed_at:** 2026-10-05T08:25:37.142274+00:00
- **duration_seconds:** 18.726413

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 8 | 8 | 0 | OK | full | — |
| bronze | 8 | 8 | 0 | OK | full | — |
| silver | 8 | 8 | 0 | OK | full | — |
| gold | 8 | 0 | 8 | OK | full | OPERATOR_SKIPPED=8 |

## Layers

- bronze: **8**
- silver valid: **8** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=8, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 8

## IO

- **pipeline_name:** `chembl_compound_record`
- **run_type:** `incremental`
- **limit:** `9`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **multi_filter_id_counts:** `{'molecule_id': 8, 'publication_id': 4}`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `18.726413`
- **records_per_second:** `0.4272`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_activity/reports/pipeline/chembl_compound_record/f652f438-bdf6-55fc-a9a8-3e29ac69b159/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_activity/reports/pipeline/chembl_compound_record/f652f438-bdf6-55fc-a9a8-3e29ac69b159/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
