# Pipeline run report: chembl_activity

- **run_id:** `016426ea-76f0-511b-af99-ad8bf85399d7`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `4150ffd5-6c6d-559b-887c-f6c04291a991`
- **provider/entity:** chembl / activity
- **started_at:** 2026-10-05T08:24:59.148407+00:00
- **completed_at:** 2026-10-05T08:25:17.552678+00:00
- **duration_seconds:** 18.404271

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 9 | 1 | OK | full | required_field_missing=1 |
| gold | 9 | 0 | 9 | OK | full | OPERATOR_SKIPPED=9 |

## Layers

- bronze: **10**
- silver valid: **9** (filtered=1, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=9, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 9
- `required_field_missing` (filtered_out): 1

## IO

- **pipeline_name:** `chembl_activity`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## DQ summary

- **records_filtered_out:** `1`
- **records_quarantined:** `0`
- **reasons:**

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `18.404271`
- **records_per_second:** `0.5434`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_activity/reports/pipeline/chembl_activity/016426ea-76f0-511b-af99-ad8bf85399d7/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_activity/reports/pipeline/chembl_activity/016426ea-76f0-511b-af99-ad8bf85399d7/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
