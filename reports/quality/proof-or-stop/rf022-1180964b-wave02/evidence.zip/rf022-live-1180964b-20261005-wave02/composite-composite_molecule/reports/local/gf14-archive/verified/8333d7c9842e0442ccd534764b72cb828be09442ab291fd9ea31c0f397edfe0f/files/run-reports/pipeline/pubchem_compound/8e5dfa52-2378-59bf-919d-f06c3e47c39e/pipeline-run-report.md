# Pipeline run report: pubchem_compound

- **run_id:** `8e5dfa52-2378-59bf-919d-f06c3e47c39e`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `bc049d5c-d254-5d00-9532-a1c5c4e1357d`
- **provider/entity:** pubchem / compound
- **started_at:** 2026-10-05T08:27:05.399040+00:00
- **completed_at:** 2026-10-05T08:27:15.149315+00:00
- **duration_seconds:** 9.750275

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 0 | 10 | OK | full | OPERATOR_SKIPPED=10 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=10, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 10

## IO

- **pipeline_name:** `pubchem_compound`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `inchi_key`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `62a43497f6761ad1`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `9.750275`
- **records_per_second:** `1.0256`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_molecule/reports/pipeline/pubchem_compound/8e5dfa52-2378-59bf-919d-f06c3e47c39e/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_molecule/reports/pipeline/pubchem_compound/8e5dfa52-2378-59bf-919d-f06c3e47c39e/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
