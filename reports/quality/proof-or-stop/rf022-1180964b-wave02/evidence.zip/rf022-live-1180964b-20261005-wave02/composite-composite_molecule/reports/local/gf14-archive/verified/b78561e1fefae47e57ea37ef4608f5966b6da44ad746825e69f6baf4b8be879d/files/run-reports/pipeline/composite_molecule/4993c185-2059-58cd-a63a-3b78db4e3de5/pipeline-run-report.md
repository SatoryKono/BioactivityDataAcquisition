# Pipeline run report: composite_molecule

- **run_id:** `4993c185-2059-58cd-a63a-3b78db4e3de5`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `cf409c46-43c6-549e-9762-394091da0d7e`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T08:26:45.877180+00:00
- **completed_at:** 2026-10-05T08:27:17.870656+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **12** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **12** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_molecule', 'run_id': 'b2766f49-0eb5-507a-98db-b59b11d61359', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_molecule\\reports\\pipeline\\chembl_molecule\\b2766f49-0eb5-507a-98db-b59b11d61359\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'pubchem_compound', 'run_id': '8e5dfa52-2378-59bf-919d-f06c3e47c39e', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_molecule\\reports\\pipeline\\pubchem_compound\\8e5dfa52-2378-59bf-919d-f06c3e47c39e\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_molecule/b2766f49-0eb5-507a-98db-b59b11d61359/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/pubchem_compound/8e5dfa52-2378-59bf-919d-f06c3e47c39e/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-0184e29fd6ea3d54624da49560788597dc2f21827663675bdbbf7e367c448be1.arrow`
- `composite_replay_object`: `replay/inputs/0001-371ab7b27387266288999342c4eec7bdda9e11b099b3257d69792c8b26b5b859.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/a09802e3089d5b466f3d299254b3f32a746d36a9d4ed52cb4d7ae25bcd01e4d3.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/b68a3328bc531f7e3ab8f0afdb3b7012c4528960d5ad84c0268cbbe34d5fcd08.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/09e462185f388d49064ee1c975580b4bce19727bb74f92f7ac9cf19a2f7dfb96.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/aaa6606425194032495c37d6e6c9ba7670133732517874539f87e1877a8df771.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/b6d756354431f53b489c736c85d04a0bd73d004c92f55c2d3aa07eb5ab75e1eb.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c2aa541cd70eadc8264029ba6e1209529a71fa4dc9403bec6f138dc6e5a9f070.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/a96c6785352e568ff63d1a81ccec660633e366a9f5406c7f4ca58cdcaecf9a8e.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/3139475f7dc16dbda9e5fe0a0424b7c1d43a099c13aa24db31bde77d86776a2b.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/bb8b07eb2891c64e5e8bbf12cc7a03d118a0cb1c6a552e730800818743aeece8.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/composite_molecule_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/molecule/part-00001-00e2e65d-55cb-4e54-82e1-f547f40b2614-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/composite_molecule_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/molecule/part-00001-9accea0a-768e-46a5-ad96-cd590ec4ecf3-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_molecule/reports/pipeline/composite_molecule/4993c185-2059-58cd-a63a-3b78db4e3de5/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_molecule/reports/pipeline/composite_molecule/4993c185-2059-58cd-a63a-3b78db4e3de5/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
