# Pipeline run report: chembl_target_component

- **run_id:** `9a1f8c83-cfe4-59f1-89c5-68766a093f55`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `a3cefa56-5c11-5bf4-9355-85b24e2fefdd`
- **provider/entity:** chembl / target_component
- **started_at:** 2026-10-05T08:27:51.640233+00:00
- **completed_at:** 2026-10-05T08:28:08.675743+00:00
- **duration_seconds:** 17.03551

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 10 | 0 | OK | full | — |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **pipeline_name:** `chembl_target_component`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `component_id`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `8dfd3fc055af3c67`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `17.03551`
- **records_per_second:** `0.587`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_target_component/9a1f8c83-cfe4-59f1-89c5-68766a093f55/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_target_component/9a1f8c83-cfe4-59f1-89c5-68766a093f55/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
