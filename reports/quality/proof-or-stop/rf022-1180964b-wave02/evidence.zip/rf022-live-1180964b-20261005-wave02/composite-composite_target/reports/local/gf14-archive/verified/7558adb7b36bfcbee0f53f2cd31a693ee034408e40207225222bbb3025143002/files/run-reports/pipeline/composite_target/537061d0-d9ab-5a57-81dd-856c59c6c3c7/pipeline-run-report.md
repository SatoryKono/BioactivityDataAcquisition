# Pipeline run report: composite_target

- **run_id:** `537061d0-d9ab-5a57-81dd-856c59c6c3c7`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `e443c556-a63c-5dd1-9732-ebd8b6af3c4b`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T08:27:29.853959+00:00
- **completed_at:** 2026-10-05T08:28:50.600526+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_target', 'run_id': '4a87048f-b9bb-5f9c-9283-f71506bb0195', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_target\\reports\\pipeline\\chembl_target\\4a87048f-b9bb-5f9c-9283-f71506bb0195\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_component', 'run_id': '9a1f8c83-cfe4-59f1-89c5-68766a093f55', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_target\\reports\\pipeline\\chembl_target_component\\9a1f8c83-cfe4-59f1-89c5-68766a093f55\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_protein_class', 'run_id': '205b4d00-20ce-5ae4-9cb9-83c0f93f782e', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_target\\reports\\pipeline\\chembl_protein_class\\205b4d00-20ce-5ae4-9cb9-83c0f93f782e\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_target_protein_classification', 'run_id': '02aee0e9-ba48-5936-9d93-212e78522b4f', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_target\\reports\\pipeline\\chembl_target_protein_classification\\02aee0e9-ba48-5936-9d93-212e78522b4f\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_idmapping', 'run_id': '9281299e-a4f3-5bdb-9fdf-288bb6582c9f', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_target\\reports\\pipeline\\uniprot_idmapping\\9281299e-a4f3-5bdb-9fdf-288bb6582c9f\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'uniprot_protein', 'run_id': '8adbd49b-34aa-5538-946b-2853330a6e61', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_target\\reports\\pipeline\\uniprot_protein\\8adbd49b-34aa-5538-946b-2853330a6e61\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_target/4a87048f-b9bb-5f9c-9283-f71506bb0195/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_component/9a1f8c83-cfe4-59f1-89c5-68766a093f55/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_protein_class/205b4d00-20ce-5ae4-9cb9-83c0f93f782e/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_target_protein_classification/02aee0e9-ba48-5936-9d93-212e78522b4f/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_idmapping/9281299e-a4f3-5bdb-9fdf-288bb6582c9f/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/uniprot_protein/8adbd49b-34aa-5538-946b-2853330a6e61/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-b455507d7b591ca042442eca4ce2a699ec795207750f1bec4609826bcca32816.arrow`
- `composite_replay_object`: `replay/inputs/0001-38b6c1dab7ff2e2695b66942b5ed7080b1d577cf30d64c93e76dcfdf4bac4163.arrow`
- `composite_replay_object`: `replay/inputs/0002-70847aa96dee78706a7ddc6c1e51c90298598ac3a86f0f615fa09981aac6a17f.arrow`
- `composite_replay_object`: `replay/inputs/0003-57f7ff50d05f06a18cf4076bcee6272c1e1f4b657d8db84f9d776fa8ffdb6e0c.arrow`
- `composite_replay_object`: `replay/inputs/0004-31c5706470f2c5256d4c4b4667361756a3005a3337dbf9898988b959d45d1469.arrow`
- `composite_replay_object`: `replay/inputs/0005-8d6a260dd2e2daddb4a2a20a7e9b002f8c36d8cd94215da6b907a785c02c2738.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/4554fb13936b70a479d064dff42964f57c53035f606ab89a7dffc7bb65384bfe.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/4dfe0730ac25817c920ea23c7dfe9332cc355b485142f498111a4eba9cf6aae3.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0aa1d6805cb585f4cdc86fc9891737957f17d1eb95343e7ce739ce9f34f2e285.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/0e9a2bb2a44b2785a84c1431372f8d8102ae53e2f88c1d7fca41c262dcb08588.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55238c84ae3c9c779a9df5f79c92203ce81128971ee9b59dc668d4a9214c14fe.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/55daedfd49ca78f657f9ef5f55af44363858d5b9daabcc5620e2961826d1f412.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/6dddfa84c0c2bfe2e073561505c8666deb87ec26761aa6b6418f14afd1ac8498.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/8524f7f8f209842424852ba1ab18e389e351630fb1094cd2fb97b1cd35e2ca4b.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a14ed324cbbdbf211d8cfc8ccd374db9574800cbf45bd8acafc1473e06db0013.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/c5db01bf64b1ab88b56f7793f691cd6de99aa44c1a6258962f2457b4b2c0bae5.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/5ad4d099d2a175c501d63e6f0285c0af27067a346140cacfd1726e8e73bece79.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/239ee55ecb78bf3ef94e66b9bd0ed051372868f15d915b0eef066fe733b52e2d.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/bec2297a9955d96e36ff91b819ab23cd9ab3e96d50a64712acacf0d9706a23d4.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/target/part-00001-2e08fcf2-8005-4c02-aeb4-e584e9c14cdf-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/composite_target_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/target/part-00001-91c801ea-4925-448f-93ee-430efca1e4c6-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/composite_target/537061d0-d9ab-5a57-81dd-856c59c6c3c7/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/composite_target/537061d0-d9ab-5a57-81dd-856c59c6c3c7/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
