# Pipeline run report: chembl_target

- **run_id:** `4a87048f-b9bb-5f9c-9283-f71506bb0195`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `184a7df6-235a-5b46-8658-11292304c6dd`
- **provider/entity:** chembl / target
- **started_at:** 2026-10-05T08:27:29.917488+00:00
- **completed_at:** 2026-10-05T08:27:50.751658+00:00
- **duration_seconds:** 20.83417

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 10 | 10 | 0 | OK | full | — |
| bronze | 10 | 10 | 0 | OK | full | — |
| silver | 10 | 10 | 0 | OK | full | — |
| gold | 10 | 8 | 2 | OK | full | column_filter_mismatch:organism_class=2 |

## Layers

- bronze: **10**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **8** (excluded=2, quarantined=0, skipped=0, dedup=0)

## Top reasons

- `column_filter_mismatch:organism_class` (excluded_by_contract): 2

## IO

- **pipeline_name:** `chembl_target`
- **run_type:** `incremental`
- **limit:** `10`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`

## Contract summary

- **gold_excluded_by_contract:** `2`
- **reasons:**
  - `{'reason_code': 'column_filter_mismatch:organism_class', 'outcome': 'excluded_by_contract', 'reason_family': 'system', 'count': 2}`
- **rejection_details:**
  - `{'reason_code': 'column_filter_mismatch', 'rule_type': 'column_filters', 'field': 'organism_class', 'operator': 'not_in', 'count': 2}`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `20.83417`
- **records_per_second:** `0.48`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_target/4a87048f-b9bb-5f9c-9283-f71506bb0195/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_target/4a87048f-b9bb-5f9c-9283-f71506bb0195/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
