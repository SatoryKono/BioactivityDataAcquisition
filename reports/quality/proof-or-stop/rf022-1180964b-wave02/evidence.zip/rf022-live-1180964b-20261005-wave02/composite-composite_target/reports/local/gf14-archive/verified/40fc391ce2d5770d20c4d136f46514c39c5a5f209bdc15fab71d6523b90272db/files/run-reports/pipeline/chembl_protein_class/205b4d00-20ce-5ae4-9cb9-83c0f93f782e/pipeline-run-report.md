# Pipeline run report: chembl_protein_class

- **run_id:** `205b4d00-20ce-5ae4-9cb9-83c0f93f782e`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `32828a8c-971d-5a76-b79d-da9c2d7b1d6e`
- **provider/entity:** chembl / protein_class
- **started_at:** 2026-10-05T08:28:09.459312+00:00
- **completed_at:** 2026-10-05T08:28:27.076593+00:00
- **duration_seconds:** 17.617281

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 9 | 9 | 0 | OK | full | — |
| bronze | 9 | 9 | 0 | OK | full | — |
| silver | 9 | 9 | 0 | OK | full | — |
| gold | 9 | 9 | 0 | OK | full | — |

## Layers

- bronze: **9**
- silver valid: **9** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **9** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **pipeline_name:** `chembl_protein_class`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `protein_class_id`
- **skip_gold:** `False`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `9`
- **filter_id_hash:** `8971ab3455edbd48`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `17.617281`
- **records_per_second:** `0.5109`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_protein_class/205b4d00-20ce-5ae4-9cb9-83c0f93f782e/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_protein_class/205b4d00-20ce-5ae4-9cb9-83c0f93f782e/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
