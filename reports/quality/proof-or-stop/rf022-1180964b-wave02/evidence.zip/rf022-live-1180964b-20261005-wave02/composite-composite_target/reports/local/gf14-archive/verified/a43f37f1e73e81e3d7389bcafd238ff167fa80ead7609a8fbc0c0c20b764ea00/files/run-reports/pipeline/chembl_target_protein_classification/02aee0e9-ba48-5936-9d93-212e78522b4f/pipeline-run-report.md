# Pipeline run report: chembl_target_protein_classification

- **run_id:** `02aee0e9-ba48-5936-9d93-212e78522b4f`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `245100cb-bd60-58f9-bd11-72784919be1d`
- **provider/entity:** chembl / target_protein_classification
- **started_at:** 2026-10-05T08:28:27.873617+00:00
- **completed_at:** 2026-10-05T08:28:29.636400+00:00
- **duration_seconds:** 1.762783

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 8 | 8 | 0 | OK | full | — |
| bronze | 8 | 8 | 0 | OK | full | — |
| silver | 8 | 8 | 0 | OK | full | — |
| gold | 8 | 0 | 8 | OK | full | OPERATOR_SKIPPED=8 |

## Layers

- bronze: **8**
- silver valid: **8** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=8, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 8

## IO

- **pipeline_name:** `chembl_target_protein_classification`
- **run_type:** `incremental`
- **limit:** `10`
- **filter_column:** `target_id`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `10`
- **filter_id_hash:** `e79be54bb6fa21e9`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `1.762783`
- **records_per_second:** `4.5383`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_target_protein_classification/02aee0e9-ba48-5936-9d93-212e78522b4f/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_target/reports/pipeline/chembl_target_protein_classification/02aee0e9-ba48-5936-9d93-212e78522b4f/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
