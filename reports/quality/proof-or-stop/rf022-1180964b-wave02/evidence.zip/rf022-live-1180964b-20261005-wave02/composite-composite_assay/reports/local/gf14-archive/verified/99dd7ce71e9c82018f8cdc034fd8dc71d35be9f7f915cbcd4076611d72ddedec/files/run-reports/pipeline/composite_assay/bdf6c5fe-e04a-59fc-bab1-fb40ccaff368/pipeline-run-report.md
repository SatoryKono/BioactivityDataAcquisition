# Pipeline run report: composite_assay

- **run_id:** `bdf6c5fe-e04a-59fc-bab1-fb40ccaff368`
- **status:** success
- **run_type:** composite
- **tracking:** partial
- **catalog:** reason_catalog_v1
- **manifest_id:** `0a85b947-72f7-5b33-bf7d-5f303c03217b`
- **provider/entity:** composite / merged
- **started_at:** 2026-10-05T08:25:54.201694+00:00
- **completed_at:** 2026-10-05T08:26:33.501722+00:00

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|

## Layers

- bronze: **0**
- silver valid: **10** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **10** (excluded=0, quarantined=0, skipped=0, dedup=0)

## Top reasons

- (none)

## IO

- **execution_context:** `composite`
- **child_runs:**
  - `{'pipeline_name': 'chembl_assay', 'run_id': 'df3eb58f-ab94-51fa-8f35-0ddd0c5d4c9a', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_assay\\reports\\pipeline\\chembl_assay\\df3eb58f-ab94-51fa-8f35-0ddd0c5d4c9a\\pipeline-run-report.json'}`
  - `{'pipeline_name': 'chembl_tissue', 'run_id': '19a5b432-6925-5464-b01c-7c0f5880986c', 'status': 'success', 'report_ref': 'C:\\Users\\Fedor\\.codex\\worktrees\\rf022-runner-preparation\\BioactivityDataAcquisition\\reports\\quality\\rf022-live-1180964b-20261005-wave02\\composite-composite_assay\\reports\\pipeline\\chembl_tissue\\19a5b432-6925-5464-b01c-7c0f5880986c\\pipeline-run-report.json'}`

## Artifacts

- `composite_child_run_report`: `pipeline/chembl_assay/df3eb58f-ab94-51fa-8f35-0ddd0c5d4c9a/pipeline-run-report.json`
- `composite_child_run_report`: `pipeline/chembl_tissue/19a5b432-6925-5464-b01c-7c0f5880986c/pipeline-run-report.json`
- `composite_replay_object`: `replay/config.json`
- `composite_replay_object`: `replay/expected/gold.arrow`
- `composite_replay_object`: `replay/expected/silver.arrow`
- `composite_replay_object`: `replay/field-groups.json`
- `composite_replay_object`: `replay/inputs/0000-20d56a79cbce82eb0c5134452a74fa96a40bb047165fa82406210040345601fe.arrow`
- `composite_replay_object`: `replay/inputs/0001-f5e87dcc7f42908d83d34fa4526878aaab94018f126e4af2a267e76776422bd9.arrow`
- `composite_replay_object`: `replay/inputs/inputs.json`
- `composite_exact_replay`: `replay/parent.json`
- `composite_replay_object`: `replay/pipeline-settings.json`
- `composite_replay_object`: `replay/uv.lock`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/95d3ec97002da4e788deedd5f23a30925e200494ccfd40239fdd8e4b77c00a4a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_fragment_id/f4d3cae61b8a61bcb2314416cb0d850391849651befdac4ac2108e8da15754d7.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/1f551b0e5760da276ce04979e844b08fc37ad2e40f69bef73d560d4d61aabb7f.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/3182cb4651fb1698e2c61c24682b2171a93bf13a6b1873757f613dc9c1c30b7f.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/396d58cd70243e1c5c185ad883ca15417a45c60026e212e9f46920ec3ac80801.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/70881504a003f5478a82628b980e7a08532152d3ccd4d4fa0a3218cf9791c79e.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/a47e10c32b41ec41a7829a03930c9d0f4c3b84d1b532bc2b80202d53b568f80a.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_node_id/f2c52e3dceb104fa232bee6544f8ac992af6dadb14632e9fe985a3b0ad939813.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/_by_run_id/fafaf8c0c12f683300864a3c4eb560fb82419d9f2582e33dc14abbd721db2e00.jsonl`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/27aa67f86322dabe8f82ae67ad7bd4c0143d393f49af0bb9fba060a6e8a60125.json`
- `composite_replay_object`: `replay/verification/output/control/lineage/fragments/3a64426d57b585b372f105e5051ce172835e341c1ce6669cc3e262d40bc41542.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/assay/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/gold/composite/assay/composite_assay_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/gold/composite/assay/part-00001-a3caa8d9-a932-47ff-b0bc-31a25983d54e-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/output/silver/composite/assay/_delta_log/00000000000000000000.json`
- `composite_replay_object`: `replay/verification/output/silver/composite/assay/composite_assay_metadata.yaml`
- `composite_replay_object`: `replay/verification/output/silver/composite/assay/part-00001-e3a3e65e-08dd-4141-b12d-9c0ff202dc1c-c000.snappy.parquet`
- `composite_replay_object`: `replay/verification/verification.json`
- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_assay/reports/pipeline/composite_assay/bdf6c5fe-e04a-59fc-bab1-fb40ccaff368/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_assay/reports/pipeline/composite_assay/bdf6c5fe-e04a-59fc-bab1-fb40ccaff368/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **None** (delta=None)
- gold vs silver: **None** (delta=None)
