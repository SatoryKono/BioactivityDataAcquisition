# Pipeline run report: chembl_tissue

- **run_id:** `19a5b432-6925-5464-b01c-7c0f5880986c`
- **status:** success
- **run_type:** incremental
- **tracking:** full
- **catalog:** reason_catalog_v1
- **manifest_id:** `e43a5082-1e30-5fbb-adf2-b087e42f117e`
- **provider/entity:** chembl / tissue
- **started_at:** 2026-10-05T08:26:13.385906+00:00
- **completed_at:** 2026-10-05T08:26:31.025445+00:00
- **duration_seconds:** 17.639539

## Funnel

| Stage | In | Out | Removed | Balance | Tracking | Top reasons |
|-------|---:|----:|--------:|---------|----------|-------------|
| extract | 2 | 2 | 0 | OK | full | — |
| bronze | 2 | 2 | 0 | OK | full | — |
| silver | 2 | 2 | 0 | OK | full | — |
| gold | 2 | 0 | 2 | OK | full | OPERATOR_SKIPPED=2 |

## Layers

- bronze: **2**
- silver valid: **2** (filtered=0, quarantined=0, skipped=0, dedup=0)
- gold written: **0** (excluded=0, quarantined=0, skipped=2, dedup=0)

## Top reasons

- `OPERATOR_SKIPPED` (skipped): 2

## IO

- **pipeline_name:** `chembl_tissue`
- **run_type:** `incremental`
- **limit:** `5`
- **filter_column:** `tissue_id`
- **skip_gold:** `True`
- **dry_run:** `False`
- **use_cached_bronze:** `False`
- **filter_id_count:** `2`
- **filter_id_hash:** `c3eb7b1fc0c97ce8`

## Schema versions

- **reason_catalog_version:** `reason_catalog_v1`
- **bioetl_version:** `6.1.0`

## Performance

- **duration_seconds:** `17.639539`
- **records_per_second:** `0.1134`

## Artifacts

- `pipeline_run_report_json`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_assay/reports/pipeline/chembl_tissue/19a5b432-6925-5464-b01c-7c0f5880986c/pipeline-run-report.json`
- `pipeline_run_report_md`: `C:/Users/Fedor/.codex/worktrees/rf022-runner-preparation/BioactivityDataAcquisition/reports/quality/rf022-live-1180964b-20261005-wave02/composite-composite_assay/reports/pipeline/chembl_tissue/19a5b432-6925-5464-b01c-7c0f5880986c/pipeline-run-report.md`

## Reconciliation

- silver vs bronze: **OK** (delta=0)
- gold vs silver: **OK** (delta=0)
