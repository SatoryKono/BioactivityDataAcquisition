# RF-001: пакет раскрытых dashboards из #10165

Source commit: `e8d64ddbf867dba8310fecf4572cd88909eb47eb`. Immutable manifest SHA-256: `fd7291c26cd71e162b69fafb30d593252a8502c8ceb476435efef48797e70746`.
Проверено 7/7 цепочек commit → JSON → before/browser-loaded/after model → browser context → PNG.
Scope: provenance only. Layout, accessibility и корректность чисел требуют отдельных verdicts.

`source.bundle` содержит ветку layout и требует существующий public main ancestor
`cab240755d10137642f9086ea5b2e6f88b4a56d9`. В клоне репозитория выполните:

```shell
git fetch /absolute/path/source.bundle refs/heads/codex/layout-dom-fit-10165:refs/heads/review-layout-10165
git worktree add --detach /absolute/path/layout-source e8d64ddbf867dba8310fecf4572cd88909eb47eb
```

Из checkout с merged verifier PR #10236:

```python
from pathlib import Path
from scripts.ops.observability.grafana.capture_provenance import verify_capture
result = verify_capture(Path("/absolute/path/capture/render-manifest--full-set--10165-expanded-e8d64ddbf86-1366x768-dark-full.json"), repo_root=Path("/absolute/path/layout-source"), expected_sha256="fd7291c26cd71e162b69fafb30d593252a8502c8ceb476435efef48797e70746", expected_commit="e8d64ddbf867dba8310fecf4572cd88909eb47eb")
assert result["status"] == "PASS", result
```

`file-index.json` закрепляет все вложения; mutable latest pointer исключён.
