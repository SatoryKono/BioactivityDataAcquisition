# Local Skills Catalog (BioETL Core)

Consolidated registry of BioETL-focused local skills under `.codex/skills/`.

## Canonical Rules

- `.codex/skills/` is the canonical source for repository-local skills.
- `docs/00-project/ai/skills/local/` is a generated mirror and must not be edited manually.
- Treat each `SKILL.md` frontmatter (`name`, `description`) as the trigger contract.
- Verify and sync the local docs mirror with:

```bash
bash scripts/check_skills_mirror.sh --check
bash scripts/check_skills_mirror.sh --sync
```

## Skill Groups

### Orchestration

| Skill | Path | Purpose |
|------|------|---------|
| `agent-orchestration` | `.codex/skills/agent-orchestration` | Multi-agent coordination map |
| `py-review-orchestrator` | `.codex/skills/py-review-orchestrator` | Hierarchical review campaign |
| `py-test-swarm` | `.codex/skills/py-test-swarm` | Hierarchical test swarm (L1/L2/L3) |

### Profile Skills

| Skill | Path | Purpose |
|------|------|---------|
| `py-audit-bot` | `.codex/skills/py-audit-bot` | Audit profile workflow |
| `py-code-bot` | `.codex/skills/py-code-bot` | Deprecated compatibility profile for historical references |
| `py-config-bot` | `.codex/skills/py-config-bot` | Config profile workflow |
| `py-debug-bot` | `.codex/skills/py-debug-bot` | Debug profile workflow |
| `py-doc-bot` | `.codex/skills/py-doc-bot` | Documentation profile workflow |
| `py-plan-bot` | `.codex/skills/py-plan-bot` | Planning profile workflow |
| `py-test-bot` | `.codex/skills/py-test-bot` | Test profile workflow |

`py-code-bot` is retained only as a compatibility surface for historical references. In the current Codex workflow, production code is written directly by the orchestrator.

### Architecture and Quality

| Skill | Path | Purpose |
|------|------|---------|
| `architecture-guardian` | `.codex/skills/public/architecture-guardian` | Architecture boundary validation |
| `verify-architecture` | `.codex/skills/verify-architecture` | Quick/full architecture checks |
| `vcr-record` | `.codex/skills/vcr-record` | VCR cassette recording/safety |

### Documentation

| Skill | Path | Purpose |
|------|------|---------|
| `documentation-audit` | `.codex/skills/documentation-audit` | Full docs audit and updates |
| `documentation-cascade-audit` | `.codex/skills/documentation-cascade-audit` | Hierarchical docs audit orchestration |

### Research and Planning Utilities

| Skill | Path | Purpose |
|------|------|---------|
| `capability-discovery` | `.codex/skills/capability-discovery` | Discover available agents/skills/quality commands |
| `collecting-evidence` | `.codex/skills/collecting-evidence` | Build traceable evidence objects |
| `deep-research` | `.codex/skills/deep-research` | Structured deep research workflow |
| `synthesizing-pillars` | `.codex/skills/synthesizing-pillars` | Convert evidence into synthesis insights |
| `making-decisions` | `.codex/skills/making-decisions` | Turn synthesis into explicit decisions |
| `generating-constrained-specs` | `.codex/skills/generating-constrained-specs` | Generate PRD/architecture specs from decisions |
| `initializing-ledger` | `.codex/skills/initializing-ledger` | Initialize decision/evidence workspace |
| `repo-config` | `.codex/skills/repo-config` | Resolve dynamic repository configuration |
| `suggest-users` | `.codex/skills/suggest-users` | Suggest reviewers/assignees from repo context |
| `create-pr` | `.codex/skills/create-pr` | PR creation workflow guidance |
| `nci-analysis` | `.codex/skills/nci-analysis` | Manipulation/disinformation pattern analysis |

### Build and Design Utilities

| Skill | Path | Purpose |
|------|------|---------|
| `new-pipeline` | `.codex/skills/new-pipeline` | Provider/entity pipeline scaffolding |
| `technical-designer-mermaid` | `.codex/skills/technical-designer-mermaid` | Mermaid technical diagram design |

## Current Consolidation Status

- All local skills are structurally valid.
- `documentation-cascade-audit` has been normalized from template/TODO state to an active skill.

## Mirror Doc Index

- [agent-orchestration](agent-orchestration/SKILL.md)
- [capability-discovery](capability-discovery/SKILL.md)
- [collecting-evidence](collecting-evidence/SKILL.md)
- [create-pr](create-pr/SKILL.md)
- [deep-research](deep-research/SKILL.md)
- [documentation-audit](documentation-audit/SKILL.md)
- [documentation-cascade-audit](documentation-cascade-audit/SKILL.md)
- [generating-constrained-specs](generating-constrained-specs/SKILL.md)
- [initializing-ledger](initializing-ledger/SKILL.md)
- [making-decisions](making-decisions/SKILL.md)
- [nci-analysis](nci-analysis/SKILL.md)
- [new-pipeline](new-pipeline/SKILL.md)
- [py-audit-bot](py-audit-bot/SKILL.md)
- [py-code-bot](py-code-bot/SKILL.md)
- [py-config-bot](py-config-bot/SKILL.md)
- [py-debug-bot](py-debug-bot/SKILL.md)
- [py-doc-bot](py-doc-bot/SKILL.md)
- [py-plan-bot](py-plan-bot/SKILL.md)
- [py-review-orchestrator](py-review-orchestrator/SKILL.md)
- [py-test-bot](py-test-bot/SKILL.md)
- [py-test-swarm](py-test-swarm/SKILL.md)
- [repo-config](repo-config/SKILL.md)
- [suggest-users](suggest-users/SKILL.md)
- [synthesizing-pillars](synthesizing-pillars/SKILL.md)
- [technical-designer-mermaid](technical-designer-mermaid/SKILL.md)
- [vcr-record](vcr-record/SKILL.md)
- [verify-architecture](verify-architecture/SKILL.md)
- [architecture-guardian (public)](public/architecture-guardian/SKILL.md)

## Shared Generic Skills

Additional non-BioETL generic skills may coexist under `.codex/skills/` (for example discovery, decision, and research helpers). They are intentionally excluded from the core catalog above.
