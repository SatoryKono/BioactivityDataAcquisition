# Documentation Audit Report (BioETL v5.23+)

## Summary
- Date:
- Scope:
- Overall status:

## Inventory
- Docs scanned:
- Entry points (README.md, mkdocs.yml):

## Findings by severity
### Critical
- 

### High
- 

### Medium
- 

### Low
- 

## Proposed changes (prioritized)
1. 
2. 
3. 

## Required decisions
- 

## Updated files (if changes applied)
- 

## Dead or orphan docs (candidates)
- 

## Verification
- RULES.md and REQUIREMENTS.md sync:
- ADR alignment (ADR-010, ADR-014, ADR-017):
- Link check:
