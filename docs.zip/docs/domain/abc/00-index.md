# Domain Contracts (ABC)

This directory contains documentation for Abstract Base Classes and Domain Contracts.

*Note: Some files may have been lost during refactoring. Please restore from version control if needed.*

- `00-index.md` (Reference catalog)

