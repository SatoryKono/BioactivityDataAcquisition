# Core Infrastructure

This directory contains documentation for core infrastructure components.

*Note: Some files may have been lost during refactoring. Please restore from version control if needed.*

- `05-schema-registry.md` (Missing)
- `06-validation-service.md` (Missing)

