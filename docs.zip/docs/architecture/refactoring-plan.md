# Архитектурный обзор и план рефакторинга BioETL

## 🏗️ Текущая архитектура

### Слоевая структура (Hexagonal Architecture)
```
┌──────────────────────────────────────────┐
│          Interfaces Layer                 │
│         (CLI, HTTP APIs)                  │
├──────────────────────────────────────────┤
│         Application Layer                 │
│    (Pipelines, Orchestration)            │
├──────────────────────────────────────────┤
│          Domain Layer                     │
│  (Business Logic, Schemas, Rules)        │
├──────────────────────────────────────────┤
│       Infrastructure Layer               │
│   (DB, Files, External APIs)             │
└──────────────────────────────────────────┘
```

### Основные компоненты

#### 1. Pipeline System (Template Method Pattern)
- **PipelineBase**: Абстрактный базовый класс с оркестрацией ETL
- **ChemblPipelineBase**: ChEMBL-специфичная база с примесью нормализации
- **Concrete Pipelines**: Activity, Assay, Document, Cell, Target, Molecule
- **Stages**: extract → transform → validate → write

#### 2. Normalization System
- **NormalizerMixin**: Конфигурационно-управляемая нормализация полей
- **CustomFieldNormalizers**: Доменные валидаторы (DOI, ChEMBL ID, UniProt)
- **Case Sensitivity**: Обработка химических структур (SMILES, InChI)
- **Nested Serialization**: Преобразование сложных структур в строки

#### 3. Data Integrity System
- **HashService**: SHA256 хеширование для целостности строк
- **Business Key Hashing**: Хеширование для дедупликации
- **Deterministic JSON**: Детерминированная сериализация

#### 4. Validation Layer
- **Pandera Schemas**: Строгая типизация данных
- **Schema Registry**: Паттерн регистра схем
- **Lazy Validation**: Отложенная валидация с агрегацией ошибок

## 🔍 Выявленные проблемы

### 1. Архитектурные проблемы

#### 1.1 Нарушение принципа единой ответственности (SRP)
- **ChemblPipelineBase** смешивает множество обязанностей:
  - Извлечение данных
  - Трансформация
  - Нормализация
  - Управление версиями ChEMBL
  - Построение метаданных

#### 1.2 Тесная связанность (High Coupling)
- Пайплайны напрямую зависят от конкретных реализаций сервисов
- Отсутствие инверсии зависимостей в некоторых местах
- Прямое наследование вместо композиции

#### 1.3 Смешение слоёв
- Нормализация (домен) смешана с пайплайнами (приложение)
- Конфигурация содержит как инфраструктурные, так и доменные настройки
- Валидация разбросана между слоями

### 2. Проблемы производительности

#### 2.1 Row-by-row обработка
- `apply()` используется для нормализации каждой строки отдельно
- Отсутствие векторизации для простых операций
- Неэффективное использование памяти при больших датасетах

#### 2.2 Избыточное копирование данных
- Множественные `df.copy()` на каждой стадии
- Отсутствие ленивых вычислений
- Загрузка всего датасета в память

### 3. Проблемы поддерживаемости

#### 3.1 Сложность нормализации
- 300+ строк кода в `normalize.py`
- Сложная логика с множеством условных веток
- Трудность добавления новых типов нормализации

#### 3.2 Конфигурационная сложность
- YAML конфигурации содержат 280+ строк на пайплайн
- Дублирование конфигурации между пайплайнами
- Отсутствие валидации на уровне конфигурации

#### 3.3 Недостаточное тестовое покрытие
- Отсутствие unit-тестов для критических компонентов
- Сложность тестирования из-за тесной связанности
- Отсутствие мокирования внешних зависимостей

### 4. Проблемы масштабируемости

#### 4.1 Отсутствие параллелизма
- Последовательная обработка батчей
- Нет использования многопоточности/многопроцессности
- Отсутствие стриминговой обработки

#### 4.2 Монолитная архитектура
- Все пайплайны в одном процессе
- Невозможность горизонтального масштабирования
- Отсутствие message-driven архитектуры

## 📋 План рефакторинга

### Фаза 1: Разделение ответственностей (2 недели)

#### 1.1 Выделение стратегий нормализации
```python
# domain/normalization/strategies.py
class NormalizationStrategy(ABC):
    @abstractmethod
    def normalize(self, value: Any) -> Any: ...

class IdentifierNormalizationStrategy(NormalizationStrategy):
    """For ChEMBL IDs, DOIs, etc."""

class ChemicalStructureNormalizationStrategy(NormalizationStrategy):
    """For SMILES, InChI, etc."""

class NumericNormalizationStrategy(NormalizationStrategy):
    """For floats with precision control"""
```

#### 1.2 Создание фабрики нормализаторов
```python
# domain/normalization/factory.py
class NormalizerFactory:
    def create_normalizer(self, field_config: FieldConfig) -> NormalizationStrategy:
        """Factory method to create appropriate normalizer"""
```

#### 1.3 Разделение PipelineBase
```python
# application/pipelines/core/
class DataExtractor:
    """Отвечает только за извлечение данных"""

class DataTransformer:
    """Отвечает только за трансформацию"""

class DataValidator:
    """Отвечает только за валидацию"""

class DataWriter:
    """Отвечает только за запись"""

class PipelineOrchestrator:
    """Координирует работу компонентов"""
```

### Фаза 2: Оптимизация производительности (1 неделя)

#### 2.1 Векторизация нормализации
```python
# domain/normalization/vectorized.py
class VectorizedNormalizer:
    def normalize_series(self, series: pd.Series) -> pd.Series:
        """Векторизованная нормализация для pandas Series"""
        # Использовать numpy operations где возможно
        # Использовать pandas string methods для строк
```

#### 2.2 Ленивая загрузка и стриминг
```python
# infrastructure/streaming/reader.py
class StreamingDataReader:
    def read_chunks(self, source, chunk_size: int):
        """Читает данные чанками для обработки больших файлов"""
```

#### 2.3 Кеширование результатов
```python
# infrastructure/cache/service.py
class CacheService:
    def get_or_compute(self, key: str, compute_fn: Callable):
        """Кеширует результаты дорогих вычислений"""
```

### Фаза 3: Улучшение конфигурации (1 неделя)

#### 3.1 Иерархия конфигураций
```yaml
# configs/base/default.yaml
base_config:
  common_settings: ...

# configs/pipelines/activity.yaml
extends: base/default
specific_settings: ...
```

#### 3.2 Строгая типизация конфигурации
```python
# infrastructure/config/types.py
@dataclass
class FieldDefinition:
    name: str
    data_type: DataType
    normalizer: NormalizerType
    validators: List[ValidatorType]
```

#### 3.3 Конфигурационный валидатор
```python
# infrastructure/config/validator.py
class ConfigValidator:
    def validate_pipeline_config(self, config: dict) -> PipelineConfig:
        """Валидирует и типизирует конфигурацию"""
```

### Фаза 4: Внедрение DI и тестируемость (1 неделя)

#### 4.1 Dependency Injection Container
```python
# application/container.py
from dependency_injector import containers, providers

class Container(containers.DeclarativeContainer):
    config = providers.Configuration()
    
    hash_service = providers.Singleton(
        HashService,
        hasher=providers.Factory(HasherImpl)
    )
    
    validation_service = providers.Singleton(
        ValidationService,
        schema_provider=providers.Factory(SchemaRegistry)
    )
```

#### 4.2 Интерфейсы для всех зависимостей
```python
# domain/contracts/
class DataExtractorABC(ABC): ...
class DataTransformerABC(ABC): ...
class DataValidatorABC(ABC): ...
```

#### 4.3 Unit тесты с моками
```python
# tests/unit/pipelines/
def test_pipeline_with_mocked_services():
    mock_extractor = Mock(spec=DataExtractorABC)
    mock_transformer = Mock(spec=DataTransformerABC)
    # ... test logic
```

### Фаза 5: Параллелизация и масштабирование (2 недели)

#### 5.1 Batch Parallel Processing
```python
# application/parallel/processor.py
class ParallelBatchProcessor:
    def process_batches(self, batches, processor_fn, n_workers=4):
        """Обрабатывает батчи параллельно"""
        with ProcessPoolExecutor(max_workers=n_workers) as executor:
            futures = [executor.submit(processor_fn, batch) for batch in batches]
```

#### 5.2 Async I/O для внешних вызовов
```python
# infrastructure/clients/async_chembl.py
class AsyncChemblClient:
    async def fetch_activities(self, ids: List[str]):
        """Асинхронная загрузка данных из API"""
```

#### 5.3 Message Queue интеграция
```python
# infrastructure/messaging/
class PipelineMessageBroker:
    def publish_task(self, task: PipelineTask):
        """Публикует задачу в очередь"""
    
    def consume_tasks(self, handler: Callable):
        """Потребляет и обрабатывает задачи"""
```

### Фаза 6: Мониторинг и observability (1 неделя)

#### 6.1 Метрики производительности
```python
# infrastructure/monitoring/metrics.py
class PipelineMetrics:
    def record_stage_duration(self, stage: str, duration: float): ...
    def record_rows_processed(self, count: int): ...
    def record_memory_usage(self, usage_mb: float): ...
```

#### 6.2 Distributed Tracing
```python
# infrastructure/tracing/
class PipelineTracer:
    def start_span(self, operation: str): ...
    def add_tags(self, **tags): ...
```

#### 6.3 Health Checks
```python
# application/health/
class PipelineHealthCheck:
    def check_dependencies(self) -> HealthStatus: ...
    def check_resources(self) -> HealthStatus: ...
```

## 🎯 Приоритеты рефакторинга

### Высокий приоритет (Quick Wins)
1. **Векторизация нормализации** - быстрый выигрыш в производительности
2. **Разделение ChemblPipelineBase** - улучшение поддерживаемости
3. **Выделение стратегий нормализации** - упрощение кода

### Средний приоритет
4. **DI Container** - улучшение тестируемости
5. **Конфигурационная иерархия** - уменьшение дублирования
6. **Параллельная обработка батчей** - масштабируемость

### Низкий приоритет
7. **Message Queue** - для будущего масштабирования
8. **Distributed Tracing** - для production monitoring
9. **Async I/O** - оптимизация сетевых вызовов

## 📊 Ожидаемые результаты

### Производительность
- **↑ 3-5x** скорость обработки за счёт векторизации
- **↑ 2-4x** за счёт параллельной обработки
- **↓ 40%** использование памяти за счёт стриминга

### Поддерживаемость
- **↓ 50%** сложность кода (cyclomatic complexity)
- **↑ 80%** тестовое покрытие
- **↓ 30%** дублирование кода

### Масштабируемость
- Возможность горизонтального масштабирования
- Обработка датасетов любого размера
- Распределённая обработка через message queue

## 🚀 Следующие шаги

1. **Создать POC** для векторизованной нормализации
2. **Провести бенчмарки** текущей производительности
3. **Начать с Фазы 1** - разделение ответственностей
4. **Настроить CI/CD** для автоматического тестирования
5. **Документировать** изменения архитектуры

## 📚 Дополнительные ресурсы

- [Clean Architecture by Robert Martin](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [Domain-Driven Design](https://martinfowler.com/bliki/DomainDrivenDesign.html)
- [Hexagonal Architecture](https://alistair.cockburn.us/hexagonal-architecture/)
- [SOLID Principles](https://en.wikipedia.org/wiki/SOLID)
