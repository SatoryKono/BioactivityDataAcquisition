# Target Relation (`target_relation`)

| Поле | Тип данных | Допустимые значения | Описание |
|------|------------|----------------------|----------|
| target_chembl_id | строка | — | Исходный таргет. |
| related_target_chembl_id | строка | — | Связанный таргет. |
| relationship | строка | — | Описание типа связи (например, SUBSET OF, SUPERSET OF). |
